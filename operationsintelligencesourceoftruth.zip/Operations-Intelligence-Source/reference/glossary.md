# Glossary

The one correct spelling and meaning for every term, role, and identifier in
Operations Intelligence. When you write code, documentation, or a deliverable, use
these exactly. Where a term has a fuller treatment, the authoritative section is named.

## Platform and surfaces

| Term | Meaning |
|---|---|
| **Operations Intelligence** | The platform: a ServiceNow scoped application for operations teams. Never abbreviated in prose. `oi-` is acceptable only as an artifact-name prefix (widget IDs, CSS classes). |
| **Operations Assistant** | The platform's Virtual Agent (channel). Entirely separate from Now Support. The natural-language interface to everything. |
| **Operations Intelligence NLU** | The dedicated NLU model. No shared intents or training data with Now Support. |
| **Portal** | The single Service Portal at URL suffix `/operations_intelligence`, portal id `operations_intelligence`, default page `main`. |
| **Sections** | The role-filtered areas within the `main` page: Workspace, My Activity, Studio, Governance, Command. Switching is client-side; no page reload. |
| **`{scope}`** | Placeholder for the application scope prefix. Actual value: **`x_infte_ops_int`**. All custom tables are auto-prefixed, e.g. `x_infte_ops_int_automation`. |

## Roles (system) and group roles

| Term | Meaning |
|---|---|
| **admin** | Platform/IT. Full access; onboards top-level leadership; sees the Command section. |
| **leadership** | Business leaders. Group governance, onboarding, approvals; sees the Governance section. |
| **creator** | Appointed power users. Design automations and deliverables for their groups; see the Studio section. A *system role*, auto-granted when leadership appoints a group creator. |
| **user** | All other staff. Trigger automations and request deliverables via the Operations Assistant. |
| **group role** | Per-group role on `group_member`: `creator` or `user`. Independent of system role — a person can be a creator in one group and a user in another. |
| **delegation_rights** | Boolean on the `person` record (its single source of truth). A leader with it set may onboard sub-leaders, never exceeding their own level. |

Roles are always read from ServiceNow (`gs.hasRole()`), never from a field on a custom
table. Authoritative: architecture *Roles*.

## Core concepts

| Term | Meaning |
|---|---|
| **Automation** | A multi-step process sequence (`automation` + `automation_step` + `automation_input`), executed by `ExecutionEngine` on demand or on schedule. One of the two creative tracks. |
| **Deliverable / managed artifact** | A persistent ServiceNow artifact (report, dashboard, notification rule, scheduled data job, flow, custom table, UI page) registered in `managed_artifact` and managed for its whole lifecycle through Operations Intelligence. The second creative track. |
| **Execution** | One run of an automation (`execution` + `execution_step_log`). `is_test = true` runs are dry-run and excluded from `usage_count`. |
| **Group** | An operations team. `leadership_group` (auto-created for a leader) or `custom_group`. Content is scoped to groups. |
| **Pending action** | A queued decision (`pending_action`): approval, deactivation, expiry, escalation. Escalation **updates** the existing record; it never creates a second. |
| **Use case request** | The captured requirements for an automation (`use_case_request`), produced by the NLU conversation, optionally Copilot-enhanced. |
| **Creator credential** | A creator's encrypted GitHub PAT (`creator_credential.github_pat`, `password2`). Read-blocked for everyone including admin; read only by `CopilotBridge` via an elevated GlideRecord, never returned or logged. |

## Operations Intelligence Engine

| Term | Meaning |
|---|---|
| **Engine** | The Scripted REST API built in the `x_infte_ops_int` scope that exposes 35 operations for diagnostics, discovery, DDL, record CRUD, access control, file ops, and self-management. The primary mechanism for building the platform from outside ServiceNow. |
| **Engine key** | A 40-character random string stored in `x_infte_ops_int.engine_key`. Sent on every Engine call in the `X-Engine-Key` header. Never committed to source. |
| **`"platform": true`** | Flag on any `record.*` Engine operation that routes the request through the Table REST API as `svc_operations_intelligence_api` instead of a scoped GlideRecord. Enables writes to cross-scope system tables. |
| **`engine.selfupdate`** | Engine operation that replaces the engine's own operation script. Safety check: the submitted script must contain both `'X-Engine-Key'` and `'function dispatch'` markers. |
| **Engine base path** | `/api/x_infte_ops_int/engine/v1` — the Scripted REST base URI for all Engine calls. |

## Key Script Includes (full list: architecture *Script Includes*)

| Name | One-line role |
|---|---|
| **PermissionResolver** | Reads ServiceNow roles + group_member; never `person.system_role`. |
| **VAHelper** | VA context: identity, role, groups, top-N catalog, section context. |
| **CatalogService** | Automation lifecycle: create, version, publish, deprecate, VA topic, NLU retrain. |
| **ExecutionEngine** | Runs automation steps; template-variable resolution; dry-run; step logging. |
| **ApprovalRouter** | Self-approval guard, null-leader fallback, escalation, target resolution. |
| **CopilotBridge** | One bounded Copilot call; write-only PAT access; silent fallback; phrase merge / deliverable spec. |
| **ArtifactManager** | Deliverable registry: `managed_artifact` CRUD, lifecycle, builder dispatch. |
| **TableBuilder / ReportBuilder / NotificationBuilder / FlowBuilder / UIPageBuilder** | The five builders that create the underlying ServiceNow records per deliverable type. |
| **MaintenanceManager** | Reads/writes maintenance state; generates the Studio export URL; logs via AuditService. |
| **AuditService** | Field-level audit logging for privileged admin actions. |

## Identifiers you must spell exactly

| Thing | Exact value |
|---|---|
| Scope prefix | `x_infte_ops_int` |
| Portal id / URL suffix | `operations_intelligence` |
| Default portal page | `main` |
| Maintenance widgets | `oi-maintenance-overlay`, `oi-maintenance-control-panel` |
| Maintenance properties | `{scope}.maintenance_sections`, `.maintenance_message`, `.maintenance_return_at`, `.maintenance_initiated_by`, `.maintenance_initiated_at` |
| Notification prefix | `Operations Intelligence - ` |
| Update set | `Operations Intelligence v1.0.0` |
| Service account | `svc_operations_intelligence_api` |
| Engine key property | `x_infte_ops_int.engine_key` |
| Engine password property | `x_infte_ops_int.svc_password` |
| Engine base path | `/api/x_infte_ops_int/engine/v1` |

## Easy-to-confuse distinctions

- **`sysauto_script` vs `sysauto_report`.** `sysauto_script` is used **only** by
  `ScheduleManager` for automation scheduling; its body is always
  `new ExecutionEngine().runScheduled(automation_sys_id)`. Scheduled **data jobs**
  (a deliverable) use `sysauto_report` — declarative, no script. Never build a
  scheduled data job as a `sysauto_script`.
- **Automation vs deliverable.** Both are created by natural language and use Copilot,
  but an automation *runs* (executions) while a deliverable *exists* (a durable
  artifact). They live in different tables and follow different lifecycles.
- **System topic vs per-automation topic.** System topics are fixed capabilities built
  once; per-automation topics are generated by `CatalogService.onPublish()`.
- **Engine `"platform": true` vs scoped GlideRecord.** Scoped GlideRecord can only
  write to tables within the `x_infte_ops_int` scope. `"platform": true` routes through
  the Table API as `svc_operations_intelligence_api` (admin), enabling writes to any
  ServiceNow table — required for Script Includes, business rules, portal records, etc.
