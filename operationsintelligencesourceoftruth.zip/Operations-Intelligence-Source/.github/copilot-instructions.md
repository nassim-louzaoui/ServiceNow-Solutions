# Operations Intelligence — Instructions for AI Working in This Repository

You are working inside the **single source of truth** for the Operations
Intelligence platform. This file is loaded automatically every session. Read it
fully before acting. It tells you what the platform is, how this repository is
organised, and the rules you must follow when you read from it, build from it,
generate deliverables from it, or change it.

---

## 1. What the Platform Is (one paragraph)

Operations Intelligence is a ServiceNow scoped application (`x_infte_ops_int`) that
lets Infosys operations teams create, govern, and execute process automations and
persistent ServiceNow deliverables (reports, dashboards, notification rules,
scheduled data jobs, flows, custom tables, UI pages) entirely through natural
language, via a dedicated Virtual Agent called the **Operations Assistant**. When a
user cannot supply a technical detail, GitHub Copilot generates the specification
and the user confirms it. Role-appropriate approval workflows govern impactful
changes. Everything lives at one portal: `/operations_intelligence`.

For the *why* in depth, read [`../context/`](../context/). For the *what* in full,
read [`../architecture/solution-architecture.md`](../architecture/solution-architecture.md).
Do not reconstruct either from this summary — these instructions are an index, not
a substitute.

---

## 2. The Authority Order (resolve every conflict with this)

1. [`../architecture/solution-architecture.md`](../architecture/solution-architecture.md)
   — authoritative for all **technical** facts.
2. [`../context/`](../context/) — authoritative for all **business** facts.
3. [`../implementation/`](../implementation/) — verbatim artifact source; must match
   the architecture and the live instance.
4. Everything else is **derived** and must yield to the above.

If two files disagree, the higher source wins and the lower file is wrong and must
be corrected (see §6).

---

## 3. How to Read This Repository

- `ai-guide/operating-guide.md` — **start here for any task.** It classifies the
  request (explain / build / generate / change) and routes you to the right canon and
  procedure.
- `context/` — business narrative: problem, value, future state, solution.
- `architecture/solution-architecture.md` — the complete technical specification.
- `implementation/coding-patterns.md` — the canonical patterns every artifact follows.
- `implementation/engine-api-guide.md` — calling the Operations Intelligence Engine to
  create, modify, and query any ServiceNow artifact from outside the instance.
- `implementation/recipes/` — step-by-step "add one artifact" procedures.
- `implementation/scripts/` — exact, deployable source for background scripts,
  Script Includes, and Service Portal widgets. Byte-for-byte what is in ServiceNow.
- `implementation/build-order.md` — the deploy sequence and background scripts.
- `ai-delivery/` — the logic and worked deliverables for producing presentations,
  overviews, and briefings from the canon.
- `reference/glossary.md` — the exact spelling of every term and identifier.
- `maintenance/self-maintenance-protocol.md` — how to keep this repository true.

---

## 3a. When You Build or Implement

The primary build mechanism is the **Operations Intelligence Engine**: a Scripted REST
endpoint in the `x_infte_ops_int` scope, authenticated with an API key, that exposes
35 operations covering diagnostics, discovery, DDL, record CRUD, access control,
file operations, and engine self-management. Use it for creating tables, Script
Includes, business rules, properties, notifications, VA topics, and all other
artifacts. See [`../implementation/engine-api-guide.md`](../implementation/engine-api-guide.md).

For in-instance work (background scripts run in ServiceNow Studio), confirm where
the artifact fits in [`../implementation/build-order.md`](../implementation/build-order.md);
follow [`../implementation/coding-patterns.md`](../implementation/coding-patterns.md);
use the matching procedure in [`../implementation/recipes/`](../implementation/recipes/);
build from the **verbatim** source in [`../implementation/scripts/`](../implementation/scripts/).

After any build step, verify and record the change per §6.

---

## 4. When You Generate a Deliverable

Go to [`../ai-delivery/`](../ai-delivery/README.md). Use
[`../ai-delivery/generation-logic.md`](../ai-delivery/generation-logic.md) to choose
the audience, map the right source sections, and assemble the output. The three
files in `ai-delivery/deliverables/` are complete, regenerate-able reference
deliverables — adapt them; never ship a draft with bracketed blanks. Every claim in
a generated deliverable must trace to the canon.

---

## 5. Non-Negotiable Technical Facts

Use these exactly; getting them wrong produces an incorrect or insecure result.

- Application scope prefix: **`x_infte_ops_int`**. Custom tables are scope-prefixed:
  the `automation` table is `x_infte_ops_int_automation`. The architecture writes the
  unprefixed name for readability; real code uses the prefix.
- Service account: **`svc_operations_intelligence_api`**. This account is used by the
  Engine for internal REST calls (`sn_ws.RESTMessageV2`). It holds the `admin` role.
  Its password is stored in the `x_infte_ops_int.svc_password` system property —
  **never in source code or this repository**.
- Engine API key: stored in the `x_infte_ops_int.engine_key` system property —
  **never in source code or this repository**. Every Engine call must include the key
  in the `X-Engine-Key` request header.
- `"platform": true` on any `record.*` Engine operation routes the request through
  the Table REST API (as `svc_operations_intelligence_api`) instead of a scoped
  GlideRecord, enabling writes to cross-scope system tables (Script Includes, business
  rules, portal records, etc.).
- `system_role` is **never** stored on `person`. Read roles via `gs.hasRole()`.
- `creator_credential.github_pat` has **Read ACL = NOBODY**, including admin and
  elevated scripts. `CopilotBridge` reads it via a privileged GlideRecord and passes
  it straight to the outbound call without returning or logging it.
- `managed_artifact.artifact_sys_ids` is readable by admin and System only.
- `sysauto_script` is used **only** by `ScheduleManager` for automation scheduling.
  Scheduled **data jobs** use `sysauto_report`.
- Maintenance state is five `{scope}.maintenance_*` system properties, polled every
  30 seconds by the Content Area widget. The Export Application XML button is gated
  behind full-application maintenance (`maintenance_sections = ["all"]`).
- Approval escalation **updates** the existing `pending_action` record — it never
  creates a second one.
- CopilotBridge makes one bounded call; on any failure it falls back silently and the
  user still gets a complete result.

---

## 6. When the Platform Changes, Change This Repository

This repository is self-maintaining by discipline, not magic — you are the
mechanism. If you correct or extend the platform, you must update both the relevant
canon and the verbatim source in the same change. Follow
[`../maintenance/self-maintenance-protocol.md`](../maintenance/self-maintenance-protocol.md)
exactly. Never add a changelog, a "v2" note, or dated history to file content; edit
the file so it states the new current truth. Git history is the only history.
