# AI Guide

This folder is the operating manual for any AI working on Operations Intelligence from
this repository. `.github/copilot-instructions.md` is the short, auto-loaded entry
point; this folder is the depth behind it.

| File | Read it to… |
|---|---|
| [`operating-guide.md`](operating-guide.md) | Know exactly how to handle each kind of request — explain, build, generate, or change — and the rules that bind all of them |

Start at [`operating-guide.md`](operating-guide.md). It routes you to the right canon
and the right procedure for whatever you have been asked to do.
