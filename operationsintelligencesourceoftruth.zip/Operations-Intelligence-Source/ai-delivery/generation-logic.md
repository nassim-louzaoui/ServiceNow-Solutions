# Generation Logic

This file is the reusable procedure any AI follows to produce a deliverable from
this repository. It is deliberately mechanical: follow the steps in order and the
output will be accurate, audience-appropriate, non-repetitive, and traceable to the
canon.

## Step 1 — Identify audience and intent

Classify the request along two axes. The audience determines language and depth; the
intent determines structure.

| Audience | Knows | Wants | Never wants |
|---|---|---|---|
| Executive / leadership | The business, not the platform | Problem, value, control, what to do | Implementation detail, jargon |
| Operations team (user) | Their own work | What they can ask for, how, what happens next | Architecture, ACLs, build steps |
| Platform / IT team | ServiceNow | Exact technical design and how to build/operate it | Marketing framing |

| Intent | Produces |
|---|---|
| Persuade / inform leadership | Executive presentation |
| Enable end users | Solution overview |
| Equip builders/operators | Technical briefing |
| Other documentation | Apply the same logic with the matching audience and the relevant source map |

## Step 2 — Map to source sections (single-source rule)

Pull each piece of content from exactly one canonical location. Never re-derive a
fact that the canon already states; cite it from there. Use this map:

| Content needed | Canonical source |
|---|---|
| The problem and its four parts | [`../context/01-problem-statement.md`](../context/01-problem-statement.md) |
| Business value and how it compounds | [`../context/02-business-value.md`](../context/02-business-value.md) |
| What "good" looks like, per role | [`../context/03-desired-future-state.md`](../context/03-desired-future-state.md) |
| How the solution works (business level) | [`../context/04-proposed-solution.md`](../context/04-proposed-solution.md) |
| Roles, hierarchy, delegation | architecture → *Roles*, *Organisational Hierarchy* |
| What users/creators can create + approval rules | architecture → *Deliverable Types & Governance* (governance matrix) |
| The user's working surface | architecture → *Group Workspace Interface*, *Portal Interface* |
| The conversational creation experience | architecture → *Automation Creation Flow*, *Deliverable Creation Flows* |
| Data model, Script Includes, business rules | architecture → *Data Model*, *Script Includes*, *Business Rules* |
| Security design | architecture → *Security & Access Control*, plus the Copilot PAT pattern in *CopilotBridge API Specification* |
| Copilot integration | architecture → *Copilot Role in Deliverables*, *CopilotBridge API Specification* |
| Maintenance mode | architecture → *Maintenance Mode* |
| Build & migration | architecture → *Build Order*, *Update Set & Migration Strategy*, plus [`../implementation/build-order.md`](../implementation/build-order.md) |
| Exact deployable code | [`../implementation/scripts/`](../implementation/scripts/) (verbatim — never paraphrase code) |

## Step 3 — Assemble, transforming rather than copying

- **Transform for the audience.** Restating a technical section verbatim to a
  business audience is wrong; so is hand-waving an architectural fact to a technical
  one. Convert depth into the right register, do not strip or pad it.
- **Say each thing once.** Within a deliverable, a fact appears in exactly one place.
  If two sections need it, one references the other.
- **No placeholders, ever.** If a value is unknown, it is not unknown — it is in the
  canon. Look it up. Do not emit `[TBD]`, `[insert]`, or a bracketed blank.
- **Quantify by mechanism, not invented numbers.** The canon does not contain
  customer metrics; do not fabricate percentages or hours. State value in terms of
  the mechanism that produces it ("recurring tasks become one-time requests"),
  which is both true and defensible.

## Step 4 — Verify before delivering

Run every claim against this checklist. If any item fails, fix it before shipping.

1. **Traceable** — every factual statement maps to a specific canon location.
2. **Accurate** — names are exact: roles (`admin`/`leadership`/`creator`/`user`),
   scope (`x_infte_ops_int`), portal (`/operations_intelligence`), VA channel
   (Operations Assistant), Script Include and widget names as written in the canon.
3. **Audience-fit** — no implementation detail in a business piece; no marketing in a
   technical piece.
4. **Non-repetitive** — no fact stated twice within the deliverable.
5. **Complete** — no placeholders, no unresolved brackets, no "to be added."
6. **Security-correct** — any mention of credentials or data access respects the
   real rules (`github_pat` unreadable by everyone including admin;
   `artifact_sys_ids` admin/System only; approval escalation updates the existing
   record).

## Step 5 — Keep the reference deliverables current

The three files in [`deliverables/`](deliverables/) are themselves outputs of this
logic. When the canon changes in a way that affects them, regenerate them as part of
the same change, per
[`../maintenance/self-maintenance-protocol.md`](../maintenance/self-maintenance-protocol.md).
They are living deliverables, not frozen samples.
