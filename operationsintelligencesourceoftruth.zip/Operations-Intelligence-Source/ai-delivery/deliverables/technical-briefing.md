# Operations Intelligence — Technical Briefing

*A complete briefing for the platform / IT team. Generated from
`architecture/solution-architecture.md` using `../generation-logic.md`. For
exhaustive field-level and step-level detail, the architecture document remains
authoritative; this briefing is the orientation a ServiceNow engineer needs to be
productive against it. No placeholders.*

---

## Application scope and surface

- **Type:** ServiceNow scoped application. Scope prefix `x_infte_ops_int` (written as
  `{scope}` in the canon; all custom tables are auto-prefixed, e.g.
  `x_infte_ops_int_automation`).
- **Portal:** one portal, ID and URL suffix `operations_intelligence`, default page
  `main`, plus an isolated `onboarding` page. Fully custom theme; no OOB pages.
- **Virtual Agent:** channel **Operations Assistant** and model **Operations
  Intelligence NLU** — both entirely separate from Now Support; no shared intents or
  training data.
- **Roles:** `admin`, `leadership`, `creator`, `user`. System roles are read via
  `gs.hasRole()`; they are never stored on a custom table. Group role (`creator` /
  `user`) is per-group on `group_member`, independent of system role.

## Data model — 19 custom tables

Core identity and org: `person`, `reporting_relationship`, `group`, `group_member`,
`onboarding_request`. Automation: `automation_category`, `approved_flow`,
`automation`, `automation_version`, `automation_step`, `automation_input`,
`group_automation`, `execution`, `execution_step_log`, `automation_schedule`,
`use_case_request`. Deliverables: `managed_artifact`. Security/queue:
`creator_credential`, `pending_action`.

Design points that matter when you build:

- `person` holds OI-specific profile data and `delegation_rights` — the single source
  of truth for who may onboard sub-leaders. It does **not** hold `system_role`.
- `automation_version` rows are immutable snapshots; each new published version is a
  new `automation` record sharing a `base_automation` self-reference.
- `execution.group` is denormalised on insert by a business rule for query
  performance.
- `managed_artifact.artifact_sys_ids` and `.creation_spec` are how Operations Intelligence manages the
  real underlying records; both are field-ACL-restricted.

## Script Includes — 21, in build (dependency) order

`PermissionResolver` → `VAHelper` → `NotificationService` → `GroupManager` →
`CatalogService` → `ScheduleManager` → `ExecutionEngine` → `ApprovalRouter` →
`OnboardingService` → `DeactivationHandler` → `FlowBridge` → `RESTBridge` →
`CopilotBridge` → `AuditService` → `MaintenanceManager` → `ArtifactManager` →
`ReportBuilder` → `NotificationBuilder` → `FlowBuilder` → `TableBuilder` →
`UIPageBuilder`.

The five builders (`ReportBuilder` … `UIPageBuilder`) depend on `ArtifactManager`;
`ArtifactManager` depends on `PermissionResolver`, `NotificationService`,
`AuditService`; `MaintenanceManager` depends on `AuditService` only. Client-callable
includes extend `AbstractAjaxProcessor` — `MaintenanceManager` is the worked example,
with both a GlideAjax surface and a server-side public API. Its verbatim source is in
[`../../implementation/scripts/script-includes/MaintenanceManager.js`](../../implementation/scripts/script-includes/MaintenanceManager.js).

## Business rules — 5

| # | Name | Table | When | Delegates to |
|---|---|---|---|---|
| 1 | Operations Intelligence - Deactivation Detector | `sys_user` | after update (active → false) | `DeactivationHandler` |
| 2 | Operations Intelligence - Execution Group Sync | `{scope}_execution` | before insert | inline group resolution |
| 3 | Operations Intelligence - Usage Count Increment | `{scope}_execution` | after update (→ success, non-test) | inline counter |
| 4 | Operations Intelligence - Automation Publish | `{scope}_automation` | after update (→ published) | `CatalogService.onPublish()` |
| 5 | Operations Intelligence - Deprecation Guard | `{scope}_automation` | after update (→ deprecation_queued) | inline + `CatalogService.onDeprecate()` |

Full scripts are in the architecture canon under *Business Rules*. Each rule is a
thin wrapper; logic lives in the Script Includes.

## Security model

- Table and row ACLs are defined in full in *Security & Access Control*. Highlights:
  `person`, `group`, and most automation tables are scoped to membership and role;
  `automation_version` is immutable (no write, no delete).
- **`creator_credential.github_pat`: Read ACL = NOBODY**, including admin and
  including scripts running as admin. `CopilotBridge` reads it through an elevated
  GlideRecord, passes the decrypted value straight to the outbound REST call, and
  discards the reference — it is never returned to a caller or written to a log.
- **`managed_artifact.artifact_sys_ids`**: admin and System only. `.creation_spec`:
  owning creator and admin. `execution.input_values` and
  `use_case_request.structured_spec`: the owner plus leadership/admin of the group.
- Approval **escalation updates the existing `pending_action`** (status, assigned_to)
  — it never creates a second record, preserving one traceable record per approval.

## Copilot integration

`CopilotBridge` makes a single bounded call to the Copilot chat-completions endpoint,
authenticated with the creator's PAT, in one of two modes:

- **Automation mode** (`max_tokens` 1000): returns additional NLU phrases, gap
  analysis, and step optimisations. Suggested phrases are **appended** to the
  creator's own, never replacing them; the creator confirms the merged list.
- **Deliverable mode** (`max_tokens` 3000): returns a full technical `spec`,
  `assumptions`, and clarifying `questions` for the artifact type; the creator
  confirms or adjusts before it is saved.

On any failure (timeout `{scope}.copilot_timeout_ms` default 15000ms, HTTP error,
parse failure, exhausted credits) it falls back silently — automation mode returns
the original spec; deliverable mode reverts to manual clarifying questions — and the
error is logged to `AuditService`, never surfaced to the user.

## Maintenance mode

State lives in five `{scope}.maintenance_*` properties (`sections` as a JSON array,
`message`, `return_at`, `initiated_by`, `initiated_at`). The Content Area widget
polls `MaintenanceManager.ajaxIsInMaintenance` every 30 seconds and swaps the
**Maintenance Overlay** widget in for any section in maintenance. The **Maintenance
Control Panel** (admin-only, Command section) toggles sections or the whole app, sets
the message and estimated return, and exposes the **Export Application XML** button —
gated so it is active only when `maintenance_sections = ["all"]`. `MaintenanceManager`
logs `maintenance_enabled`, `maintenance_disabled`, and `app_export_triggered` to
`AuditService`. All maintenance artifacts have verbatim source under
[`../../implementation/scripts/`](../../implementation/scripts/) and are installed by
`04_build_maintenance.js`.

## Build and migration

- **Build:** 15-step sequence in *Build Order* — tables → seed data → roles/ACLs →
  the 21 Script Includes in the order above → business rules → scheduled jobs (5,
  created inactive) → notifications (22) → NLU model → VA topics (23) → initial NLU
  training → portal + 20 widgets → auto-topic business rule → Copilot integration →
  activate jobs → end-to-end test. The four background scripts and their run order are
  in [`../../implementation/build-order.md`](../../implementation/build-order.md).
- **Verify:** `02_verify_implementation.js` checks every artifact group and the two
  critical field ACLs; it must pass before any promotion.
- **Migrate:** Studio application export is preferred; a single update set
  ("Operations Intelligence v1.0.0") is the fallback. Environment config sets are
  always applied separately per environment. The NLU model record migrates but its
  trained weights do not — **retrain NLU on every environment** after import, then
  re-run verification.
- **Test:** a 30-item end-to-end checklist in the canon covers onboarding, automation
  build with and without Copilot, Copilot-failure fallback, approvals and rejection,
  execution and usage counting, deactivation (user and leader), cross-group publish,
  deprecation with in-flight executions, every deliverable type, and the two security
  assertions (`github_pat` unreadable; `artifact_sys_ids` non-admin-blocked).
