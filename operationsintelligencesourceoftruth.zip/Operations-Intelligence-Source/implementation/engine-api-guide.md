# Operations Intelligence Engine — API Guide

The Operations Intelligence Engine is a Scripted REST API built in the
`x_infte_ops_int` scope. It is the **primary build and maintenance mechanism** for
the platform: a single authenticated endpoint that exposes 35 operations covering
diagnostics, discovery, DDL, record CRUD, access control, file operations, and
engine self-management. Every call is made as an HTTP POST.

---

## Authentication and base setup

Every call requires the engine key in a header. The key is a 40-character random
string stored in the `x_infte_ops_int.engine_key` system property. It is generated
once by `02a_generate_engine_key.js` and **never committed to source or this
repository**.

```
POST   https://{instance}.service-now.com/api/x_infte_ops_int/engine/v1
X-Engine-Key:   {engine_key}
Content-Type:   application/json
Accept:         application/json
```

A missing or wrong key returns HTTP 403.

---

## Request shape

Every call is a JSON body with at minimum an `"op"` field:

```json
{ "op": "operation.name", "field1": "value1", "field2": "value2" }
```

For batch calls:
```json
{ "op": "batch", "stop_on_error": true, "ops": [ { "op": "...", ... }, ... ] }
```

---

## Operation catalogue

### DIAGNOSTICS

#### `ping`
Returns `pong` and the current timestamp. Used to confirm the endpoint is live.
```json
{ "op": "ping" }
```

#### `help`
Returns the list of all available operations.
```json
{ "op": "help" }
```

#### `now`
Returns current ServiceNow date/time, user, and session scope.
```json
{ "op": "now" }
```

#### `scope.info`
Returns the application scope name, sys_id, and version.
```json
{ "op": "scope.info" }
```

#### `selftest`
Runs six sub-tests verifying the full capability matrix: auth, scoped-read,
scoped-write, platform-write, platform-read, platform-delete. All must pass before
the Engine is used for production builds.
```json
{ "op": "selftest" }
```

---

### DISCOVERY

#### `meta.tables`
Lists all tables in the `x_infte_ops_int` scope.
```json
{ "op": "meta.tables" }
```

#### `table.exists`
Checks whether a named table exists.
```json
{ "op": "table.exists", "table": "x_infte_ops_int_automation" }
```

#### `schema.fields`
Returns the field definitions for a table (from `sys_dictionary`).
```json
{ "op": "schema.fields", "table": "x_infte_ops_int_automation" }
```

---

### DDL (data definition)

All DDL operations use `"platform": true` internally (they write to system tables).

#### `schema.table.create`
Creates a new scoped table. Posts to `sys_db_object` with the full scoped name and
the application scope sys_id.

```json
{
  "op": "schema.table.create",
  "name": "my_table",
  "label": "My Table",
  "extends": "task"
}
```

Returns `full_name` (`x_infte_ops_int_my_table`) and `created_name` for verification.

#### `schema.add_field`
Adds a column to an existing table by posting to `sys_dictionary`.

```json
{
  "op": "schema.add_field",
  "table": "x_infte_ops_int_my_table",
  "element": "status",
  "type": "string",
  "label": "Status",
  "mandatory": false,
  "max_length": 40
}
```

#### `schema.add_choice`
Adds a choice value to a field's option list (`sys_choice`).

```json
{
  "op": "schema.add_choice",
  "table": "x_infte_ops_int_my_table",
  "field": "status",
  "value": "active",
  "label": "Active",
  "sequence": 1
}
```

#### `schema.set_autonumber`
Configures auto-numbering on a table (`sys_number`).

```json
{
  "op": "schema.set_autonumber",
  "table": "x_infte_ops_int_my_table",
  "prefix": "MYT",
  "start": 1001
}
```

---

### SYSTEM PROPERTIES

#### `property.set`
Creates or updates a system property.

```json
{ "op": "property.set", "name": "x_infte_ops_int.my_prop", "value": "hello", "type": "string" }
```

#### `property.get`
Reads a system property value.

```json
{ "op": "property.get", "name": "x_infte_ops_int.my_prop" }
```

#### `property.list`
Lists all properties in the `x_infte_ops_int` scope.

```json
{ "op": "property.list" }
```

---

### RECORDS

All record operations support `"platform": true` to route through the Table REST API
(as `svc_operations_intelligence_api`) instead of a scoped GlideRecord. This is
**required** when writing to cross-scope system tables (Script Includes, business
rules, portal records, widgets, ACLs, etc.). Omit the flag (or set `false`) for
operations on custom tables within the scope.

Optionally add `"scope": false` to suppress the automatic `sys_scope` tag on
platform inserts when writing to tables that don't use `sys_scope`.

#### `record.insert`
Inserts a single record.

```json
{
  "op": "record.insert",
  "table": "sys_script_include",
  "platform": true,
  "data": {
    "name": "MyService",
    "api_name": "x_infte_ops_int.MyService",
    "script": "var MyService = Class.create(); ...",
    "client_callable": "false",
    "access": "public",
    "active": "true"
  }
}
```

#### `record.insert_many`
Inserts multiple records in a single call.

```json
{
  "op": "record.insert_many",
  "table": "sys_properties",
  "platform": true,
  "records": [
    { "name": "x_infte_ops_int.prop_a", "value": "1" },
    { "name": "x_infte_ops_int.prop_b", "value": "2" }
  ]
}
```

#### `record.update`
Updates a record by sys_id.

```json
{
  "op": "record.update",
  "table": "sys_script_include",
  "platform": true,
  "sys_id": "{sys_id}",
  "data": { "script": "var MyService = Class.create(); ..." }
}
```

#### `record.upsert`
Inserts or updates based on a query. If the query matches, it updates; if not, it inserts.

```json
{
  "op": "record.upsert",
  "table": "sys_properties",
  "platform": true,
  "query": { "name": "x_infte_ops_int.my_prop" },
  "data": { "name": "x_infte_ops_int.my_prop", "value": "new_value" }
}
```

#### `record.delete`
Deletes a record by sys_id. Unbounded deletes (no sys_id) are blocked.

```json
{
  "op": "record.delete",
  "table": "x_infte_ops_int_my_table",
  "sys_id": "{sys_id}"
}
```

#### `record.get`
Retrieves a single record by sys_id.

```json
{
  "op": "record.get",
  "table": "x_infte_ops_int_automation",
  "sys_id": "{sys_id}",
  "fields": ["name", "status", "sys_created_on"]
}
```

#### `record.query`
Queries records with optional encoded query, field selection, and limit.

```json
{
  "op": "record.query",
  "table": "x_infte_ops_int_automation",
  "query": "status=active",
  "fields": ["name", "status"],
  "limit": 50,
  "order_by": "name"
}
```

#### `record.count`
Returns the count of matching records.

```json
{
  "op": "record.count",
  "table": "x_infte_ops_int_execution",
  "query": "state=success"
}
```

#### `record.aggregate`
Runs an aggregate query (sum, avg, count, min, max) grouped by field.

```json
{
  "op": "record.aggregate",
  "table": "x_infte_ops_int_execution",
  "aggregate": "COUNT",
  "group_by": "state"
}
```

---

### ACCESS CONTROL

#### `role.grant`
Grants a role to a user.

```json
{ "op": "role.grant", "user": "svc_operations_intelligence_api", "role": "admin" }
```

#### `role.revoke`
Revokes a role from a user.

```json
{ "op": "role.revoke", "user": "some_user", "role": "some_role" }
```

#### `user.roles`
Lists all roles for a user.

```json
{ "op": "user.roles", "user": "svc_operations_intelligence_api" }
```

---

### FILES

#### `attachment.write`
Attaches a Base64-encoded file to a record.

```json
{
  "op": "attachment.write",
  "table": "x_infte_ops_int_managed_artifact",
  "sys_id": "{record_sys_id}",
  "file_name": "spec.json",
  "content_type": "application/json",
  "content_base64": "eyJ0eXBlIjoiY..."
}
```

#### `attachment.read`
Reads an attachment as Base64.

```json
{ "op": "attachment.read", "sys_id": "{attachment_sys_id}" }
```

#### `attachment.list`
Lists attachments on a record.

```json
{
  "op": "attachment.list",
  "table": "x_infte_ops_int_managed_artifact",
  "sys_id": "{record_sys_id}"
}
```

---

### POWER OPERATIONS

#### `script.run`
Executes an arbitrary server-side JavaScript snippet and returns the result. The
script body is passed as a string; it runs in the `x_infte_ops_int` scope. Use with
care — prefer dedicated Engine operations where possible.

```json
{ "op": "script.run", "script": "return gs.getProperty('glide.installation.name');" }
```

#### `rest.call`
Makes an outbound HTTP call from ServiceNow.

```json
{
  "op": "rest.call",
  "method": "GET",
  "url": "https://api.example.com/data",
  "headers": { "Authorization": "Bearer {token}" }
}
```

#### `event.fire`
Fires a ServiceNow event.

```json
{
  "op": "event.fire",
  "name": "x_infte_ops_int.automation.completed",
  "table": "x_infte_ops_int_execution",
  "sys_id": "{sys_id}"
}
```

#### `sys.log`
Writes a message to the system log.

```json
{ "op": "sys.log", "message": "Build step completed", "level": "info" }
```

#### `cache.flush`
Flushes the ServiceNow cache.

```json
{ "op": "cache.flush" }
```

---

### ENGINE SELF-MANAGEMENT

#### `engine.source`
Returns the current engine operation script (the body of `02b_engine_operation_script.js`).

```json
{ "op": "engine.source" }
```

#### `engine.selfupdate`
Replaces the engine's own operation script. The submitted script must contain both
`'X-Engine-Key'` and `'function dispatch'` safety markers — the Engine rejects any
script missing either.

```json
{ "op": "engine.selfupdate", "script": "/* full replacement script */" }
```

---

### BATCH

#### `batch`
Executes multiple operations in a single call. With `stop_on_error: true`, execution
halts on the first failure; otherwise all operations are attempted.

```json
{
  "op": "batch",
  "stop_on_error": true,
  "ops": [
    { "op": "property.set", "name": "x_infte_ops_int.prop_a", "value": "1" },
    { "op": "record.insert", "table": "x_infte_ops_int_group", "data": { "name": "Team Alpha" } }
  ]
}
```

---

## Common patterns

### Idempotent artifact creation

Before inserting, query to check existence. If found, update; if not, insert:

```json
{ "op": "record.upsert",
  "table": "sys_script_include",
  "platform": true,
  "query": { "name": "MyService", "sys_scope.scope": "x_infte_ops_int" },
  "data": { "name": "MyService", "script": "...", "api_name": "x_infte_ops_int.MyService", ... }
}
```

### Creating a Script Include

```json
{
  "op": "record.upsert",
  "table": "sys_script_include",
  "platform": true,
  "query": { "name": "PermissionResolver", "sys_scope.scope": "x_infte_ops_int" },
  "data": {
    "name": "PermissionResolver",
    "api_name": "x_infte_ops_int.PermissionResolver",
    "client_callable": "false",
    "access": "public",
    "active": "true",
    "script": "var PermissionResolver = Class.create(); ..."
  }
}
```

### Creating a Business Rule

```json
{
  "op": "record.insert",
  "table": "sys_script",
  "platform": true,
  "data": {
    "name": "Operations Intelligence - Deactivation Detector",
    "collection": "sys_user",
    "when": "after",
    "action_update": "true",
    "condition": "current.active.changesTo(false)",
    "script": "new DeactivationHandler().handle(current);",
    "active": "true"
  }
}
```

### Verifying an artifact

After creating, confirm it exists:

```json
{
  "op": "record.query",
  "table": "sys_script_include",
  "platform": true,
  "query": "name=PermissionResolver^sys_scope.scope=x_infte_ops_int",
  "fields": ["name", "sys_id", "active"]
}
```

---

## Error responses

| HTTP status | Meaning |
|---|---|
| 403 | Missing or invalid `X-Engine-Key` |
| 400 | Unknown operation, missing required field, or safety check failed |
| 200 with `error` key | Operation-level failure (table not found, record not found, script error) |
| 200 with `result` key | Success |
