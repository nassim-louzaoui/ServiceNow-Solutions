# Coding Patterns & Conventions

Every artifact in Operations Intelligence follows a small set of patterns. Use them
exactly when you build or extend the platform — they are what make the code
consistent, idempotent, and safe. The verbatim files in
[`scripts/`](scripts/) are the worked examples referenced throughout.

This file is about *how* to write artifacts. *What* to build and in what order is the
architecture canon and [`build-order.md`](build-order.md).

---

## 1. Scope prefix discipline

All custom tables are auto-prefixed with the application scope. The architecture
writes the unprefixed name (`automation`); real code uses the prefixed name
(`x_infte_ops_int_automation`).

- **Never hardcode the prefix as a literal.** Resolve it at runtime:
  `gs.getCurrentScopeName()` (server) returns `x_infte_ops_int`. Build table names as
  `gs.getCurrentScopeName() + '_automation'` only when you must; prefer referencing
  records you already hold.
- System property keys are prefixed too: `gs.getProperty(gs.getCurrentScopeName() + '.maintenance_message')`.
  `MaintenanceManager._scope()` / `_getProp()` are the canonical helpers — see
  [`scripts/script-includes/MaintenanceManager.js`](scripts/script-includes/MaintenanceManager.js).

## 2. Three ways to create artifacts — pick deliberately

| Mechanism | Use when | Pattern source |
|---|---|---|
| **Operations Intelligence Engine** (`record.insert` / `record.upsert` with `"platform": true`) | Building from this session or any external orchestrator — **the preferred path** | [`engine-api-guide.md`](engine-api-guide.md) |
| **Background script + GlideRecord** | One-time in-instance setup (tables, keys, scope registration) | [`scripts/background/04_build_maintenance.js`](scripts/background/04_build_maintenance.js) |
| **Engine `script.run`** | Edge cases that have no dedicated Engine operation | use sparingly |

The Engine is the correct default for all Script Includes, business rules, properties,
notifications, widgets, and ACLs. Background scripts are reserved for bootstrapping
steps that must run before the Engine exists.

## 3. Idempotency: the `createOrSkip` pattern (background scripts)

Background scripts that build artifacts must be safe to re-run. Never blind-insert.
Query first; insert only if absent:

```javascript
function createOrSkip(table, queryFn, insertFn, label) {
    var gr = new GlideRecord(table);
    queryFn(gr);
    gr.setLimit(1);
    gr.query();
    if (gr.next()) { /* already exists — skip */ return gr.getUniqueValue(); }
    var newGr = new GlideRecord(table);
    newGr.initialize();
    insertFn(newGr);
    return newGr.insert();
}
```

The Engine equivalent is `record.upsert` — it queries, updates if found, inserts if
not. Prefer `record.upsert` over `record.insert` for all platform artifact creation
via the Engine so builds are repeatable.

## 4. Scope guard at the top of every background script (Application scope)

A background script that builds scoped artifacts must refuse to run in global scope:

```javascript
var scope = gs.getCurrentScopeName();
if (!scope || scope === 'global') {
    gs.info('ERROR: Switch to your Operations Intelligence scope first.');
    return;
}
```

Use `gs.info()` in Application scope scripts (not `gs.print()`, which is blocked in
scoped context).

## 5. Client-callable Script Includes: the `AbstractAjaxProcessor` pattern

Any Script Include called from a widget client controller via GlideAjax extends
`AbstractAjaxProcessor`. `MaintenanceManager` is the reference implementation. Rules:

- `Class.create()` + `Object.extendsObject(AbstractAjaxProcessor, { ... })`.
- Record settings: **Client callable = true**, **Access = public**, **Active = true**,
  `api_name = {scope}.Name`.
- **Two surfaces, one logic.** Public `ajaxXxx()` methods are the GlideAjax entry
  points; they read params with `this.getParameter('sysparm_x')`, enforce
  authorisation, then delegate to private `_xxx()` methods. The same `_xxx()` methods
  are also exposed through plain server-side methods so other Script Includes can call
  the logic directly without going through AJAX.
- **Authorise inside every mutating `ajax` method**, never assume the caller is
  trusted: `if (!gs.hasRole('admin')) { return JSON.stringify({ error: 'Unauthorized' }); }`.
- Return strings: booleans as `'' + value`, objects as `JSON.stringify(obj)`.
- End with `type: 'Name'`.

## 6. Embedding a Script Include inside a background script (Rhino)

When a background script *creates* a Script Include record, the `script` field is a
string. Build it as a line array joined with `\n` so it is readable and quote-safe:

```javascript
var siCode = [
    "var MyService = Class.create();",
    "MyService.prototype = {",
    "    initialize: function() {},",
    "    type: 'MyService'",
    "};"
].join('\n');
```

This is why `MaintenanceManager` exists in two forms (a readable `.js` file and the
embedded array inside `04_build_maintenance.js`). The maintenance protocol requires
both to be updated together.

## 7. Service Portal widget structure

Every widget is four parts, kept as four files under
[`scripts/widgets/<id>/`](scripts/widgets/):

| File | Field on `sp_widget` | Pattern |
|---|---|---|
| `template.html` | `template` | AngularJS bindings `{{c.data.x}}`, `ng-if`, `ng-repeat`. SVG illustrations are inline — no external image URLs. |
| `server-script.js` | `script` | `(function(){ ... })()`; reads `options`, role-gates with `gs.hasRole()`, populates the `data` object, may call Script Includes directly. |
| `client-script.js` | `client_script` | `function($scope, ...) { var c = this; ... }`; `c` is the controller; talks to the server via GlideAjax. |
| `style.css` | `css` | Widget-scoped class names prefixed `oi-`. |

The two maintenance widgets are the reference. Match their conventions: controller
alias `c = this`, GlideAjax through a single `_ajax(method, params, cb)` helper,
`$scope.$apply()` (guarded by `if (!$scope.$$phase)`) after async updates, and
`$interval`/`$timeout` cleaned up on `$destroy`.

## 8. GlideAjax call convention (client → Script Include)

```javascript
var ga = new GlideAjax('MaintenanceManager');     // Script Include name
ga.addParam('sysparm_name', 'ajaxGetStatus');     // the ajax method
ga.addParam('sysparm_section', sectionId);        // extra params as sysparm_*
ga.getXMLAnswer(function(answer) {
    var res = JSON.parse(answer);
    // ... update c.*, then $scope.$apply() if needed
});
```

## 9. Security conventions (always)

- **Never return or log a secret.** `creator_credential.github_pat` is read-blocked
  for everyone including admin; `CopilotBridge` reads it via an elevated GlideRecord
  and passes it straight to the outbound call. Do not add a code path that returns it.
- **Never hardcode credentials** in automation step `configuration` JSON — use
  execution context variables or a ServiceNow Connection & Credential alias.
- **Authorise server-side**, not just by hiding UI. Widget server scripts role-gate
  with `gs.hasRole()` and return early for unauthorised users; the matching `ajax`
  methods re-check the role.
- **Audit privileged actions.** Admin actions that bypass normal role checks are
  logged via `AuditService`.
- The Engine key and the `svc_operations_intelligence_api` password live in system
  properties (`x_infte_ops_int.engine_key`, `x_infte_ops_int.svc_password`). They are
  **never written to source files, logs, or this repository**.

## 10. Template variables in automation steps

`ExecutionEngine` resolves `{{input.X}}`, `{{context.X}}`, and `{{steps.N.output.X}}`
in step `configuration` JSON before each step runs. An unresolvable variable is a
**step error**, never a silent empty value. The full variable catalogue and the
per-action configuration schemas are in the architecture (*Execution Context
Variables*, *Automation Step Action Types*). When you author a step, reference those
schemas exactly.

## 11. `getFields()` is blocked in scoped context

In the `x_infte_ops_int` scope, calling `gr.getFields()` on a GlideRecord throws
`MethodNotAllowedException`. Enumerate fields instead via `sys_dictionary`:

```javascript
function tableFields(table) {
    var fields = [];
    var dict = new GlideRecord('sys_dictionary');
    dict.addQuery('name', table);
    dict.addQuery('internal_type', '!=', 'collection');
    dict.query();
    while (dict.next()) {
        var el = dict.getValue('element');
        if (el) fields.push(el);
    }
    return fields;
}
```

The Engine uses this pattern internally in `grToObj` with a per-request `_fieldCache`.
