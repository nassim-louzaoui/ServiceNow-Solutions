# Recipe — Add a Custom Table

This recipe adds a scoped custom table with fields. It is the same work `TableBuilder`
does when a creator's approved `custom_table` deliverable is built — so use it both
for platform tables (the 19 core tables) and to understand the deliverable path.

> **Governance note:** a creator-requested `custom_table` is a *deliverable* and
> requires leadership approval before TableBuilder runs (architecture: *Deliverable
> Types & Governance*). This recipe is the mechanical build that happens **after**
> approval, or when an engineer adds a platform table during the build sequence.

## 1. Create the table record

POST to `sys_db_object` (REST) or insert via GlideRecord (background script):

| Field | Value |
|---|---|
| `name` | `x_infte_ops_int_<table>` (scope prefix + base name) |
| `label` | Human label, e.g. `Managed Artifact` |
| `super_class` | sys_id of a parent table to extend, or leave empty for a base table |
| `sys_scope` | Operations Intelligence app sys_id |

ServiceNow provisions the physical table and a collection dictionary row.

## 2. Add each field

POST one `sys_dictionary` row per column:

| Field | Value |
|---|---|
| `name` | the table name (`x_infte_ops_int_<table>`) |
| `element` | the column key, e.g. `display_name` |
| `column_label` | the column label, e.g. `Display Name` |
| `internal_type` | the field type — see table below |
| `mandatory` | `true` / `false` |
| `reference` | (reference fields only) target table name |
| `max_length` | optional, for strings |
| `choice` / `choice_table` | for choice fields |

Common `internal_type` values used across OI:

| Need | `internal_type` |
|---|---|
| Short/long text | `string` |
| Whole number | `integer` |
| True/false | `boolean` |
| Date + time | `glide_date_time` |
| Reference to another record | `reference` (+ `reference` = target table) |
| Fixed option list | `choice` |
| Encrypted secret | `password2` (e.g. `creator_credential.github_pat`) |
| JSON blob | `string` with large `max_length` (OI stores JSON in string fields, e.g. `creation_spec`, `structured_spec`, `snapshot_steps`) |

## 3. Apply ACLs

Tables carry table-, row-, and field-level ACLs. Use the exact rules in the
architecture's *Security & Access Control* section for any of the 19 core tables. For
a new table, follow the same shape: row-scope to membership/role, restrict sensitive
fields at field level. Two rules are non-negotiable where they apply:

- A secret field (like `github_pat`) gets a **field read ACL that denies everyone**,
  including admin; only a privileged Script Include reads it without returning it.
- Internal pointer fields (like `artifact_sys_ids`) are **admin + System read only**.

## 4. Default views

Add a form layout and list view (default `sys_ui_section` / list columns) so the table
is usable. `TableBuilder` does this automatically for deliverable tables.

## 5. Finish

- Add the table to the architecture's *Data Model* with every field documented, and to
  the *Build Order* table list if it is a permanent platform table.
- Add it to the `tables` array in
  [`../scripts/background/02_verify_implementation.js`](../scripts/background/02_verify_implementation.js)
  so verification covers it.
- Follow the [maintenance protocol](../../maintenance/self-maintenance-protocol.md).
