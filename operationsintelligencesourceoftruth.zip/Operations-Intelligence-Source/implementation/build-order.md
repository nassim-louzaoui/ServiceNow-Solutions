# Build Order — Operational Run Sheet

This is the operational run sheet: the manual prerequisites, the background scripts,
and the Engine-driven build sequence. The complete, authoritative 15-step build
sequence — with every table name, the Script Include dependency chain, and the
end-to-end test checklist — lives in
[`../architecture/solution-architecture.md`](../architecture/solution-architecture.md)
under **Build Order**. This file is the checklist you keep open while doing it.

## Pre-build (manual, in ServiceNow Studio)

1. Create the scoped application in Studio. Scope: **`x_infte_ops_int`**.
2. Create the four application roles: `admin`, `leadership`, `creator`, `user`.
   ServiceNow prefixes them with the scope automatically.
3. Create the `svc_operations_intelligence_api` service account via
   `sys_user` and assign it the `admin` role.
4. Confirm the scope picker (top-right banner) shows **Operations Intelligence**,
   not **Global**. Every artifact must be created while this scope is active.

## Background scripts — in order

Run from **System Definition → Scripts - Background**, in the scope and order shown.

| Script | Scope | When | What it does |
|---|---|---|---|
| [`scripts/background/01_global_cleanup.js`](scripts/background/01_global_cleanup.js) | **Global** | First | Deletes any leftover orphan test tables from previous sessions |
| [`scripts/background/02_engine_setup.js`](scripts/background/02_engine_setup.js) | **Application** (`x_infte_ops_int`) | After 01 | Creates the `EngineRouter` Scripted REST API resource and confirms scope |
| [`scripts/background/02a_generate_engine_key.js`](scripts/background/02a_generate_engine_key.js) | **Application** | After 02 | Generates a 40-character random engine key and writes it to `x_infte_ops_int.engine_key` — **capture the printed key** |
| [`scripts/background/02b_engine_operation_script.js`](scripts/background/02b_engine_operation_script.js) | — | — | **Paste this entire file** into Studio → Engine Router → Script field. This is the 35-op engine body. |
| [`scripts/background/02c_set_svc_account_password.js`](scripts/background/02c_set_svc_account_password.js) | **Application** | After key captured | Stores the `svc_operations_intelligence_api` password in `x_infte_ops_int.svc_password` |
| [`scripts/background/02d_grant_svc_account_roles.js`](scripts/background/02d_grant_svc_account_roles.js) | **Global** | After 02c | Grants `admin` + `snc_internal` + `web_service_admin` to the service account |
| [`scripts/background/03a_cleanup_orphan_tables.js`](scripts/background/03a_cleanup_orphan_tables.js) | **Global** | If needed | Deletes any known orphan tables by sys_id |
| [`scripts/background/03_create_tables.js`](scripts/background/03_create_tables.js) | **Application** | After engine is live | Creates all 19 custom tables with fields and auto-numbers |
| [`scripts/background/03_setup_update_sets.js`](scripts/background/03_setup_update_sets.js) | **Application** | After 03 | Creates and activates the **Operations Intelligence v1.0.0** update set |
| [`scripts/background/04_build_maintenance.js`](scripts/background/04_build_maintenance.js) | **Application** | At build step 15 | Creates the 5 `maintenance_*` properties, `MaintenanceManager` Script Include, and both maintenance widgets |
| [`scripts/background/02_verify_implementation.js`](scripts/background/02_verify_implementation.js) | **Application** | After each major step | Verifies tables, Script Includes, properties, business rules, notifications, VA, portal |

## Engine self-test

After the engine is live and `x_infte_ops_int.svc_password` is set, call `selftest`
to verify the full capability matrix:

```
POST {instance}/api/x_infte_ops_int/engine/v1
X-Engine-Key: {engine_key}
{ "op": "selftest" }
```

All six sub-tests must pass: auth, scoped-read, scoped-write, platform-write,
platform-read, platform-delete. Any failure indicates a missing property, role, or
ACL.

## Engine-driven build (after self-test passes)

All remaining platform artifacts (Script Includes, business rules, properties,
notifications, VA topics, portal records, widgets, ACLs) are built by calling the
Engine. See [`engine-api-guide.md`](engine-api-guide.md) for the full operation
reference. The recommended build order mirrors the dependency chain in the
architecture canon:

1. System properties (15 total)
2. Script Includes in dependency order (21 total — see architecture *Script Includes*)
3. Business rules (5)
4. Notifications (22)
5. Scheduled jobs (5)
6. NLU model + VA channel + 23 topics
7. Portal + pages + widgets (20 custom widgets)
8. ACLs

For each artifact: call the Engine to create it, then `record.get` or `table.exists`
to verify, then update the architecture canon and this repository.

## Do not proceed past pre-build until

- `02a_generate_engine_key.js` output is captured (the engine key).
- Engine `selftest` returns all passing.
- The scope picker still shows **Operations Intelligence**.

## Migration

Promotion from dev → test → prod is covered in the architecture document under
**Update Set & Migration Strategy**. The NLU model must be retrained on each
environment after import. Do not duplicate those steps here — follow them from the
canon so there is only one copy to keep correct.
