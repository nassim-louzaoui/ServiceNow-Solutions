# Implementation — Verbatim, Deployable Artifact Source

This folder holds the **exact source** of the artifacts that make up Operations
Intelligence. Every script file here is byte-for-byte what is deployed in ServiceNow.
It is not a description of the code — it *is* the code. The architecture document
explains what these artifacts do and how they fit together; this folder is the ground
truth for their content.

> **Invariant:** the files in `scripts/` must always match both the live ServiceNow
> instance and the specification in
> [`../architecture/solution-architecture.md`](../architecture/solution-architecture.md).
> If one changes, the others change in the same commit
> (see [`../maintenance/self-maintenance-protocol.md`](../maintenance/self-maintenance-protocol.md)).

## What is in this folder

| File / folder | Role |
|---|---|
| [`build-order.md`](build-order.md) | Operational run sheet: prerequisites and the background scripts, in order |
| [`coding-patterns.md`](coding-patterns.md) | The canonical patterns every artifact follows — read before you build or extend anything |
| [`engine-api-guide.md`](engine-api-guide.md) | The 35-operation Engine API: request shapes, all operations, common patterns |
| [`recipes/`](recipes/) | Step-by-step procedures for adding one artifact of each kind |
| [`scripts/`](scripts/) | Verbatim, deployable source (background scripts, Script Includes, widgets) |

## Layout

```
implementation/
  build-order.md                         How to deploy, prerequisites, and background script order
  coding-patterns.md                     Canonical patterns & conventions
  engine-api-guide.md                    Complete Engine API reference (35 ops)
  recipes/                               One procedure per artifact kind
    add-a-script-include.md  add-a-custom-table.md  add-a-service-portal-widget.md
    add-a-notification.md    add-a-va-topic.md
  scripts/
    background/                          Run in ServiceNow > Scripts - Background
      01_global_cleanup.js               Global scope — removes orphan test tables
      02_engine_setup.js                 App scope — creates EngineRouter Scripted REST resource
      02a_generate_engine_key.js         App scope — generates + stores engine key
      02b_engine_operation_script.js     Paste into Studio → Engine Router → Script field
      02c_set_svc_account_password.js    App scope — stores svc account password in property
      02d_grant_svc_account_roles.js     Global scope — grants roles to service account
      02_verify_implementation.js        App scope — verifies every artifact group
      03_create_tables.js                App scope — creates all 19 custom tables
      03_setup_update_sets.js            App scope — creates + activates update set
      03a_cleanup_orphan_tables.js       Global scope — deletes known orphan tables by sys_id
      04_build_maintenance.js            App scope — builds MaintenanceManager + widgets + props
    script-includes/
      MaintenanceManager.js              Readable canonical source of the maintenance Script Include
    widgets/
      oi-maintenance-overlay/            Shown in place of a section when it is in maintenance
        template.html  client-script.js  server-script.js  style.css
      oi-maintenance-control-panel/      Admin control surface in the Command section
        template.html  client-script.js  server-script.js  style.css
```

## What is here versus what is in the architecture

This folder contains the artifacts that are fully realised as standalone, portable
source: the background scripts, the Operations Intelligence Engine operation script,
the `MaintenanceManager` Script Include, and the two maintenance widgets.

The remaining platform artifacts — the other 20 Script Includes, the 5 business rules,
the 22 notifications, the 23 Virtual Agent topics, the portal and its other widgets —
are fully specified in the architecture canon. They are built through the Engine using
`record.insert`/`record.upsert` with `"platform": true`. As any of them is extracted
to standalone source, it is added here under the matching `scripts/` subfolder, and
this README's layout is updated to list it.

## Two representations of MaintenanceManager — both correct, on purpose

`MaintenanceManager` appears twice and they must stay semantically identical:

1. `scripts/script-includes/MaintenanceManager.js` — the **readable** canonical
   source, formatted for humans and AI to read and reason about.
2. Inside `scripts/background/04_build_maintenance.js` — the **same logic** as a
   line-array string (`[...].join('\n')`), because the build script writes the
   Script Include record through a background script where the Rhino engine needs
   the body as a string literal.

When the maintenance logic changes, update **both**. The readable file is the source
of truth for the logic; the build script is how that logic is installed.
