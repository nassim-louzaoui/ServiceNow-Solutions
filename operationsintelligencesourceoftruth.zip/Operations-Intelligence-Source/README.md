# Operations Intelligence — Source of Truth

This repository is the **single source of truth** for the Operations Intelligence
platform: an enterprise intelligent-automation and deliverable system, built as a
ServiceNow scoped application, that lets Infosys operations teams create, govern,
and run automations and ServiceNow deliverables entirely through natural language.

It is not a document dump. It is a structured, self-maintaining knowledge system.
Every folder has a defined role, the files reference one another instead of
repeating content, and an `.github/copilot-instructions.md` file teaches any AI
working in this repository how to read it, build from it, generate deliverables
from it, and keep it current.

---

## The System at a Glance

| Folder | Role | Read this when you need… |
|---|---|---|
| [`context/`](context/) | **Why** the platform exists — problem, value, future state, solution | Business narrative for any audience |
| [`architecture/`](architecture/) | **What** the platform is — the complete technical canon | Any technical detail: tables, Script Includes, ACLs, VA, build order |
| [`implementation/`](implementation/) | **How** it is built — verbatim source, coding patterns, Engine API mechanics, recipes | The exact code, the patterns, and how to add any artifact |
| [`ai-delivery/`](ai-delivery/) | **Produce** — logic and worked deliverables generated from the canon | To create a presentation, overview, or briefing |
| [`ai-guide/`](ai-guide/) | **Operate** — how an AI should reason and act in this repo | To know how to handle any request: explain, build, generate, change |
| [`reference/`](reference/) | **Look up** — glossary of exact terms and identifiers | The one correct spelling of a name or term |
| [`maintenance/`](maintenance/) | **Sustain** — the protocol that keeps this repo true | Whenever the platform changes |
| [`.github/`](.github/copilot-instructions.md) | **Onboard AI** — auto-loaded Copilot instructions | Automatically, every Copilot session |

---

## The Two Canons

Everything else is derived from two authoritative sources. When they disagree with
any other file, they win.

1. **Business canon** — [`context/`](context/). The problem, the value, the future
   state, and the solution, written once, in depth.
2. **Technical canon** — [`architecture/solution-architecture.md`](architecture/solution-architecture.md).
   The complete specification of the platform: 19 tables, 21 Script Includes,
   5 business rules, 22 notifications, 23 Virtual Agent topics, the portal, every
   widget, the full ACL model, the Operations Intelligence Engine, maintenance mode,
   and the build and migration sequence.

Derived material (`ai-delivery/`, folder READMEs, `.github/copilot-instructions.md`)
**transforms** the canon for a specific audience or purpose. It never restates it
for its own sake. If you find yourself copying a paragraph from a canon into a
derived file, link to the canon instead.

---

## How to Navigate

- **An AI starting work here?** Read
  [`ai-guide/operating-guide.md`](ai-guide/operating-guide.md) — it routes every kind
  of request (explain, build, generate, change) to the right canon and procedure.
- **New to the platform?** Read [`context/`](context/) front to back (four short
  files), then skim [`architecture/`](architecture/README.md).
- **Building or extending it?** Start at
  [`implementation/build-order.md`](implementation/build-order.md) and
  [`implementation/coding-patterns.md`](implementation/coding-patterns.md), use the
  matching [`implementation/recipes/`](implementation/recipes/), keep
  [`architecture/solution-architecture.md`](architecture/solution-architecture.md)
  open beside you.
- **Calling the Engine to build something?** Go to
  [`implementation/engine-api-guide.md`](implementation/engine-api-guide.md).
- **Producing a deliverable?** Go to [`ai-delivery/`](ai-delivery/README.md).
- **Need the exact name of something?** [`reference/glossary.md`](reference/glossary.md).
- **You changed the platform?** Follow
  [`maintenance/self-maintenance-protocol.md`](maintenance/self-maintenance-protocol.md).

---

## No Version History in Content

This repository carries **no changelog and no version history inside any file**.
Each file states the platform as it is *now*. Change tracking is the job of git
history, not of prose. The maintenance protocol exists precisely so that "now" in
this repository always equals "now" in the live ServiceNow application.
