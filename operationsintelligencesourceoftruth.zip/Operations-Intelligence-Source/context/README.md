# Context — The Business Canon

This folder is the authoritative business narrative for Operations Intelligence.
It answers *why the platform exists* and *what it is for*, independent of how it is
built. The technical canon lives in
[`../architecture/solution-architecture.md`](../architecture/solution-architecture.md);
this folder never duplicates implementation detail.

Read the four files in order — they form a single argument:

| File | Answers |
|---|---|
| [`01-problem-statement.md`](01-problem-statement.md) | What is wrong today, and why it costs the organisation |
| [`02-business-value.md`](02-business-value.md) | What value is unlocked by fixing it |
| [`03-desired-future-state.md`](03-desired-future-state.md) | What "good" looks like once it is fixed |
| [`04-proposed-solution.md`](04-proposed-solution.md) | How Operations Intelligence delivers that future state |

Any business-facing deliverable (executive presentation, solution overview) draws
its non-technical content from these four files. See
[`../ai-delivery/`](../ai-delivery/README.md).
