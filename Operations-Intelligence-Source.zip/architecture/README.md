# Architecture

One file: `solution-architecture.md`. The complete technical specification of
Operations Intelligence — 19 tables, 21 Script Includes, 5 business rules,
22 notifications, 23 Virtual Agent topics, portal, widgets, full ACL model,
Copilot integration contract, maintenance mode, build order, and migration sequence.

**This file is the highest-authority technical source.** When any other file
contradicts it, the other file is wrong. Open this file before guessing at any
technical detail.
