# Context

The business canon. Five files that together answer: what problem does Operations
Intelligence solve, what value does solving it produce, what does working life look
like after, how does the platform deliver that, and what are the live operational
details needed to connect to it?

Read in order. Every business claim in derived material traces to one of these files.

| File | Contents |
|---|---|
| `01-problem-statement.md` | The four structural problems operations teams face |
| `02-business-value.md` | The value each problem's removal produces |
| `03-desired-future-state.md` | What working life looks like once the platform is in place |
| `04-proposed-solution.md` | How Operations Intelligence delivers the future state |
| `05-system-context.md` | Live instance URL, credentials, engine endpoint, deployment mechanism, non-negotiable standards |
