# AI Guide — Operations Intelligence Source

You are an AI working on the Operations Intelligence platform. Read this file in
full before acting on any request. It defines what the system is, how the source
is organised, what authority each part holds, and exactly how to handle every kind
of request.

`.github/copilot-instructions.md` is loaded automatically every session and covers
the same facts in brief. This file is the depth behind it.

---

## 1. What Operations Intelligence Is

Operations Intelligence is a ServiceNow scoped application (`x_infte_ops_int`) that
lets Infosys operations teams create, govern, and execute process automations and
persistent ServiceNow deliverables entirely through natural language, via a dedicated
Virtual Agent called the **Operations Assistant**. GitHub Copilot generates
specifications when a user cannot supply a technical detail; the user confirms.
Role-appropriate approval workflows govern impactful changes. Everything lives at one
portal: `/operations_intelligence`.

The platform has two creative tracks:

- **Automations** — multi-step sequences that run on demand or on schedule
- **Deliverables** — durable ServiceNow artifacts (reports, dashboards, notification
  rules, scheduled data jobs, flows, custom tables, UI pages)

Both are created in natural language, Copilot-enhanced, and governed by the same role
and approval model.

---

## 2. The Authority Order

When any two files disagree, the higher authority is correct. The lower file is wrong
and must be corrected before you finish.

| Priority | File / Folder | Governs |
|---|---|---|
| 1 | `architecture/solution-architecture.md` | All technical facts |
| 2 | `context/` (all five files) | All business facts; live credentials and identifiers |
| 3 | `implementation/` | Verbatim artifact source and implementation documentation |
| 4 | Everything else | Derived; must yield to the above three |

---

## 3. How This Source Is Organised

### context/ — Business Canon and System Identity

| File | Contents |
|---|---|
| `01-problem-statement.md` | The four structural problems operations teams face |
| `02-business-value.md` | The value each problem's removal produces |
| `03-desired-future-state.md` | What working life looks like once the platform is in place |
| `04-proposed-solution.md` | How Operations Intelligence delivers the future state |
| `05-system-context.md` | Live instance URL, credentials, engine endpoint, deployment mechanism, non-negotiable standards |

### architecture/ — Technical Canon

One file: `solution-architecture.md`. The complete specification: 19 tables,
21 Script Includes, 5 business rules, 22 notifications, 23 VA topics, portal,
widgets, full ACL model, Copilot integration, maintenance mode, build sequence.
**When in doubt, open this file. Do not guess.**

### implementation/documentation/ — How It Is Built

- `build-order.md` — prerequisites and deploy sequence
- `coding-patterns.md` — ES5 rules, scope discipline, idempotency, widget structure, security, engine script rules
- `engine-reference.md` — the engine REST API: all 117 operations with complete input/output specifications, engine internals, and critical constraints
- `outbound-integration-guide.md` — Table API mechanics for direct ServiceNow REST calls without the engine
- `recipes/` — step-by-step procedures for each artifact type

### implementation/source/ — Verbatim Deployed Code

- `engine/operation-script.js` — the engine operation script (ground truth; 2,407 lines)
- `script-includes/MaintenanceManager.js` — the maintenance Script Include
- `background/02_verify_implementation.js` — verifies all platform artifacts
- `background/04_build_maintenance.js` — builds maintenance properties and widgets
- `widgets/maintenance-overlay/` — four files (template, server, client, style)
- `widgets/maintenance-control-panel/` — four files

### reference/glossary.md — Quick Lookup

The one correct spelling for every term, role, and identifier. Use these exactly
in all code, documentation, and deliverables.

### generated-deliverables/ — Generating Deliverables

`generation-logic.md` — procedure for producing audience-appropriate deliverables.
`deliverables/` — three complete reference deliverables (executive, user-facing, technical).

### operating-procedures/operating-guide.md — Operating Procedures

Step-by-step procedures for each request type (explain, build, generate, change),
plus the rules that bind all of them.

### maintenance/self-maintenance-protocol.md — Keeping It True

What must move together when the platform changes, the invariants to protect,
and the definition of done.

---

## 4. Classify the Request

| Kind | Examples | Procedure |
|---|---|---|
| **Explain / answer** | "How does X work?", "What is Y?" | §A |
| **Build / implement** | "Add a widget", "create the table", "build Z" | §B |
| **Generate a deliverable** | "Make a presentation / overview / briefing" | §C |
| **Change the platform** | "Fix X", "change Y", "add operation Z to engine" | §D |

---

## §A — Explain or Answer

1. Find the authoritative source: technical → `architecture/solution-architecture.md`;
   business → `context/01–04`; credentials/identifiers → `context/05-system-context.md`;
   a term → `reference/glossary.md`.
2. Answer from the canon. If your memory and the canon disagree, the canon is right.
3. Quote exact identifiers from `reference/glossary.md`.
4. Cite the source file and section so the human can verify.
5. If the canon does not cover it, say so. Do not invent.

## §B — Build or Implement

1. Confirm where it fits: `implementation/documentation/build-order.md` and the
   Script Include dependency order in the architecture.
2. Confirm the mechanism:
   - Engine operation (preferred for remote builds) → `implementation/documentation/engine-reference.md`
   - In-instance background script + GlideRecord → `implementation/documentation/coding-patterns.md`
   - Table API directly → `implementation/documentation/outbound-integration-guide.md`
3. Follow coding patterns: `implementation/documentation/coding-patterns.md`. ES5 only
   in any Rhino-executed code. No backticks, no `let`/`const`, no arrow functions,
   no destructuring, no `eval()`.
4. Use the matching recipe: `implementation/documentation/recipes/`.
5. Use verbatim source from `implementation/source/`. Never paraphrase code.
6. Verify: run `implementation/source/background/02_verify_implementation.js` including
   the two security assertions.
7. Record the change per §D.

## §C — Generate a Deliverable

1. Read `generated-deliverables/generation-logic.md` in full.
2. Classify the audience and intent. Map to source sections.
3. If a reference deliverable in `generated-deliverables/deliverables/` matches, adapt it.
4. No placeholders. No invented metrics. Every claim traces to the canon.
5. Verify against the generation-logic checklist before delivering.

## §D — Change the Platform (and Keep This Source True)

1. Make the platform change in ServiceNow.
2. Follow `maintenance/self-maintenance-protocol.md` exactly:
   - Update `architecture/solution-architecture.md`
   - Update verbatim source in `implementation/source/` — both copies of maintenance
     logic (MaintenanceManager.js AND the embedded copy in 04_build_maintenance.js)
   - Update `context/` if rationale or scope moved
   - Regenerate affected deliverables in `generated-deliverables/deliverables/`
   - Update structural files only if the system's shape or rules changed
3. Never add a changelog, dated note, or version annotation to any file. Edit files
   so they state the new current truth.
4. Self-check against the authority order. If two files now disagree, fix the lower
   before finishing.
5. Done when: live instance, architecture, implementation source, and business canon
   all tell the same story — no file contradicts a higher-authority file.

---

## 5. Non-Negotiable Technical Facts

Getting these wrong produces an incorrect or insecure result.

**Scope prefix:** `x_infte_ops_int`. Custom tables: `x_infte_ops_int_<name>`.
Architecture writes unprefixed names for readability; real code always uses the full prefix.

**Service account:** `svc_operations_intelligence_api`. Sys ID: `94a5973dfb6dcb5052eef5c9beefdc77`.
Never rename or abbreviate.

**Engine:** `POST /api/x_infte_ops_int/ops_int_engine/v1`. Authentication: `X-Engine-Key`
header matching `x_infte_ops_int.engine_key` property. 117 operations. The sole
remote build and management interface.

**Platform writes:** The engine uses `x_infte_ops_int.svc_password` property to make
internal REST calls as `svc_operations_intelligence_api`. Add `"platform": true` to
any record operation to bypass the scoped sandbox.

**Update set:** The engine maintains exactly one update set named "Operations
Intelligence". Created on first configuration write, never duplicated.
`engine.status` returns its sys_id and state.

**ES5 only** in any Rhino-executed script (engine, Script Includes, background scripts).
No backticks, no `let`/`const`, no arrow functions, no destructuring, no `eval()`.
Template literals cause a Rhino parse error at load time that silently disables the
entire engine with no error message.

**Engine script header:** The formal header block at the top of the operation script
covers exactly four things — scope identity, endpoint, authentication, and the
operation catalog. Nothing else. No deployment instructions. No operator guidance.
No onboarding steps. No human-addressed content of any kind.

**Engine script body:** No `//` inline comments anywhere in the function body.

**`script.run` constraint:** GlideScopedEvaluator requires a real GlideRecord — passing
`null` as the first argument causes silent failure (returns null). The engine loads
its own `sys_ws_operation` record in-memory, sets `operation_script` to the wrapped
user script, and calls `evaluateScript(gr, 'operation_script', null)`. This is the
only working approach. See `implementation/documentation/engine-reference.md` §script.run.

**`engine.selfupdate` safety check:** The incoming script must contain both
`X-Engine-Key` and `function dispatch`. The engine rejects it if either is absent.

**`engineOperationId()` lookup:** Primary path queries `sys_ws_operation` by scope
(`sys_scope.scope=x_infte_ops_int`) and service name. Fallback queries by operation
name alone. Never query by name alone as the primary path.

**`creator_credential.github_pat`** — Read ACL = NOBODY, including admin. Never add
a code path that returns it.

**`managed_artifact.artifact_sys_ids`** — readable by admin and System only.

**Approval escalation** updates the existing `pending_action` record. It never creates
a second one.

**`sysauto_script`** is used only by `ScheduleManager` for automation scheduling.
Scheduled data jobs use `sysauto_report`. Never build a scheduled data job as a
`sysauto_script`.

**No AI identity** in any artifact name, property, Script Include, table name, role
name, or any configuration record.

**Naming** — every artifact name, role, update set, table label, notification name,
and description must be proper title case with full words and no abbreviations.
"Operations Intelligence", never "OI". "Script Include", never "SI". API identifiers
follow ServiceNow conventions; display names never use abbreviations.

---

## 6. Rules That Bind Every Request

- **Accuracy of names is non-negotiable.** Use `reference/glossary.md` for every
  identifier, role name, table name, and widget id. One wrong character breaks things.
- **Say each thing once.** Each fact has one home. Other files link to it. Do not
  copy a paragraph from a canon into another file — link instead.
- **Prefer the verbatim artifact.** `implementation/source/` is ground truth.
  Your recollection of what the code looks like is not.
- **When unsure, read — do not guess.** The answer is almost always in
  `architecture/` or `context/`. Open the file.
- **No history inside content.** Edit files so they state the current truth.
  Git history is the record of what changed.
- **Formal and precise in all content.** No casual language in names, descriptions,
  labels, or documentation. No filler. No unnecessary commentary.
