# Operations Intelligence — Instructions for AI Working in This System

You are working inside the single source of truth for the Operations Intelligence
platform. This file is loaded automatically every session. Read it fully before
acting. For detailed operating procedures, read `../System-Guide.md`.

---

## 1. What the Platform Is

Operations Intelligence is a ServiceNow scoped application (`x_infte_ops_int`) that
lets Infosys operations teams create, govern, and execute process automations and
persistent ServiceNow deliverables entirely through natural language, via a dedicated
Virtual Agent called the Operations Assistant. Role-appropriate approval workflows
govern impactful changes. Everything lives at one portal: `/operations_intelligence`.

---

## 2. The Authority Order

1. `architecture/solution-architecture.md` — all technical facts
2. `context/` (all five files) — all business facts; live credentials and identifiers
3. `implementation/` — verbatim artifact source; must match architecture and instance
4. Everything else — derived; yields to the above

If two files disagree, the higher authority is correct. The lower file is wrong.

---

## 3. Structure Index

| Path | Role |
|---|---|
| `System-Guide.md` | Comprehensive AI operating instructions — read first |
| `context/05-system-context.md` | Live credentials, instance URL, engine endpoint, deployment |
| `architecture/solution-architecture.md` | Complete technical specification |
| `implementation/documentation/engine-reference.md` | All 117 engine operations — complete input/output specs and engine internals |
| `implementation/documentation/coding-patterns.md` | Build patterns, ES5 rules, engine script rules |
| `implementation/documentation/outbound-integration-guide.md` | Table API mechanics |
| `implementation/documentation/recipes/` | Step-by-step artifact procedures |
| `implementation/source/` | Verbatim deployed code: engine, Script Includes, widgets |
| `reference/glossary.md` | Canonical spelling of every term and identifier |
| `maintenance/self-maintenance-protocol.md` | How to keep this source current |
| `operating-procedures/operating-guide.md` | Step-by-step procedures for each request type |
| `generated-deliverables/` | Logic and worked deliverables for presentations and briefings |

---

## 4. Non-Negotiable Technical Facts

- Scope prefix: `x_infte_ops_int`. Tables: `x_infte_ops_int_<name>`.
- Service account: `svc_operations_intelligence_api`.
- Engine: `POST /api/x_infte_ops_int/ops_int_engine/v1`. Auth: `X-Engine-Key` header.
- Update set: exactly one, named "Operations Intelligence". Never duplicated.
- ES5 only in Rhino-executed scripts. No backticks, `let`/`const`, arrow functions,
  destructuring, or `eval()`. Template literals silently kill the engine.
- Engine script header: covers scope identity, endpoint, auth, and operation catalog
  ONLY. No deployment instructions. No operator guidance. No human-addressed content.
- Engine script body: no `//` inline comments anywhere.
- `script.run` uses GlideScopedEvaluator with a real GlideRecord — null arg causes
  silent failure. See `implementation/documentation/engine-reference.md` §script.run.
- `engine.selfupdate` requires `X-Engine-Key` and `function dispatch` markers in script.
- `creator_credential.github_pat` — Read ACL = NOBODY including admin.
- `managed_artifact.artifact_sys_ids` — admin and System only.
- Approval escalation updates the existing `pending_action` — never creates a second.
- No AI identity in any artifact name, property, Script Include, or configuration.
- Naming: proper title case, full words, no abbreviations in all display names.

---

## 5. When the Platform Changes, Change This Source

Follow `maintenance/self-maintenance-protocol.md` exactly. Update the technical canon,
verbatim source, business canon if needed, and affected deliverables — in the same
change. Never add a changelog or dated note. Edit files so they state the new current
truth. Git history is the only history.
