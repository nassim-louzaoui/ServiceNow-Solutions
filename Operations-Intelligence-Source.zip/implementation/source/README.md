# Source

Verbatim deployed code for Operations Intelligence. Every file here is authoritative:
it is (or should be) exactly what is deployed in the `x_infte_ops_int` application
scope on the live instance. When the live instance and a file here disagree, the
instance is the ground truth and this file must be updated.

## Files

| Path | Description |
|---|---|
| `engine/operation-script.js` | The Scripted REST operation script. 2,407 lines. 117 operations. Deploy via `engine.selfupdate` using `update_engine.sh`. |
| `script-includes/MaintenanceManager.js` | The maintenance Script Include in readable form. Must be kept identical to the string-array copy embedded in `background/04_build_maintenance.js`. |
| `background/02_verify_implementation.js` | Verification script. Checks all platform artifacts are present and correctly configured. Run after any build or change. |
| `background/04_build_maintenance.js` | Idempotent build script for maintenance mode: properties, overlay widget, and control panel widget. Safe to re-run. |
| `widgets/maintenance-overlay/` | The maintenance overlay widget (four files). Displayed to all users when maintenance mode is active. |
| `widgets/maintenance-control-panel/` | The maintenance control panel widget (four files). Admin-only — enables and disables maintenance mode. |

## Deployment

- **Engine:** `bash scripts/background-scripts/update_engine.sh` from the repository root.
- **Script Includes, Business Rules, widgets, properties:** use the engine's
  `artifact.*` operations or run the relevant background script inside the instance.
- **Maintenance build:** run `04_build_maintenance.js` as a background script in the
  `x_infte_ops_int` scope. It is idempotent — re-running a completed build produces
  all `[SKIP]` results.

## Verification

After any build, run `02_verify_implementation.js` as a background script. It checks
all platform artifacts and includes two mandatory security assertions:

1. `creator_credential.github_pat` must return empty even for admin.
2. A field-level read ACL must exist on `creator_credential`.
