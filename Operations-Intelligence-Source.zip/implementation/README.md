# Implementation

Two subfolders. Together they answer: how is Operations Intelligence built, and what
is the exact deployed code?

## documentation/

How the platform is built. Patterns, constraints, the engine API reference, REST
mechanics, and step-by-step recipes. Read these before writing any artifact.

| File | Contents |
|---|---|
| `build-order.md` | Prerequisites and deployment sequence |
| `coding-patterns.md` | ES5 rules, scope discipline, idempotency, widget structure, Script Include pattern, engine script rules |
| `engine-api.md` | All 117 engine operations — complete input/output specs, engine internals, critical constraints |
| `rest-api-guide.md` | Table API mechanics for direct ServiceNow REST calls without the engine |
| `recipes/` | Step-by-step procedures: add a custom table, notification, Script Include, widget, VA topic |

## source/

Verbatim deployed code. Every file here is the authoritative version of what is
(or should be) live in the `x_infte_ops_int` application scope.

| Path | What it is |
|---|---|
| `engine/operation-script.js` | The Scripted REST operation script — 2,407 lines, 117 operations |
| `script-includes/MaintenanceManager.js` | Maintenance Script Include (readable form) |
| `background/02_verify_implementation.js` | Verifies all platform artifacts are present and correctly configured |
| `background/04_build_maintenance.js` | Idempotent build script for maintenance properties and widgets |
| `widgets/oi-maintenance-overlay/` | Overlay widget — four files (template, server, client, style) |
| `widgets/oi-maintenance-control-panel/` | Control panel widget — four files |

## Two Representations of MaintenanceManager — Both Correct on Purpose

`MaintenanceManager.js` is a readable JavaScript file. The same logic is also
embedded as a string array in `04_build_maintenance.js` (the `siCode` variable),
which is how a background script creates a Script Include record in ServiceNow.

**These two representations must always be identical.** If you edit one, edit both.
The maintenance protocol enforces this. The source of truth for the logic is
`MaintenanceManager.js`; the string array in `04_build_maintenance.js` is a derived
form of it.
