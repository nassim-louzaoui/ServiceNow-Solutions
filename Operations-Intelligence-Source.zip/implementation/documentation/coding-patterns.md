# Coding Patterns and Conventions

Every artifact in Operations Intelligence follows a small set of patterns. Use them
exactly when building or extending the platform — they are what make the code
consistent, idempotent, and safe.

The verbatim files in `../source/` are the worked examples referenced throughout.
This file covers *how* to write artifacts. *What* to build and in what order is
`build-order.md` and `../../../architecture/solution-architecture.md`.

---

## 1. Scope Prefix Discipline

All custom tables are auto-prefixed with the application scope. The architecture
writes the unprefixed name (`automation`); real code uses the full prefixed name
(`x_infte_ops_int_automation`).

Never hardcode the prefix as a string literal in scoped code. Resolve it at runtime:

```javascript
var scope = gs.getCurrentScopeName(); // returns 'x_infte_ops_int'
var tableName = scope + '_automation';
```

System property keys are also prefixed:
```javascript
gs.getProperty(gs.getCurrentScopeName() + '.maintenance_message');
```

`MaintenanceManager._scope()` and `_getProp()` are the canonical helpers — see
`../source/script-includes/MaintenanceManager.js`. The authoritative scope value
for a given instance is `x_infte_ops_int` (documented in `../../../context/05-system-context.md`).

---

## 2. Two Ways to Create Artifacts — Choose Deliberately

| Mechanism | Use when | Reference |
|---|---|---|
| **Engine API** | Building from outside ServiceNow (remote orchestration) | `engine-api.md` |
| **Background script + GlideRecord** | Building inside the instance, idempotently, with no external tooling | `../source/background/04_build_maintenance.js` |
| **Table API directly** | When the engine is unavailable or a specific Table API feature is needed | `rest-api-guide.md` |

Both the engine and the background-script path create the same records. The
background-script path is the most robust for in-instance work because it runs in
the active scope and is trivially idempotent. The engine is for remote automation.

---

## 3. Idempotency: the createOrSkip Pattern

Build scripts must be safe to re-run. Never blind-insert. Query first; insert only
if absent. The canonical helper from `04_build_maintenance.js`:

```javascript
function createOrSkip(table, queryFn, insertFn, label) {
    var gr = new GlideRecord(table);
    queryFn(gr);
    gr.setLimit(1);
    gr.query();
    if (gr.next()) {
        gs.print('[SKIP] ' + label + ' (' + gr.getUniqueValue() + ')');
        return gr.getUniqueValue();
    }
    var newGr = new GlideRecord(table);
    newGr.initialize();
    insertFn(newGr);
    var id = newGr.insert();
    gs.print(id ? '[OK]   ' + label : '[FAIL] ' + label);
    return id;
}
```

Every build script reports `[OK] / [SKIP] / [FAIL]` per artifact and a summary
count. A re-run of a completed build must produce all `[SKIP]` and zero `[FAIL]`.

The engine's `artifact.*` operations implement this automatically (find-then-upsert).

---

## 4. Scope Guard at the Top of Every Background Script

A background script that builds scoped artifacts must refuse to run in global scope,
because artifacts created under the wrong scope cannot be easily moved:

```javascript
var scope = gs.getCurrentScopeName();
if (!scope || scope === 'global') {
    gs.print('ERROR: Switch to the Operations Intelligence scope first.');
    return;
}
```

All background scripts in `../source/background/` open with this guard.

---

## 5. ES5 — The Only JavaScript Permitted in Rhino-Executed Code

ServiceNow's Rhino engine does not support ES6+. This applies to: the engine
operation script, all Script Includes, all background scripts, Business Rules,
Client Scripts, and widget server scripts.

**Forbidden — causes parse or runtime errors:**

| Construct | Forbidden form | Use instead |
|---|---|---|
| Template literals | `` `Hello ${name}` `` | `'Hello ' + name` |
| Block scoping | `let x`, `const x` | `var x` |
| Arrow functions | `arr.map(x => x * 2)` | `arr.map(function(x) { return x * 2; })` |
| Destructuring | `var { a, b } = obj` | `var a = obj.a; var b = obj.b;` |
| `eval()` | `eval(code)` | `GlideScopedEvaluator` with a real GlideRecord |
| Spread operator | `[...arr]` | explicit loop or `Array.prototype.slice` |
| Default parameters | `function f(x = 1)` | `var x = (x !== undefined ? x : 1)` |

A single backtick in the engine operation script causes a Rhino parse error at load
time. The engine returns 200 OK for every request but every response is `{"ok":false}`.
There is no error message in the response — only the application log reveals it.

---

## 6. Engine Script Rules

The engine operation script (`../source/engine/operation-script.js`) has additional
rules beyond the ES5 requirement:

**Header block only at the top.** The file begins with a formal comment block
covering exactly four things:
1. Scope identity (scope name, endpoint, authentication)
2. Request format (single op, batch, platform flag)
3. The complete operation catalog (all 117 operations listed by category)
4. Nothing else.

No deployment instructions. No operator guidance. No onboarding steps. No content
addressed to a human reader. The header exists for machine context, not human
instruction.

**No inline comments in the function body.** There are no `//` comments anywhere
inside `(function process(request, response) { ... })`. The code is self-documenting
through precise naming.

**Updating the engine.** Use `engine.selfupdate` via `update_engine.sh`. The engine
validates that the incoming script contains both `X-Engine-Key` and `function dispatch`
before replacing itself. Never edit `sys_ws_operation` directly.

---

## 7. Client-Callable Script Includes: the AbstractAjaxProcessor Pattern

Any Script Include called from a widget client controller via GlideAjax extends
`AbstractAjaxProcessor`. `MaintenanceManager` is the reference implementation.

Required record settings: **Client callable = true**, **Access = public**,
**Active = true**, `api_name = x_infte_ops_int.Name`.

```javascript
var MaintenanceManager = Class.create();
MaintenanceManager.prototype = Object.extendsObject(AbstractAjaxProcessor, {
    ajaxGetStatus: function() {
        // GlideAjax entry point — reads params, checks auth, delegates to _getStatus()
        return JSON.stringify(this._getStatus());
    },
    getStatus: function() {
        // Direct server-side entry point — same logic, no AJAX overhead
        return this._getStatus();
    },
    _getStatus: function() {
        // Private implementation — called by both surfaces
        ...
    },
    type: 'MaintenanceManager'
});
```

**Two surfaces, one logic.** Public `ajaxXxx()` methods are the GlideAjax entry
points. The same private `_xxx()` methods are exposed through plain server-side
methods so other Script Includes can call the logic directly without going through
AJAX.

**Authorise inside every mutating ajax method:**
```javascript
if (!gs.hasRole('admin')) {
    return JSON.stringify({ error: 'Unauthorized' });
}
```

Return strings: booleans as `'' + value`, objects as `JSON.stringify(obj)`.
End with `type: 'Name'`.

---

## 8. Embedding a Script Include in a Background Script

When a background script creates a Script Include record, the `script` field is a
string. Build it as a line array joined with `\n` so it is readable and quote-safe
in the Rhino engine — see the `siCode` variable in `04_build_maintenance.js`:

```javascript
var siCode = [
    "var MaintenanceManager = Class.create();",
    "MaintenanceManager.prototype = Object.extendsObject(AbstractAjaxProcessor, {",
    ...
].join('\n');
```

This is why `MaintenanceManager` exists in two forms. The maintenance protocol
requires both to be updated together whenever the logic changes.

---

## 9. Service Portal Widget Structure

Every widget is four parts, stored as four files under
`../source/widgets/<widget-id>/`:

| File | Field on `sp_widget` | Pattern |
|---|---|---|
| `template.html` | `template` | AngularJS `{{c.data.x}}`, `ng-if`, `ng-repeat`. SVG illustrations inline — no external image URLs. |
| `server-script.js` | `script` | `(function(){ ... })();` — reads `options`, role-gates with `gs.hasRole()`, populates `data`, may call Script Includes directly. |
| `client-script.js` | `client_script` | `function($scope, ...) { var c = this; ... }` — controller alias `c = this`; GlideAjax through a single `_ajax(method, params, cb)` helper. |
| `style.css` | `css` | Widget-scoped class names prefixed `oi-`. |

Conventions: `$scope.$apply()` guarded by `if (!$scope.$$phase)` after async updates;
`$interval` and `$timeout` cleaned up on `$scope.$on('$destroy', ...)`.

---

## 10. GlideAjax Call Convention (Client to Script Include)

```javascript
function _ajax(method, params, cb) {
    var ga = new GlideAjax('MaintenanceManager');
    ga.addParam('sysparm_name', method);
    for (var k in params) {
        if (params.hasOwnProperty(k)) ga.addParam(k, params[k]);
    }
    ga.getXMLAnswer(cb);
}
```

The `answer` argument to the callback is the string returned by the `ajaxXxx()`
method. Parse it with `JSON.parse(answer)` if the method returns a JSON object.
After updating `c.*`, call `if (!$scope.$$phase) $scope.$apply()`.

---

## 11. script.run and GlideScopedEvaluator

`GlideScopedEvaluator.evaluateScript(gr, fieldName, null)` requires a real
GlideRecord as the first argument. Passing `null` causes the evaluator to return
null silently — no error, no output, no exception.

The engine's `script.run` operation works around this by loading its own
`sys_ws_operation` record in-memory, setting `operation_script` to the wrapped user
script, and calling `evaluateScript(gr, 'operation_script', null)`:

```javascript
var gr = new GlideRecord('sys_ws_operation');
gr.get(engineOperationSysId);              // load real record
gr.setValue('operation_script', wrapped);  // set in-memory only — no insert/update
var evaluator = new GlideScopedEvaluator();
evaluator.putVariable('_result_str', '');
evaluator.evaluateScript(gr, 'operation_script', null);
var result = evaluator.getVariable('_result_str');
```

The in-memory `setValue` does not write to the database. The evaluator reads the
field value from the GlideRecord object. This is the only working pattern for
executing arbitrary scoped JavaScript from a Scripted REST operation.

Results are passed back across the evaluator boundary via the `_result_str` variable:
the user's script must set `var result = ...;` — the engine wraps it in
`if (typeof result !== "undefined") { _result_str = JSON.stringify(result); }`.

---

## 12. Security Conventions

- **Never return or log a secret.** `creator_credential.github_pat` is read-blocked
  for everyone including admin. Do not add a code path that returns it.
- **Never hardcode credentials** in automation step `configuration` JSON.
- **Authorise server-side**, not just by hiding UI. Widget server scripts role-gate
  with `gs.hasRole()` and return early for unauthorised users. The matching ajax
  methods re-check the role.
- **Audit privileged actions.** Admin actions that bypass normal role checks are
  logged via `AuditService`.
