# Engine API Reference

The engine is the sole remote interface for building and managing Operations
Intelligence. It is a Scripted REST API (`sys_ws_operation`) deployed in the
`x_infte_ops_int` scope at:

```
POST https://everestdev.service-now.com/api/x_infte_ops_int/ops_int_engine/v1
```

The verbatim operation script is `../source/engine/operation-script.js` (2,407 lines).
Live credentials and the Basic Auth string are in
`../../../context/05-system-context.md`.

---

## Authentication

Every request requires both credentials:

```
Authorization: Basic c3ZjX29wZXJhdGlvbnNfaW50ZWxsaWdlbmNlX2FwaTpIIV5qNDZaS0FIQTdSTGZEYjZWYTk3UHU3UEI4c1RjRg==
X-Engine-Key: EPpXxygqG5AvP8zEPAQ847sFqW6NGqYYp5P6VWJn
Content-Type: application/json
```

The engine reads the key from `x_infte_ops_int.engine_key` system property and
compares it to the `X-Engine-Key` header. A mismatch returns HTTP 403. A missing
or empty `engine_key` property returns HTTP 503.

ServiceNow wraps every response: `{"result": {...}}`. Always unwrap `.result` before
reading any field.

---

## Request Structure

All fields other than `op` are optional and have defaults:

| Field | Type | Default | Purpose |
|---|---|---|---|
| `op` | string | — | Operation name (required) |
| `table` | string | `''` | Target ServiceNow table |
| `data` | object | `{}` | Insert/update payload; also used for operation-specific inputs |
| `query` | object | `{}` | Key-value filter for GlideRecord queries |
| `encoded_query` | string | `''` | Raw ServiceNow encoded query (e.g. `active=true^state=1`) |
| `limit` | integer | `100` | Maximum records to return (hard cap: 10,000) |
| `offset` | integer | `0` | Pagination offset |
| `fields` | array | `null` | Specific fields to return; null returns all |
| `order_by` | string | `''` | Field to sort ascending |
| `order_by_desc` | string | `''` | Field to sort descending |
| `display_values` | boolean | `false` | Return display values instead of raw values |
| `group_by` | string or array | `''` | Group-by field(s) for aggregate operations |
| `platform` | boolean | `false` | Execute via Table API as service account (bypasses scoped sandbox) |
| `bypass_rules` | boolean | `false` | `setWorkflow(false)` and `autoSysFields(false)` on inserts/updates |
| `confirm` | boolean | `false` | Required safeguard for destructive operations (`record.bulk_delete`, `table.truncate`) |
| `include_total` | boolean | `false` | Also return total count for `record.query` |
| `scope` | boolean | `true` | Set `sys_scope` automatically on platform inserts when `true` |

---

## Platform Writes (`"platform": true`)

Platform writes use the `x_infte_ops_int.svc_password` system property to make
internal REST calls as `svc_operations_intelligence_api` via `sn_ws.RESTMessageV2`.
This bypasses the scoped sandbox, allowing writes to system tables
(e.g. `sys_script_include`, `sys_db_object`, `sp_widget`) that the scoped GlideRecord
cannot reach.

Requirements: the `x_infte_ops_int.svc_password` property must be set. Use
`selftest` to verify platform-write capability before relying on it. The timeout
for each internal REST call is 60 seconds.

All `artifact.*` operations use platform writes automatically.

---

## Update Set Management

Configuration-creating operations automatically call `ensureEngineUpdateSet()`
before executing. This function:
1. Queries `sys_update_set` for a record named "Operations Intelligence" with state
   "in progress".
2. If found: activates it for the current session.
3. If not found: creates it with description "Configuration artifacts managed by
   Operations Intelligence." and activates it.

The caller never manages the update set. `engine.status` returns the update set
sys_id and state for verification.

**Operations that trigger update set management** (`TRACKED_OPS`):
All `artifact.*`, all `schema.*`, `acl.create`, `acl.delete`, `role.grant`,
`role.revoke`, `user.create`, `group.create`, `group.add_member`,
`group.remove_member`.

---

## Error Response Format

All errors follow this shape (inside the `.result` envelope):

```json
{"ok": false, "error": "<message>", "_status": 400}
```

`_status` is stripped before the response is sent — the HTTP status code reflects
it instead. Common codes: 400 (bad input), 403 (auth failure), 404 (not found),
500 (server error), 503 (misconfiguration).

---

## Batch Operations

```json
{
  "op": "batch",
  "ops": [
    {"op": "ping"},
    {"op": "now", "label": "timestamp"},
    {"op": "record.insert", "table": "x_infte_ops_int_automation", "data": {...}}
  ],
  "stop_on_error": true
}
```

`stop_on_error` defaults to `true`. When a batch operation fails and stop_on_error is
true, subsequent operations are skipped with `{"ok": false, "error": "skipped after
prior error"}`. The batch response HTTP status is always 200; check each result's
`ok` field. Results include the `label` if one was provided.

---

## Operations Reference

### DIAGNOSTICS

#### `ping`
Health check. No inputs.
```json
{"ok": true, "pong": true, "scope": "x_infte_ops_int", "ts": "2026-06-20 10:00:00"}
```

#### `now`
Server date and time.
```json
{"ok": true, "utc": "2026-06-20 10:00:00", "display": "06/20/2026 10:00:00", "numeric": "1750420800000"}
```

#### `scope.info`
Instance identity and capability status.
```json
{
  "ok": true, "scope": "x_infte_ops_int", "user": "svc_operations_intelligence_api",
  "is_admin": true, "app_scope": "x_infte_ops_int", "app_sys_id": "...",
  "platform_writes_enabled": true, "instance": "everestdev", "base_url": "https://everestdev.service-now.com"
}
```

#### `selftest`
End-to-end capability matrix. Tests scoped read, scoped write, platform write,
platform read, and platform delete. Creates and cleans up test records.
```json
{
  "ok": true,
  "capability": {
    "svc_password_set": true, "engine_key_set": true, "is_admin": true,
    "app_scope_resolved": true, "scoped_read": true, "scoped_write": true,
    "platform_write": true, "platform_read": true, "platform_delete": true
  },
  "summary": "Fully autonomous: build + maintenance ready."
}
```

#### `engine.status`
Health, configuration, and full artifact inventory. Use this to verify the engine
is correctly deployed and to audit what is in the application scope.
```json
{
  "ok": true, "scope": "x_infte_ops_int", "instance": "everestdev",
  "base_url": "https://...", "user": "svc_operations_intelligence_api",
  "is_admin": true, "platform_writes_enabled": true, "engine_key_configured": true,
  "op_count": 117,
  "update_set": {"name": "Operations Intelligence", "sys_id": "...", "state": "in progress"},
  "inventory": {
    "tables":          {"count": 19},
    "script_includes": {"count": 21, "items": [...]},
    "business_rules":  {"count": 5,  "items": [...]},
    "client_scripts":  {"count": 0,  "items": []},
    "ui_actions":      {"count": 0,  "items": []},
    "notifications":   {"count": 22, "items": [...]},
    "scheduled_jobs":  {"count": 0,  "items": []},
    "widgets":         {"count": 2,  "items": [...]},
    "ui_pages":        {"count": 0,  "items": []},
    "reports":         {"count": 0,  "items": []},
    "catalog_items":   {"count": 0,  "items": []},
    "acls":            {"count": 0,  "items": []}
  }
}
```

#### `help`
Returns the full annotated operation list from `OP_CATALOG`.
```json
{"ok": true, "count": 117, "ops": [{"op": "ping", "description": "health-check"}, ...]}
```

#### `sys.version`
Platform build details.
```json
{"ok": true, "build_name": "...", "build_date": "...", "build_tag": "...", "patch": "...", "instance": "everestdev", "base_url": "https://..."}
```

---

### DISCOVERY

All meta operations return items scoped to `x_infte_ops_int` only (by `sys_scope`).

#### `meta.tables`
```json
{"ok": true, "count": 19, "tables": [{"sys_id": "...", "name": "x_infte_ops_int_automation", "label": "Automation"}]}
```

#### `meta.script_includes`
Fields: `name`, `api_name`, `active`, `client_callable`.

#### `meta.business_rules`
Fields: `name`, `collection`, `active`, `when`, `order`.

#### `meta.notifications`
Fields: `name`, `active`, `event_name`.

#### `meta.widgets`
Fields: `name`, `id`, `active`.

#### `meta.jobs`
Fields: `name`, `active`, `run_type`, `run_time`.

#### `meta.acls`
Requires `table`. Returns ACLs for the named table regardless of scope.
Fields: `sys_id`, `operation`, `active`, `admin_overrides`, `condition`.

#### `meta.all`
Full inventory across all artifact types in one call. Returns the same shape as
`engine.status.inventory` but with `items` arrays for every type including
`ui_policies`, `portal_themes`, `portal_pages`, `event_registries`, and `properties`.

#### `meta.ui_pages`
Fields: `name`, `category`, `direct`.

#### `meta.portal_pages`
Fields: `id`, `title`, `draft`, `internal`.

#### `meta.catalog_items`
Fields: `name`, `short_description`, `active`, `category`.

#### `meta.app_menus`
Fields: `title`, `active`, `category`.

#### `meta.app_modules`
Fields: `title`, `active`, `application`, `link_type`, `order`.

#### `meta.events`
Fields: `event_name`, `description`, `table`, `fired_by`.

#### `meta.roles`
Fields: `name`, `description`, `grantable`, `elevated_privilege`.

#### `meta.portals`
Fields: `title`, `url_suffix`.

#### `table.exists`
Required: `table` (the `table` field, not `data`).
```json
{"ok": true, "table": "x_infte_ops_int_automation", "exists": true}
```

#### `schema.fields`
Required: `table`. Returns all field definitions from `sys_dictionary`.
Fields per entry: `element`, `column_label`, `internal_type`, `max_length`,
`mandatory`, `default_value`, `reference`, `read_only`, `choice`, `sys_id`.

#### `table.schema`
Required: `table`. Full schema dump: fields (same as `schema.fields`), all choice
values grouped by element (`choices`), and autonumber config (`autonumber`).

---

### DDL

All DDL operations write to `x_infte_ops_int` scope and trigger update set management.

#### `schema.table.create`
Creates a table in `x_infte_ops_int`. The engine prefixes the name automatically:
`table` field = short name (e.g. `automation`) → creates `x_infte_ops_int_automation`.

Required: `table` (short name).
Optional data: `label`, `is_extendable` (boolean), `name_field`, `super_class`.

Idempotent: if the full-prefixed table already exists, returns `{ok: true, skipped: true}`.

```json
{"ok": true, "full_name": "x_infte_ops_int_automation", "sys_id": "...", "name_ok": true}
```

#### `schema.table.delete`
Required: `table` (full name) or `data.sys_id`.

#### `schema.table.extend`
Sets a table's parent (inheritance). Required: `table` (child, full name),
`data.parent` (parent table full name).

#### `schema.add_field`
Adds a field to a table. Required: `table`, `data.element` (field name), `data.type`
(Glide type name, e.g. `string`, `integer`, `reference`, `boolean`, `glide_date_time`).

Optional data: `label`, `max_length`, `reference` (target table for reference fields),
`mandatory`, `default_value`, `choice`, `read_only`.

Idempotent: if the field already exists on the table, returns `{ok: true, skipped: true}`.

#### `schema.field.update`
Updates an existing field. Required: `table`, `data.element`.
Updatable fields: `column_label`, `max_length`, `mandatory`, `default_value`,
`choice`, `read_only`, `reference`.

#### `schema.field.delete`
Removes a field. Required: `table`, `data.element`.

#### `schema.add_choice`
Adds a choice value to a field. Required: `table`, `data.element`, `data.value`.
Optional data: `label` (defaults to value), `sequence` (defaults to 0).
Idempotent: skips if choice value already exists.

#### `schema.choice.update`
Updates a choice's label or sequence. Required: `table`, `data.element`, `data.value`.
Optional data: `label`, `sequence`.

#### `schema.choice.delete`
Removes a choice. Required: `table`, `data.element`, `data.value`.

#### `schema.set_autonumber`
Configures autonumbering for a table (`sys_number`). Required: `table`, `data.prefix`.
Optional data: `start` (defaults to 1001).
Idempotent: skips if autonumber config already exists.

#### `schema.index.create`
Creates a database index (`sys_db_index`). Required: `table`, `data.columns`
(comma-separated field names). Optional data: `unique` (boolean, defaults to false).

---

### PROPERTIES

`sys_properties` is platform-global — the only table not scoped to `x_infte_ops_int`.

#### `property.set`
Single property: Required `data.key`. Optional: `data.value`, `data.type` (if type
is supplied, the property is created/updated as a typed record via Table API rather
than `gs.setProperty`), `data.description`.

Batch: send `data` as an array of `{key, value, type?, description?}` objects.
```json
{"ok": true, "set": 3, "failed": 0, "results": [{"ok": true, "key": "x_infte_ops_int.engine_key"}]}
```

#### `property.get`
Required: `data.key`. Returns `null` value if the property does not exist.
```json
{"ok": true, "key": "x_infte_ops_int.engine_key", "value": "EPpXxygqG5AvP8zEPAQ847sFqW6NGqYYp5P6VWJn"}
```

#### `property.list`
Optional `data.prefix` to filter by prefix. Returns up to `limit` properties
ordered by name.

#### `property.delete`
Required: `data.key`. Returns 404 if not found.

---

### RECORDS

Record operations support both scoped GlideRecord (default) and platform write
(`"platform": true`). Prefer platform writes for system tables and when the scoped
sandbox would block the operation.

#### `record.insert`
Required: `table`. `data` is the field payload.

With `platform: true`: uses Table API POST, returns `{ok: true, sys_id: "...", via: "platform"}`.
Without: uses GlideRecord insert.

Optional: `bypass_rules` (skips Business Rules and auto sys fields),
`use_display_value` (object mapping field names to boolean — uses `setDisplayValue` for those fields).

#### `record.insert_many`
Required: `table`, `data.records` (array of field objects). Inserts each record
individually. Returns `{ok: true, inserted: N, failed: 0, sys_ids: [...]}`.

#### `record.update`
Required: `table`. Target via `data.sys_id` (single record) or `query`/`encoded_query`
(multiple records). Returns count of updated records.

#### `record.patch`
Partial update — only supplied fields change. Required: `table` plus at least one of
`data.sys_id`, `query`, `encoded_query`. Identical to `record.update` but semantically
documents intent as a partial change.

#### `record.upsert`
Insert-or-update. Required: `table` plus `query` or `encoded_query` to match on.
`data` is the full payload for both cases. Returns `{ok: true, action: "inserted"|"updated", sys_id: "..."}`.

#### `record.delete`
Required: `table` plus at least one of `data.sys_id`, `query`, `encoded_query`.
Refuses unbounded deletes (no filter = error). Returns `{ok: true, deleted: N}`.

#### `record.bulk_delete`
Destructive. Required: `table` plus `query` or `encoded_query`. Without `confirm: true`,
returns the count of matching records and refuses to delete. With `confirm: true`,
deletes all matching records. Always provide a filter — unbounded bulk_delete is refused.

#### `record.get`
Required: `table`. Target via `data.sys_id` or `query`/`encoded_query`. Returns the
first matching record. Optional: `fields` (array), `order_by`, `order_by_desc`.

#### `record.find`
Required: `table`, `data.value`. Searches using CONTAINS on `data.field` (defaults
to `name`). Returns up to `limit` matching records.

#### `record.query`
Required: `table`. Optional: `query`, `encoded_query`, `fields`, `limit` (default 100,
max 10,000), `offset`, `order_by`, `order_by_desc`, `include_total` (triggers a
separate GlideAggregate COUNT query).
```json
{"ok": true, "count": 25, "records": [...], "offset": 0, "total": 250}
```

#### `record.clone`
Duplicates a record. Required: `table`, `data.sys_id`. Optional: `data.override`
(object of field values to set on the clone, excluding `sys_id`). Skips audit/system
fields. Returns `{ok: true, cloned_from: "...", sys_id: "..."}`.

#### `record.count`
Required: `table`. Optional: `query`, `encoded_query`.
```json
{"ok": true, "table": "x_infte_ops_int_automation", "count": 42}
```

#### `record.aggregate`
Required: `table`. Optional: `data.type` (COUNT/SUM/AVG/MIN/MAX, default COUNT),
`data.field` (required for non-COUNT), `group_by` (field name or array), `query`,
`encoded_query`, `order_by`.

#### `record.history`
Required: `table`, `data.sys_id`. Returns both `sys_audit` entries (field changes)
and `sys_journal_field` entries (work notes/comments). Limited to `limit` entries
from each table, ordered by creation descending.

#### `record.exists`
Required: `table`. Optional: `data.sys_id`, `query`, `encoded_query`.
```json
{"ok": true, "table": "...", "exists": true, "sys_id": "..."}
```

#### `record.read_many`
Required: `table`, `data.sys_ids` (array of sys_id strings). Returns all matching
records in one call. Supports `platform: true` and `fields`.

#### `table.truncate`
Destructive. Required: `table`. Without `confirm: true`, returns the row count and
refuses. With `confirm: true`, deletes every row.

---

### ACL

#### `acl.create`
Required: `table` (the ACL name, e.g. `x_infte_ops_int_automation`), `data.operation`
(read/write/create/delete/execute).

Optional data: `active` (default true), `admin_overrides` (default true),
`type` (default "record"), `script`, `condition`, `roles`.

Uses `artifactUpsert` — idempotent on `name + operation`.

#### `acl.delete`
Required: `data.sys_id`.

#### `acl.list`
Required: `table`. Optional: `data.operation` to filter. Returns full ACL details
including `condition` and `script`.

---

### ACCESS

#### `role.grant`
Grants a role to a user. Required: `data.user` (user_name or sys_id),
`data.role` (role name or sys_id). Idempotent — skips if already granted.

#### `role.revoke`
Removes a role from a user. Required: `data.user`, `data.role`.
Returns count of removed `sys_user_has_role` records.

#### `user.roles`
Lists all roles for a user. Required: `data.user`.
```json
{"ok": true, "user": "svc_operations_intelligence_api", "count": 1, "roles": ["admin"]}
```

---

### USERS

#### `user.create`
Required: `data.user_name`. Optional: `first_name`, `last_name`, `email`, `title`,
`department`, `active` (default true), `password_needs_reset`, `locked_out`,
`phone`, `mobile_phone`, `time_zone`.
Idempotent — skips if user_name already exists.

#### `user.get`
Required: `data.user`, `data.user_name`, or `data.sys_id`. Default fields returned:
`user_name`, `first_name`, `last_name`, `email`, `active`, `title`, `department`.
Override with `fields`.

#### `user.update`
Required: one of `data.user`, `data.user_name`, `data.sys_id`.
Updatable fields: `first_name`, `last_name`, `email`, `title`, `department`,
`active`, `locked_out`, `password_needs_reset`, `phone`, `mobile_phone`, `time_zone`.

#### `user.search`
Optional data: `query` (searches user_name, first_name, last_name, email with CONTAINS),
`email`, `first_name`, `last_name`, `department`, `active`. Returns up to `limit` results.

---

### GROUPS

#### `group.create`
Required: `data.name`. Optional: `description`, `email`, `manager` (user_name or
sys_id), `active` (default true). Idempotent — skips if group name exists.

#### `group.add_member`
Required: `data.group` (name or sys_id), `data.user` (user_name or sys_id).
Idempotent — skips if already a member.

#### `group.remove_member`
Required: `data.group`, `data.user`. Returns count of removed records.

#### `group.members`
Required: `data.group`. Returns `{user_name, user_sys_id}` per member.

#### `group.search`
Optional data: `query` (searches name and description with CONTAINS), `name`,
`active`. Returns up to `limit` results.

---

### UPDATE SETS

These operations manage `sys_update_set` records directly. The engine's automatic
update set management (TRACKED_OPS) is separate and transparent — it is not these
operations. Use these only when explicit update set management is needed.

#### `update_set.create`
Required: `data.name`. Optional: `data.description`, `data.application`.
Idempotent — skips if name already exists.

#### `update_set.activate`
Sets an update set to "in progress". Required: `data.name` or `data.sys_id`.

#### `update_set.list`
Optional: `data.state` filter. Returns up to `limit` sets ordered by last update.

---

### ARTIFACTS

All artifact operations use `artifactUpsert`: they query for an existing record
matching the given key fields within `x_infte_ops_int` scope, update it if found,
and insert it if not. `sys_scope` is set automatically. All trigger update set
management.

#### `artifact.script_include`
Required: `data.name`, `data.script`.
Optional data: `api_name` (defaults to `x_infte_ops_int.<name>`), `active` (default
true), `client_callable` (default false), `access` (default `package_private`).

Upsert key: `name` in `sys_script_include`.

#### `artifact.business_rule`
Required: `data.name`, `data.collection` (table name), `data.script`.
Optional data: `active`, `when` (default "after"), `order` (default 100),
`insert`/`update`/`delete`/`query` (booleans, all default true except query),
`add_message`, `condition`, `filter_condition`.

Upsert key: `name + collection` in `sys_script`.

#### `artifact.notification`
Required: `data.name`, `data.event_name`.
Optional data: `active`, `subject`, `message_html`, `message_text`, `importance`,
`send_when`, `condition`, `recipient_groups`, `recipient_users`.

Upsert key: `name` in `sysevent_email_action`.

#### `artifact.scheduled_job`
Required: `data.name`, `data.script`.
Optional data: `active`, `run_type` (default "on_demand"), `run_time`, `run_period`,
`run_dayofweek`, `run_dayofmonth`.

Upsert key: `name` in `sysauto_script`.

Note: use `sysauto_script` only for `ScheduleManager` automation scheduling. Scheduled
data jobs (a deliverable type) use `sysauto_report`, not this operation.

#### `artifact.client_script`
Required: `data.name`, `data.table`, `data.type` (onLoad/onChange/onSubmit/onCellEdit).
Optional data: `script`, `active`, `field_name`, `view`, `condition`.

Upsert key: `name + table + type` in `sys_script_client`.

#### `artifact.ui_action`
Required: `data.name`, `data.table`.
Optional data: `active`, `action_name`, `type` (default "button"), `script`,
`condition`, `hint`, `list_action`, `form_button`.

Upsert key: `name + table` in `sys_ui_action`.

#### `artifact.widget`
Required: `data.name`, `data.id` (widget ID slug, e.g. `oi-maintenance-overlay`).
Optional data: `active`, `template`, `client_script`, `server_script` (note: field
is `script` on `sp_widget`), `css`, `option_schema` (object or JSON string),
`demo_data` (object or JSON string).

Upsert key: `id` in `sp_widget`.

#### `artifact.ui_page`
Required: `data.name`.
Optional data: `category`, `html`, `client`, `server`, `processing_script`.

Upsert key: `name` in `sys_ui_page`.

#### `artifact.sp_page`
Required: `data.id` (page slug).
Optional data: `title`, `draft`, `internal`.

Upsert key: `id` in `sp_page`.

#### `artifact.sp_container`
Required: `data.page_sys_id`. Uses platform insert (not upsert — containers can
repeat on a page).
Optional data: `order` (default 100), `bootstrap_alt`, `width` (default "container").

#### `artifact.sp_row`
Required: `data.container_sys_id`. Uses platform insert.
Optional data: `order` (default 100).

#### `artifact.sp_column`
Required: `data.row_sys_id`. Uses platform insert.
Optional data: `order` (default 100), `size_md`, `size_sm`, `size_xs`, `size_lg`
(Bootstrap column widths, integers).

#### `artifact.sp_instance`
Required: `data.column_sys_id`, `data.widget_sys_id`. Uses platform insert.
Optional data: `order` (default 100), `title`, `hide_title`, `css_class`,
`options` (object or JSON string).

#### `artifact.sp_theme`
Required: `data.name`.
Optional data: `css_variables`, `fixed_header`, `navbar_inverse`.

Upsert key: `name` in `sp_theme`.

#### `artifact.app_menu`
Required: `data.title`.
Optional data: `active`, `category`, `roles`.

Upsert key: `title` in `sys_app_application`.

#### `artifact.app_module`
Required: `data.title`, `data.application_sys_id`.
Optional data: `active`, `link_type` (default "LIST"), `order` (default 100),
`table`, `filter`, `url`, `roles`.

Upsert key: `title + application` in `sys_app_module`.

#### `artifact.catalog_item`
Required: `data.name`.
Optional data: `active`, `short_description`, `description`, `category`, `price`,
`picture`.

Upsert key: `name` in `sc_cat_item`.

#### `artifact.catalog_variable`
Required: `data.name`, `data.cat_item_sys_id`.
Optional data: `question_text` (defaults to name), `type` (integer, default 6 =
single-line text), `order` (default 100), `active`, `mandatory`, `default_value`,
`help_text`.

Upsert key: `name + cat_item` in `item_option_new`.

#### `artifact.ui_policy`
Required: `data.short_description`, `data.table`.
Optional data: `active`, `run_scripts`, `on_load`, `script_true`, `script_false`,
`reverse`, `conditions`.

Upsert key: `short_description + table` in `sys_ui_policy`.

#### `artifact.ui_policy_action`
Required: `data.ui_policy_sys_id`, `data.field`.
Optional data: `mandatory`, `visible`, `read_only`.

Upsert key: `ui_policy + field` in `sys_ui_policy_action`.

#### `artifact.event_registry`
Required: `data.event_name`.
Optional data: `description`, `table`, `fired_by`.

Upsert key: `event_name` in `sysevent_register`.

#### `artifact.report`
Required: `data.title`, `table` (the `table` field, not data).
Optional data: `type` (default "list"), `filter`, `field`, `group_by`, `aggregation`.

Upsert key: `title + table` in `sys_report`.

#### `artifact.role`
Required: `data.name`.
Optional data: `description`, `elevated_privilege` (default false), `grantable`
(default true).

Upsert key: `name` in `sys_user_role`.

#### `artifact.sp_portal`
Required: `data.title`.
Optional data: `url_suffix`, `theme`, `homepage`/`default_page` (both map to the
`homepage` field), `login_page`, `knowledge_base` (maps to `kb_knowledge_base`), `css`.

Upsert key: `title` in `sp_portal`.

---

### FILES

#### `attachment.write`
Required: `data.table`, `data.sys_id`, `data.file_name`, `data.base64` (base64-encoded
content). Optional: `data.content_type` (defaults to `application/octet-stream`).
Uses `GlideSysAttachment.writeBase64()`.

#### `attachment.read`
Required: `data.attachment_sys_id`. Returns `file_name`, `content_type`,
`size_bytes`, and `base64` content.

#### `attachment.list`
Required: `data.table`, `data.sys_id`. Returns all attachments on the record.

#### `attachment.delete`
Required: `data.attachment_sys_id`.

---

### POWER

#### `script.run`
Executes arbitrary scoped JavaScript on the server. Required: `data.script`.

**Critical constraint:** GlideScopedEvaluator requires a real GlideRecord — passing
`null` as the first argument causes silent failure. The engine loads its own
`sys_ws_operation` record in-memory, sets `operation_script` to the wrapped script,
and calls `evaluateScript(gr, 'operation_script', null)`. The in-memory `setValue`
does not write to the database.

**Return value:** In the script, set `var result = <anything>;`. The engine wraps
the script in:
```javascript
var result;
try { <your script> } catch (_srEx) {}
if (typeof result !== "undefined") { _result_str = JSON.stringify(result); }
```
The engine returns `{"ok": true, "result": <parsed value>}`.

If `engineOperationId()` cannot find the engine operation record, the operation
fails with 500. Pass `data.operation_sys_id` to override the lookup.

Optional: `data.operation_sys_id` — bypasses the `engineOperationId()` lookup and
uses this sys_id directly.

Example:
```json
{
  "op": "script.run",
  "data": {
    "script": "var gr = new GlideRecord('x_infte_ops_int_automation'); gr.query(); result = gr.getRowCount();"
  }
}
```

#### `rest.call`
Makes an authenticated internal REST call as the service account.
Required: `data.path` (e.g. `/api/now/table/sys_user`).
Optional: `data.method` (default GET), `data.body`, `data.params` (query params),
`data.headers`.

#### `event.fire`
Fires a platform event. Required: `data.name`. Optional: `data.table`, `data.sys_id`
(used to load the GlideRecord context), `data.param1`, `data.param2`.

#### `sys.log`
Writes to the application system log at INFO level.
Required: `data.message`. Optional: `data.source` (defaults to
`x_infte_ops_int.engine`).

#### `cache.flush`
Calls `gs.flushCache()`. No inputs.

#### `sys.id`
Resolves an artifact name to its sys_id. Required: `data.name`, `data.type`.

Type values and their lookup tables:

| Type | Table | Lookup field |
|---|---|---|
| `script_include` | `sys_script_include` | `name` |
| `business_rule` | `sys_script` | `name` |
| `notification` | `sysevent_email_action` | `name` |
| `scheduled_job` | `sysauto_script` | `name` |
| `client_script` | `sys_script_client` | `name` |
| `ui_action` | `sys_ui_action` | `name` |
| `ui_policy` | `sys_ui_policy` | `short_description` |
| `widget` | `sp_widget` | `id` |
| `ui_page` | `sys_ui_page` | `name` |
| `sp_page` | `sp_page` | `id` |
| `sp_theme` | `sp_theme` | `name` |
| `sp_portal` | `sp_portal` | `url_suffix` |
| `app_menu` | `sys_app_application` | `title` |
| `app_module` | `sys_app_module` | `title` |
| `catalog_item` | `sc_cat_item` | `name` |
| `event_registry` | `sysevent_register` | `event_name` |
| `report` | `sys_report` | `title` |
| `table` | `sys_db_object` | `name` |
| `role` | `sys_user_role` | `name` |
| `group` | `sys_user_group` | `name` |
| `user` | `sys_user` | `user_name` |
| `update_set` | `sys_update_set` | `name` |
| `acl` | `sys_security_acl` | `name` |
| `catalog_variable` | `item_option_new` | `name` |
| `attachment` | `sys_attachment` | `file_name` |
| `property` | `sys_properties` | `name` |

If `type` does not match a known key, it is used directly as the table name with
`data.field` as the lookup field (default `name`).

#### `note.add`
Adds a work note or comment to any record. Required: `table`, `data.sys_id`,
`data.value`. Optional: `data.type` (`comment` or `work_note`, defaults to `work_note`).
Uses `setWorkflow(false)` to suppress notifications.

---

### WORKFLOW

#### `workflow.start`
Triggers a Flow Designer flow. Required: `data.flow` (flow `sys_name` or sys_id).
Optional: `data.inputs` (object of input variable values).
Calls `POST /api/sn_fd/flow/<flow>/execute` internally.

#### `workflow.cancel`
Cancels a running flow instance. Required: `data.instance_sys_id`.
Calls `DELETE /api/sn_fd/flow_instances/<instance_sys_id>` internally.

---

### EMAIL

#### `email.send`
Required: `data.to`, `data.subject`, plus one of `data.body`/`data.html` (HTML body)
or `data.text_body` (plain text). Optional: `data.from`, `data.cc`, `data.bcc`.
Uses `GlideEmailOutbound`. Calls `em.save()` to queue the email.

---

### ENGINE

#### `engine.source`
Reads the current engine operation script via platform GET. Returns script size in
bytes and a `marker_ok` boolean confirming both `X-Engine-Key` and `function dispatch`
are present in the stored script.

Optional: `data.operation_sys_id` to override `engineOperationId()` lookup.

```json
{"ok": true, "operation_sys_id": "...", "name": "Engine Router", "bytes": 98304, "marker_ok": true}
```

#### `engine.selfupdate`
Replaces the engine operation script. Required: `data.script`.

**Safety check:** The incoming script must contain both `X-Engine-Key` and
`function dispatch`. The engine rejects the update if either is absent — this
prevents accidentally deploying a broken script that would disable the engine.

Uses `platformUpdate('sys_ws_operation', operationSysId, {operation_script: script})`.

Run `selftest` after updating to confirm the new script is working correctly.

```json
{"ok": true, "operation_sys_id": "...", "bytes": 98304, "note": "Engine script replaced. Re-run selftest to confirm."}
```

Optional: `data.operation_sys_id` to override `engineOperationId()` lookup.

---

## Engine Internals

This section documents the internal structure of the engine for anyone extending,
debugging, or rebuilding it.

### `engineOperationId(override)`
Resolves the sys_id of the engine's own `sys_ws_operation` record.

Primary path: queries `sys_ws_operation` filtered by
`sys_scope.scope=x_infte_ops_int^web_service_definition.name=Operations Intelligence Engine`.

Fallback: queries by `name=Engine Router` with no scope filter.

If both fail, returns an empty string and the calling operation returns HTTP 500.
Pass `data.operation_sys_id` to skip this lookup entirely.

### `appScopeSysId()`
Cached lookup of the `sys_scope` sys_id for `x_infte_ops_int`. The result is
cached in `_appId` and reused for the lifetime of the request.

### `ensureEngineUpdateSet()`
Finds or creates the "Operations Intelligence" update set and activates it for the
current session via `gs.getSession().setCurrentUpdateSet(usId)`. Called automatically
before every operation listed in `TRACKED_OPS`.

### `internalRest(method, path, payload, qParams, extraHeaders)`
Makes authenticated REST calls using `sn_ws.RESTMessageV2` as the service account.
Reads the password from `x_infte_ops_int.svc_password`. Times out at 60 seconds.
Returns `{ok, status, body}` — never throws.

### `artifactUpsert(tbl, encodedQuery, payload, scopeAuto)`
Queries for an existing record using the encoded query. If found, patches it.
If not found, inserts it. When `scopeAuto` is true and `payload.sys_scope` is not
set, automatically sets `sys_scope` to the application scope sys_id.

### `normalize(src)`
Normalises the raw request body to a consistent `ctx` object with all fields
defaulted. Called on every request before `dispatch(ctx)`.

### `dispatch(ctx)`
The main switch statement. Receives the normalised context. Returns a plain object
that becomes the response body. Uses `_status` field internally to set the HTTP
status code; this field is deleted before sending.
