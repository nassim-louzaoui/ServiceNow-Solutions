# Implementation Documentation

How Operations Intelligence is built. These files define the rules, patterns, and
mechanics that any code or artifact in this platform must follow. Read them before
building; consult them when extending.

| File | Purpose |
|---|---|
| `build-order.md` | Prerequisites and ordered deployment sequence — what to build first |
| `coding-patterns.md` | The rules: ES5, scope discipline, idempotency, widget structure, Script Include pattern, engine script constraints |
| `engine-reference.md` | The engine REST API — all 117 operations with complete specifications and engine internals |
| `outbound-integration-guide.md` | Direct Table API mechanics for builds that do not use the engine |
| `recipes/` | Step-by-step procedures for adding each artifact type |

These files document the *how*. The *what* is in `../../../architecture/solution-architecture.md`.
The *why* is in `../../../context/`. Always confirm a detail against the architecture
before implementing; documentation can lag, the architecture is authoritative.
