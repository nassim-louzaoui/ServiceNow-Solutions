# Build Order — Operational Run Sheet

This is the operational run sheet: the manual prerequisites, the exact order to run
the four background scripts, and where each fits in the full build. The complete,
authoritative 15-step build sequence — with every table name, the Script Include
dependency chain, and the 30-item end-to-end test checklist — lives in
[`../architecture/solution-architecture.md`](../architecture/solution-architecture.md)
under **Build Order**. This file is the checklist you keep open while doing it; that
section is the specification.

## Pre-build (manual, in ServiceNow Studio)

1. Create the scoped application in Studio. Suggested scope: `x_infte_ops_int`.
2. Create the four application roles: `admin`, `leadership`, `creator`, `user`.
   ServiceNow prefixes them with the scope automatically.
3. Confirm the scope picker (top-right banner) shows **Operations Intelligence**,
   not **Global**. Every artifact must be created while this scope is active.

## The four background scripts, in order

Run from **System Definition → Scripts - Background**, with the OI scope active.

| Order | Script | When | What it does | What to do with the output |
|---|---|---|---|---|
| 1 | [`scripts/background/01_bootstrap_api_access.js`](scripts/background/01_bootstrap_api_access.js) | First, before anything else | Creates the `svc_operations_intelligence_api` service account with the `admin` role; resolves and prints the instance URL, credentials, and the live `{scope}` prefix and scope sys_id | **Capture the entire output.** It is the prerequisite for every REST-driven build step and the authoritative value of `{scope}`. |
| 2 | [`scripts/background/03_setup_update_sets.js`](scripts/background/03_setup_update_sets.js) | After capturing the bootstrap output | Creates the single update set **Operations Intelligence**, activates it, and creates the per-environment config sets | Confirm the active update set banner now reads *Operations Intelligence* |
| 3 | *(full build sequence)* | Steps 1–15 of the architecture's Build Order | Tables, seed data, roles/ACLs, the 21 Script Includes in dependency order, business rules, jobs, notifications, NLU model and topics, portal and widgets, Copilot integration | Run `02_verify_implementation.js` (below) after each major step |
| 4 | [`scripts/background/04_build_maintenance.js`](scripts/background/04_build_maintenance.js) | At step 15, with `AuditService` already present | Creates the 5 `maintenance_*` properties, the `MaintenanceManager` Script Include, and both maintenance widgets — idempotent (`createOrSkip`), safe to re-run | All checks should read `[OK]` or `[SKIP]` |
| 5 | [`scripts/background/02_verify_implementation.js`](scripts/background/02_verify_implementation.js) | After every build step, and as the final gate | Verifies 19 tables, 21 Script Includes, 19 properties, 5 business rules, 22 notifications, 5 jobs, VA channel, NLU model, portal, 6 spot-check VA topics, and the `github_pat` / `managed_artifact` field ACLs | Every check must pass before promoting the build |

## Do not proceed past pre-build until

- The output of `01_bootstrap_api_access.js` is captured (credentials + `{scope}`).
- The active update set reads **Operations Intelligence**.
- The scope picker still shows **Operations Intelligence**.

## Migration

Promotion from dev → test → prod is covered in the architecture document under
**Update Set & Migration Strategy** (Studio application export is preferred; a single
update set is the fallback; environment config sets are always applied separately;
the NLU model must be retrained on each environment after import). Do not duplicate
those steps here — follow them from the canon so there is only one copy to keep
correct.
