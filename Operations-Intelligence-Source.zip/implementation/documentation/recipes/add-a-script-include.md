# Recipe — Add a Script Include

A Script Include holds reusable server-side logic. If a widget client controller must
call it, it is **client-callable** and extends `AbstractAjaxProcessor`; otherwise it
is a plain `Class.create()`. `MaintenanceManager` is the reference for the
client-callable kind — read
[`../scripts/script-includes/MaintenanceManager.js`](../scripts/script-includes/MaintenanceManager.js)
alongside this recipe.

## Decide first

1. **Where does it sit in the dependency order?** New includes are built in the order
   in the architecture's *Script Includes* section. Anything that calls another
   include must be built after it.
2. **Client-callable?** Only if a widget calls it via GlideAjax. If yes, follow the
   two-surface pattern in [`../coding-patterns.md`](../coding-patterns.md) §5.

## Record fields

| Field | Value |
|---|---|
| `name` | PascalCase, e.g. `ArtifactManager` |
| `api_name` | `{scope}.Name`, e.g. `x_infte_ops_int.ArtifactManager` |
| `client_callable` | `true` only if called from a widget |
| `access` | `public` (so other scoped includes can call it) |
| `active` | `true` |
| `sys_scope` | the OI app sys_id |
| `script` | the source (see skeletons below) |

## Skeleton — plain Script Include

```javascript
var ExampleService = Class.create();
ExampleService.prototype = {
    initialize: function() {},

    doThing: function(arg) {
        // server-side logic; may call other includes, e.g. new AuditService().log(...)
        return result;
    },

    type: 'ExampleService'
};
```

## Skeleton — client-callable Script Include

```javascript
var ExampleAjax = Class.create();
ExampleAjax.prototype = Object.extendsObject(AbstractAjaxProcessor, {

    // GlideAjax surface — params via this.getParameter('sysparm_*'); authorise; delegate
    ajaxDoThing: function() {
        if (!gs.hasRole('admin')) { return JSON.stringify({ error: 'Unauthorized' }); }
        var arg = this.getParameter('sysparm_arg') || '';
        return JSON.stringify(this._doThing(arg));
    },

    // Server-side surface — callable directly by other includes
    doThing: function(arg) { return this._doThing(arg); },

    // Private implementation — single source of the logic
    _doThing: function(arg) { /* ... */ return { success: true }; },

    type: 'ExampleAjax'
});
```

## Build it

**Background script (in-instance, idempotent):** use `createOrSkip` with the script
body as a `[...].join('\n')` array — see `04_build_maintenance.js`:

```javascript
createOrSkip('sys_script_include',
  function(gr){ gr.addQuery('name','ExampleAjax'); gr.addQuery('sys_scope.scope', scope); },
  function(gr){
    gr.setValue('name','ExampleAjax');
    gr.setValue('script', siCode);                 // the [...].join('\n') string
    gr.setValue('api_name', scope + '.ExampleAjax');
    gr.setValue('client_callable', true);
    gr.setValue('access','public');
    gr.setValue('active', true);
  },
  'ScriptInclude: ExampleAjax');
```

**REST:** POST to `sys_script_include` per [`../rest-api-guide.md`](../rest-api-guide.md).

## Finish

- If client-callable, the embedded build-script copy and the readable `.js` are two
  representations of the same logic — keep both. Add the readable source under
  [`../scripts/script-includes/`](../scripts/script-includes/).
- Add the include to the architecture's *Script Includes* table with its purpose and
  dependency note.
- Verify it appears in `02_verify_implementation.js` (add it to that script's
  `includes` list if it is a permanent platform include).
