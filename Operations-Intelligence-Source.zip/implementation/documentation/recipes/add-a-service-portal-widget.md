# Recipe — Add a Service Portal Widget

A widget is one `sp_widget` record made of four parts. Keep the four parts as four
files under [`../scripts/widgets/<id>/`](../scripts/widgets/) so they are readable and
diff-able; the build script assembles them into the record. The two maintenance
widgets are the reference — read them beside this recipe.

## 1. Choose an id and the four files

```
scripts/widgets/<widget-id>/
  template.html       → sp_widget.template
  server-script.js    → sp_widget.script
  client-script.js    → sp_widget.client_script
  style.css           → sp_widget.css
```

Use a stable, hyphenated `id` prefixed `oi-`, e.g. `oi-group-metrics`. Class names in
CSS are prefixed `oi-` to avoid collisions.

## 2. Server script — populate `data`, gate by role

```javascript
(function() {
    data.isAdmin = gs.hasRole('admin');
    if (!data.isAdmin) { return; }          // authorise server-side; never rely on hidden UI
    var svc = new SomeService();            // call Script Includes directly
    data.items = svc.getItems(options.group_id);   // options.* are widget instance options
})();
```

- Read widget options via `options.<name>` (define them in `option_schema` if you want
  them editable on the page).
- Put everything the client needs on `data`.

## 3. Client script — controller `c`, GlideAjax for changes

```javascript
function($scope, $interval, $timeout) {
    var c = this;
    c.items = c.data.items || [];

    c.refresh = function() {
        _ajax('ajaxGetItems', { sysparm_group: c.data.groupId }, function(res){
            c.items = res.items;
        });
    };

    function _ajax(method, params, cb) {
        var ga = new GlideAjax('SomeService');
        ga.addParam('sysparm_name', method);
        Object.keys(params).forEach(function(k){ ga.addParam(k, params[k]); });
        ga.getXMLAnswer(function(answer){
            var res = {}; try { res = JSON.parse(answer); } catch(e) { res = { error: 'Parse error' }; }
            cb(res);
            if (!$scope.$$phase) { $scope.$apply(); }
        });
    }
    // cancel any $interval/$timeout on $destroy
    $scope.$on('$destroy', function(){ /* $interval.cancel(...) */ });
}
```

Conventions to match (from the maintenance widgets): single `_ajax` helper; guard
`$scope.$apply()` with `if (!$scope.$$phase)`; recompute derived view state after each
async update; clean up timers on `$destroy`.

## 4. Template — AngularJS bindings, inline SVG

```html
<div class="oi-some-widget">
  <h3 class="oi-heading">{{c.data.title}}</h3>
  <div class="oi-row" ng-repeat="item in c.items">{{item.label}}</div>
  <button class="oi-btn" ng-click="c.refresh()">Refresh</button>
</div>
```

Use `ng-if`, `ng-repeat`, `ng-class`, `ng-click`. Illustrations are **inline SVG** in
the template (no external image URLs) — see `maintenance-overlay/template.html`.

## 5. Build the record

Insert `sp_widget` with `id`, `name`, `template`, `script`, `client_script`, `css`,
and `servicenow = false`. The `04_build_maintenance.js` `createOrSkip('sp_widget', ...)`
calls are the exact pattern; assemble each field from the four files as
`[...].join('\n')` (background script) or send as JSON strings (REST).

## 6. Place it and finish

- Add the widget to the relevant section/page (architecture: *Portal Interface*) and,
  if it should respect maintenance, ensure the Content Area widget governs it.
- Add the widget to the architecture's *Custom Widgets* table with its section and
  purpose.
- Commit the four source files under `scripts/widgets/<id>/` and follow the
  [maintenance protocol](../../maintenance/self-maintenance-protocol.md).
