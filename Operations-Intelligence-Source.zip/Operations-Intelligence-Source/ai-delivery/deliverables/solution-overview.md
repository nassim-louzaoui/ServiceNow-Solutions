# Operations Intelligence — Solution Overview for Operations Teams

*A complete, ready-to-share overview for the people who will use the platform day to
day. Generated from `context/` and the portal, workspace, and Virtual Agent sections
of the architecture canon. No placeholders.*

---

## What this gives you

Operations Intelligence is one place — the portal at `/operations_intelligence` —
where you and your team create and run the things you currently build by hand:
reports, dashboards, notifications, scheduled data emails, and more. You do it by
talking to the **Operations Assistant** in plain language. You never need to know
how ServiceNow works underneath.

## Your Operations Assistant

The Operations Assistant is a chat panel pinned to the right side of the portal,
always available. It opens with a greeting tailored to where you are and what you can
do. To create something, you describe it; the Assistant asks a few guided questions,
confirms what it understood, and takes care of the rest. If a technical detail is
needed that you do not know, it proposes one using AI and asks you to confirm or
adjust — it never applies anything without your sign-off.

## What you can ask it to make

Anyone on your team can request these, and they are created immediately:

- **A report or dashboard** — *"Show me open incidents for my group this month by
  priority."*
- **A notification rule** — *"Email my team whenever a change request assigned to us
  is approved."*
- **A scheduled data report** — *"Every Monday at 8am, email me a list of our open
  tasks older than a week."*

If your team has appointed you as a **creator**, you can additionally request:

- **A flow** — an automatic action that fires on an event, e.g. *"When a record is
  created in this table, assign it to this group and notify them."*
- **A custom table** — a new tracker to replace a spreadsheet, e.g. *"A table to log
  our meeting action items."* (Goes to your leader for approval first.)
- **A UI page** — a custom screen on top of a custom table. (Also approved first.)

## Your team's workspace

The **Workspace** section is where everything your team has lives, in three panels:

1. **Automations** — one card per automation available to you. On-demand ones have a
   *Trigger* button that starts a short guided conversation to run them; event-driven
   ones show their status and how often they have fired.
2. **Create New** — tiles for the things you are allowed to create. Clicking a tile
   opens the Assistant already set up for that request — you just start describing.
3. **Existing Deliverables** — one card per report, dashboard, notification, and so
   on that has been built for your team. Click any card to open it in a popup,
   without leaving the page.

Use the group selector at the top to focus on one group or see everything across all
the groups you belong to. You only ever see content for groups you are a member of.

## How a request works, end to end

Every creation follows the same simple shape:

1. **You describe it** in a guided conversation. Your progress is saved after every
   answer, so you can stop and resume any time.
2. **AI fills any gaps.** If something technical is missing, the Assistant proposes
   it and shows you exactly what it suggests.
3. **You review and confirm.** You can change anything before it is built.
4. **It is created** — immediately for reports, dashboards, notifications, scheduled
   jobs, and flows; after your leader approves for custom tables and UI pages — and
   you are notified with a reference.

## Keeping track of your requests

The **My Activity** section shows your own history: the automations you have run
(click any to see exactly what happened, step by step) and the deliverables you have
requested with their current status. If you left something half-finished, click it
to resume the conversation right where you left off.

## Getting started

You join the platform when your leader onboards you — you will receive an invitation
and complete a short first-login conversation that confirms your role and group. From
that point on, everything above is available to you. If you are set up as a creator
and want AI to help fill technical gaps, the Assistant will walk you through
connecting GitHub Copilot once; after that it is automatic.
