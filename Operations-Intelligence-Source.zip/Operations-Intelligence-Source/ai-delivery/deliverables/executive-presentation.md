# Operations Intelligence — Executive Presentation

*A complete, ready-to-present narrative for leadership and executive audiences.
Generated from the business canon (`context/`) using `../generation-logic.md`.
Contains no placeholders. Each slide is a talking section; the indented lines are
speaker notes.*

---

## Slide 1 — The hidden cost in operations

**Operations teams are running well below their potential, and the cause is
invisible because it has no single owner.**

> Across our operations portfolio, teams spend a large and growing share of their
> capacity on repetitive manual work — pulling the same data from ServiceNow,
> rebuilding the same reports and dashboards, configuring notifications one by one.
> None of it is individually large enough to prioritise, which is exactly why it is
> never automated. In aggregate it is displacing the project deliverables those
> teams exist to produce. This is delivery slippage with a thousand small causes and
> no visible one.

---

## Slide 2 — Three more barriers compound it

**Manual work is only the first barrier. Three more turn it into a structural drag.**

- **Blockers have no clear path to resolution.** Solving one requires articulating it
  technically, finding which specialised team owns it, reaching them, and waiting in
  their queue. Most operations staff can describe the problem but not specify it
  technically — so it stalls before anyone who can fix it ever sees it.
- **Capability is locked in individuals.** The knowledge of what ServiceNow can
  automate lives in a few skilled people. When they are busy or move on, the
  capability leaves with them.
- **Our operating model amplifies all of it.** Our deliberate specialisation — a
  dedicated team per subject — is a strength for depth, but it means just finding
  *who can help* is a multi-day effort before any work begins.

> The four barriers reinforce each other downward. We are paying repeatedly for the
> same manual work while the capability to remove it sits one coordination barrier
> away.

---

## Slide 3 — What we are putting in place

**Operations Intelligence: one shared platform that lets any operations team create,
govern, and run automations and deliverables — through plain-language conversation,
with no technical skill required.**

> It is a single ServiceNow application, shared across all operations teams, at one
> portal. A user describes what they need in everyday language — "a weekly report of
> open incidents for my group by priority," "email my team whenever a change is
> approved." The system captures the requirement, fills any technical gap with AI,
> routes it for the right approval, and builds it. The barrier between *knowing what
> you need* and *having it* becomes a conversation.

---

## Slide 4 — How it works, for your team

**Three moves, none of which require technical knowledge.**

1. **Describe it.** A team member tells the Operations Assistant, in plain English,
   what they want. A guided conversation captures the detail.
2. **AI fills the gap, the person confirms.** When a technical detail is missing,
   GitHub Copilot proposes it; the user reviews and confirms. Nothing is ever
   applied silently.
3. **It gets built and it runs.** The deliverable is created in ServiceNow and
   managed there for its whole life. What used to be redone every cycle is now
   requested once and runs permanently.

---

## Slide 5 — Governance: control and speed, together

**Oversight is automatic and proportional to impact — so governance never becomes
the new bottleneck.**

- Reports, dashboards, notifications, and scheduled data jobs are created
  immediately — no system-level risk.
- Flows are created immediately, with leadership notified and able to deactivate.
- Custom tables and UI pages require leadership approval before anything is built.
- Approvals route automatically to the right person (normally the requester's
  manager), with a deadline and **automatic escalation** if they do not respond.
- Leadership has real-time visibility of everything across their groups and can
  deactivate anything immediately.

> You are not administering a process. The system runs governance for you, and it is
> as strict as the risk warrants and no stricter.

---

## Slide 6 — The value, and why it compounds

**Every problem becomes a compounding gain.**

| Today | With Operations Intelligence |
|---|---|
| The same manual task, every cycle, forever | Requested once, runs permanently |
| Blockers stall in translation and routing | Captured in plain language, routed automatically |
| Capability depends on a scarce specialist | Capability lives in the system, always available |
| ServiceNow used only as a data source | ServiceNow realised as the automation platform we already own |
| Governance is slow and manual | Governance is automatic, proportional, real-time |

> The gain is not linear. Every task automated frees capacity to find the next one.
> Every blocker resolved leaves a reusable pattern. Every team onboarded widens a
> shared, governed catalogue the next team adopts without starting from zero.

---

## Slide 7 — What we ask of leadership

**Adoption starts at the top of each team and flows down — through the same
conversational system.**

- Leadership is onboarded into the platform first.
- Each leader then onboards their direct reports and appoints creators — all guided
  step by step by the Operations Assistant, no technical setup.
- From there, teams self-serve, and leadership retains full visibility and override.

> The ask is small and one-time: onboard your team. The return is continuous: capacity
> returned to delivery, blockers resolved without coordination overhead, and a
> governed platform that gets more valuable as it spreads.
