# AI Delivery — Producing Deliverables From the Source of Truth

This folder is the **production engine** of the repository. It turns the canon
(`context/` and `architecture/`) into finished, audience-appropriate deliverables:
presentations, solution overviews, technical briefings, and any documentation built
from the same material.

It contains two things:

| File / folder | Role |
|---|---|
| [`generation-logic.md`](generation-logic.md) | The **logic**: how any AI should select the audience, map the right source sections, assemble the output, and meet the quality bar. Read this first. |
| [`deliverables/`](deliverables/) | Three **complete, regenerate-able deliverables** — no placeholders. They are simultaneously ready to use and worked examples of the logic applied. |

## How to use this folder

1. Read [`generation-logic.md`](generation-logic.md).
2. Identify the deliverable type and audience.
3. If one of the three deliverables in `deliverables/` matches, adapt it directly —
   it is already complete and current. If it does not, apply the generation logic to
   the canon to produce a new one, following the same structure and quality bar.
4. Verify every claim in the output against the canon before delivering it.

## The three reference deliverables

| File | Audience | Built from |
|---|---|---|
| [`deliverables/executive-presentation.md`](deliverables/executive-presentation.md) | Leadership / executives | `context/` (all four files) + the governance and value framing |
| [`deliverables/solution-overview.md`](deliverables/solution-overview.md) | Operations teams (end users) | `context/` + portal, workspace, and Virtual Agent sections of the architecture |
| [`deliverables/technical-briefing.md`](deliverables/technical-briefing.md) | Platform / IT teams | the full technical canon |

## Why these are complete, not templates

An earlier instinct is to ship fill-in-the-blank templates. This repository does not:
a blank with `[insert value here]` is a deferral, not a deliverable, and it rots
because nobody updates a placeholder. Each file in `deliverables/` is written out in
full from the current canon. When the platform changes, these are regenerated from
the canon (the maintenance protocol requires it), so they stay both complete and
correct.
