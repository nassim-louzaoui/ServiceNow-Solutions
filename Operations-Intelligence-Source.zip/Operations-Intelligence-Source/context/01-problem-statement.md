# Problem Statement

## The shape of the problem

Operations teams across Infosys are spending a large and growing share of their
capacity on work that is repetitive, manual, and avoidable — and that spending is
quietly displacing the project deliverables those teams actually exist to produce.
The problem is not a single broken process. It is a structural pattern that repeats
across hundreds of teams, and it has four reinforcing parts.

## 1. Recurring manual effort that should be automated

A great deal of routine operations work is done by hand, every cycle, by people:

- Extracting data from ServiceNow for week-over-week or sprint-over-sprint
  comparisons.
- Building and rebuilding reports and dashboards from scratch.
- Configuring notifications and alerts one at a time.
- Assembling the same status views and data pulls that were assembled last week.

Each instance is individually small, which is exactly why it is never prioritised
for automation. In aggregate it consumes a significant fraction of team capacity,
and that capacity comes directly out of the time available for real project
deliverables. The result is delivery slippage that has no single visible cause —
it is death by a thousand manual tasks.

## 2. No structured way to capture and resolve blockers

When a team hits a blocker — a broken process, a missing data structure, a workflow
that needs a system change — there is no consistent path from "we are stuck" to
"it is solved." Resolution depends on someone being able to:

1. articulate the blocker precisely enough that a technical team can act on it,
2. work out which specialised team owns that area,
3. reach the right person there, and
4. wait in their queue.

Most operations staff are equipped to describe the problem in business terms but
not to translate it into a technical specification. The blocker therefore stalls at
step 1, long before anyone with the skill to fix it ever sees it.

## 3. Capability locked inside individuals, not systems

Many of the optimisations that would most help a team depend on knowing that a
particular ServiceNow capability exists and can be configured to remove a specific
piece of manual work. That knowledge lives in a small number of technically skilled
individuals. When those individuals are busy, reassigned, or gone, the knowledge
leaves with them, and the team has no way to discover what is possible or to request
it without technical mediation. Teams cannot optimise what they do not know they are
allowed to ask for.

## 4. The Infosys environment amplifies every gap above

Infosys deliberately runs a highly specialised operating model: rather than a few
generalist points of contact, there is a dedicated team for nearly every subject
area. This is a strength for depth, but it creates a heavy coordination tax for
anyone who must work *across* those teams. With an extremely large number of
projects and dedicated teams, simply identifying *who can help* — who owns a
capability, who can approve a change, who has authority to unblock a dependency —
is itself a multi-day effort. Operations teams burn real time navigating the
organisation before any actual work begins.

## The consequence

Put together, these four parts produce a predictable outcome: operations teams run
well below their potential efficiency, project deliverables are delayed by overhead
that nobody chose and nobody owns, and ServiceNow — already in place as the system
of record — goes massively under-exploited as the automation platform it could be.
The organisation is paying for the same manual work to be re-done indefinitely while
the capability to eliminate it sits one coordination barrier away.
