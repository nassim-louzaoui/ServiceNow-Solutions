# Context — The Business Canon and System Identity

This folder is the authoritative business narrative for Operations Intelligence
and the live system identity. It answers *why the platform exists*, *what it is
for*, and *how to connect to it right now*.

Read the five files in order — the first four form a single business argument,
the fifth is the operational identity:

| File | Answers |
|---|---|
| [`01-problem-statement.md`](01-problem-statement.md) | What is wrong today, and why it costs the organisation |
| [`02-business-value.md`](02-business-value.md) | What value is unlocked by fixing it |
| [`03-desired-future-state.md`](03-desired-future-state.md) | What "good" looks like once it is fixed |
| [`04-proposed-solution.md`](04-proposed-solution.md) | How Operations Intelligence delivers that future state |
| [`05-system-context.md`](05-system-context.md) | Live credentials, instance, engine endpoint, and non-negotiable standards |

Any business-facing deliverable draws non-technical content from files 01–04.
Any AI or integration needing to connect to the live instance reads file 05.
Technical canon lives in [`../architecture/`](../architecture/) — this folder
never duplicates it.
