# System Context and Credentials

This file is the operational identity of the live Operations Intelligence instance.
Any AI or integration that needs to connect to the platform, authenticate, or issue
operations reads this file.

---

## Instance Identity

| Property | Value |
|---|---|
| Platform | Operations Intelligence |
| Application Scope | `x_infte_ops_int` |
| Instance URL | `https://everestdev.service-now.com` |
| Engine Endpoint | `POST /api/x_infte_ops_int/ops_int_engine/v1` |
| Service Account | `svc_operations_intelligence_api` |
| Service Account Sys ID | `94a5973dfb6dcb5052eef5c9beefdc77` |
| Engine Key Property | `x_infte_ops_int.engine_key` |
| Service Account Password Property | `x_infte_ops_int.svc_password` |

---

## Credentials

| Variable | Value |
|---|---|
| Instance URL | `https://everestdev.service-now.com` |
| Service Account Username | `svc_operations_intelligence_api` |
| Service Account Password | `H!^j46ZKAHA7RLfDb6Va97Pu7pB8sTcF` |
| Engine API Key | `EPpXxygqG5AvP8zEPAQ847sFqW6NGqYYp5P6VWJn` |

---

## Calling the Engine

Every engine request requires both Basic Auth and the engine key header:

```
POST https://everestdev.service-now.com/api/x_infte_ops_int/ops_int_engine/v1
Authorization: Basic c3ZjX29wZXJhdGlvbnNfaW50ZWxsaWdlbmNlX2FwaTpIIV5qNDZaS0FIQTdSTGZEYjZWYTk3UHU3UEI4c1RjRg==
X-Engine-Key: EPpXxygqG5AvP8zEPAQ847sFqW6NGqYYp5P6VWJn
Content-Type: application/json
```

Single operation:
```json
{"op": "<name>", "data": { ... }, "table": "<table>", "query": { ... }, "limit": 100}
```

Batch:
```json
{"op": "batch", "ops": [{"op": "ping"}, {"op": "now"}], "stop_on_error": true}
```

Platform writes (bypass scoped sandbox, write to any table):
```json
{"op": "record.insert", "table": "sys_script_include", "platform": true, "data": {...}}
```

ServiceNow wraps all responses: `{"result": {...}}`. Unwrap `.result` before reading.

Send `{"op": "help"}` for the annotated operation list.
Send `{"op": "engine.status"}` for health, inventory, and update set state.

---

## Non-Negotiable Standards

The following are not preferences — they are constraints built into the platform.
Getting them wrong produces an incorrect or insecure result.

**Naming.** Every artifact name, role name, update set name, table label, notification
name, and description must be proper title case with full words and no abbreviations.
"Operations Intelligence", not "OI" or "ops_int". "Script Include", not "SI". API
identifiers (e.g. `x_infte_ops_int.engine_key`) follow ServiceNow conventions;
display names do not.

**Scope isolation.** Every artifact belongs to `x_infte_ops_int`. All artifact and
schema engine operations set `sys_scope` to the application scope automatically.
`sys_properties` is the only platform-global table and the only intentional exception.

**Update set.** The engine maintains exactly one update set named "Operations
Intelligence" (state: in progress). It is created on the first configuration write
and never duplicated. `engine.status` returns its sys_id and state.

**Engine script — ES5 only.** No template literals (backticks), no `let`/`const`,
no arrow functions, no destructuring, no `eval()`. Template literals cause a Rhino
parse error at load time, disabling the entire engine silently.

**Engine script — no inline comments.** The function body contains no `//` comments.
A formal header block at the top of the file covers scope, endpoint, auth, request
format, and operation catalog only.

**AI identity.** No AI tool, model, or vendor name may appear in any artifact name,
property key, Script Include name, role name, or any configuration record.
