# Desired Future State

This file describes what working life looks like once Operations Intelligence is in
place — concretely, from the point of view of the people involved. It is the target
the [proposed solution](04-proposed-solution.md) is designed to reach, and the
standard against which the platform's success is judged.

## For an operations team member (a "user")

You no longer build the same report by hand every week. The first time you need it,
you tell the Operations Assistant — in plain language — what you want to see, and it
exists from then on. When you hit a blocker, you describe it in business terms and
the system turns it into a structured request and routes it to the right person; you
do not have to find that person yourself. You can see, in one place, everything your
team has: the automations available to you, the deliverables that have been built,
and the status of anything you have requested. You never learn a technical interface
to do any of this.

## For a power user who builds for the team (a "creator")

You design automations and deliverables for your group through a guided
conversation, not a development project. When you know the technical detail, you
supply it; when you do not, Copilot proposes it and you confirm or adjust. You build
flows, request custom tables, and create reports without writing code or filing
tickets to another team. You manage everything you have built — edit, deactivate,
archive — from one studio view, and you always know what is pending approval and when
it is due.

## For a leader

You onboard your team into the platform through the Operations Assistant. You see
every automation and deliverable across your groups in real time, with the metrics
that tell you what they are saving. Approvals for impactful changes come to you
automatically, with a clear deadline; if you cannot act in time, they escalate
without you having to arrange it. You can deactivate anything in your groups
immediately if you need to. Governance is something the system runs for you, not a
process you administer.

## For the organisation

Manual operations overhead is no longer an invisible, uncounted drain. Capacity is
returned to project delivery, measurably, as automations replace recurring tasks.
The coordination tax of the specialised operating model is bypassed for the large
class of needs the platform can serve directly. ServiceNow is finally used to its
potential as an automation platform across operations, and the proven patterns one
team creates spread to others through a shared, governed catalogue. Capability lives
in the system, available to every team, independent of who happens to be on the
programme this quarter.

## The single defining characteristic

In the future state, **the barrier between "I know what I need" and "it exists" is a
conversation, not a project, a ticket, or a search for the right specialist.** Every
design decision in the platform serves that one outcome.
