# Proposed Solution

Operations Intelligence is a single ServiceNow scoped application, shared by all
operations teams, that turns the [desired future state](03-desired-future-state.md)
into the actual operating model. This file explains *how* the solution works at the
level a business audience needs. The complete technical specification — every table,
Script Include, ACL, and build step — is the technical canon in
[`../architecture/solution-architecture.md`](../architecture/solution-architecture.md).
This file does not repeat it; it explains the design choices that make the value real.

## One platform, one entry point

The entire solution lives at a single portal, `/operations_intelligence`. There is
no separate tool per role and no navigation between systems. A user sees the sections
their role permits — Workspace and My Activity for everyone, plus Studio for
creators, Governance for leadership, and Command for admins — all within the same
interface, switching without page reloads. One place to learn, one place to work.

## Natural language is the interface

The primary way anyone interacts with the platform is the **Operations Assistant**,
a dedicated Virtual Agent. Users describe what they need in plain English —
*"a weekly report of open incidents for my group by priority,"* *"email my team
whenever a change request is approved,"* *"a tracker for our meeting action items"* —
and the Assistant runs a guided conversation that captures the requirement, confirms
it, and drives the technical creation. This is what removes the need for technical
knowledge and what collapses the articulation-and-routing barrier that strands
blockers today.

## AI fills the technical gap, the human stays in control

When a requirement needs a technical detail the user cannot supply, GitHub Copilot
generates the specification automatically — field selections, conditions, chart
types, table schemas, flow logic. The system then shows the user exactly what it
proposes and asks them to confirm or adjust each part. **Nothing is applied
silently.** This is the mechanism that dissolves the dependency on scarce
specialists: the system provides the technical capability, and the user provides and
validates the intent. If Copilot is unavailable for any reason, the conversation
falls back to targeted questions and the user still ends up with a complete result.

## Governance that is automatic and proportional

Impact determines oversight. Reports, dashboards, notification rules, and scheduled
data jobs are created immediately — they carry no system-level risk. Flows are
created immediately but leadership is notified and can deactivate them. Custom tables
and UI pages, which change data structure and carry script capability, require
leadership approval before anything is built. Approvals route automatically to the
right person (normally the requester's manager) with a deadline and automatic
escalation if they do not respond — so control never becomes the new bottleneck.
Leadership has real-time visibility and immediate override across all of it.

## Group-scoped and self-contained

Every operations team is a group. Automations and deliverables are scoped to the
groups that need them; teams do not see each other's work unless it is explicitly
shared, and cross-group sharing passes through the receiving group's approver. This
keeps boundaries clear while still letting a proven pattern spread deliberately from
one team to the next.

## Two creative tracks, one consistent experience

The platform supports two kinds of creation through the same conversational model:

- **Process automations** — multi-step sequences (create records, query data,
  trigger approved flows, send notifications, branch on conditions) that run on
  demand or on a schedule.
- **Persistent deliverables** — reports, dashboards, notification rules, scheduled
  data jobs, flows, custom tables, and UI pages that exist as durable ServiceNow
  artifacts and are managed for their whole lifecycle through the platform.

Both are requested in natural language, both use Copilot to fill gaps, and both are
governed by the same role and approval model. The user experiences one coherent
system, not two.

## Why this design delivers the value

Each design choice maps directly to a problem and a value:

| Design choice | Removes the problem of… | Delivers the value of… |
|---|---|---|
| Natural-language Operations Assistant | Needing technical skill to ask | Self-service creation by anyone |
| Automatic Copilot gap-fill, human-confirmed | Dependency on scarce specialists | Capability on demand, control retained |
| One shared portal, group-scoped content | Coordination tax of the org model | Direct self-service with clear boundaries |
| Automatic, proportional approval routing | Slow, manual governance | Speed and control together |
| Durable, OI-managed deliverables | Re-doing the same manual work | One-time requests that run forever |

The result is the future state stated plainly: the distance between knowing what you
need and having it becomes a conversation.
