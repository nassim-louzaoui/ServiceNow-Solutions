# Operations Intelligence — System Context and Credentials

## Identity

| | |
|---|---|
| Platform | Operations Intelligence |
| Application Scope | x_infte_ops_int |
| Instance | https://everestdev.service-now.com |
| Engine Endpoint | POST /api/x_infte_ops_int/ops_int_engine/v1 |
| Service Account | svc_operations_intelligence_api |
| Service Account Sys ID | 94a5973dfb6dcb5052eef5c9beefdc77 |

---

## Credentials

| Variable | Value | Purpose |
|---|---|---|
| SNOW_INSTANCE | https://everestdev.service-now.com | Instance base URL |
| SNOW_USER | svc_operations_intelligence_api | Service account username |
| SNOW_PASS | H!^j46ZKAHA7RLfDb6Va97Pu7pB8sTcF | Service account password |
| ENGINE_KEY | EPpXxygqG5AvP8zEPAQ847sFqW6NGqYYp5P6VWJn | Engine API key |
| ENGINE_ENDPOINT | /api/x_infte_ops_int/ops_int_engine/v1 | Engine route |
| SVC_SYS_ID | 94a5973dfb6dcb5052eef5c9beefdc77 | Service account sys_id |
| APP_SCOPE | x_infte_ops_int | Application scope prefix |

Authentication on every engine request:
- Header: `X-Engine-Key: EPpXxygqG5AvP8zEPAQ847sFqW6NGqYYp5P6VWJn`
- Basic Auth: `svc_operations_intelligence_api:H!^j46ZKAHA7RLfDb6Va97Pu7pB8sTcF`

---

## Non-Negotiable Standards

**Naming.** Every artifact name, description, label, role name, update set name, table name, and notification name must be proper title case with full words and no abbreviations. "Operations Intelligence", not "ops_int" or "OI". "Script Include", not "SI". "Service Account", not "SVC Acct". API identifiers follow ServiceNow conventions (e.g. `x_infte_ops_int.engine_key`) — display names do not.

**Scope isolation.** Every artifact belongs to `x_infte_ops_int`. All `artifact.*` and `schema.*` operations set `sys_scope` to the application scope automatically. `sys_properties` is the only platform-global table in use and is the only intentional exception.

**Update set.** The engine maintains exactly one update set named "Operations Intelligence" (state: in progress). It is created on first configuration write and never duplicated. `engine.status` returns its sys_id and state.

**Engine script — no inline comments.** The function body contains no `//` comments. The file starts with a formal header block covering scope, endpoint, authentication, request format, and operation catalog only. No operator instructions, no deployment steps.

**Engine script — ES5 only.** No template literals (backticks), no `let`/`const`, no arrow functions, no destructuring, no `eval()`. ServiceNow's Rhino engine rejects template literals at parse time when stored as a Scripted REST operation script — this causes total engine failure.

**AI identity.** No AI tool, model, or vendor name may appear in any artifact, record, property name, Script Include, or configuration of any kind.

---

## Engine

### Calling the Engine

Single operation:
```
POST https://everestdev.service-now.com/api/x_infte_ops_int/ops_int_engine/v1
Authorization: Basic c3ZjX29wZXJhdGlvbnNfaW50ZWxsaWdlbmNlX2FwaTpIIV5qNDZaS0FIQTdSTGZEYjZWYTk3UHU3UEI4c1RjRg==
Content-Type: application/json
X-Engine-Key: EPpXxygqG5AvP8zEPAQ847sFqW6NGqYYp5P6VWJn

{"op": "<name>", "data": { ... }, "table": "<table>", "query": { ... }, "limit": 100}
```

Batch:
```json
{"op": "batch", "ops": [{"op": "ping"}, {"op": "now", "label": "ts"}], "stop_on_error": true}
```

ServiceNow wraps all responses: `{"result": { ... }}`. Unwrap `.result` before reading fields.

Platform writes: add `"platform": true` to any record operation. Routes through the Table API as `svc_operations_intelligence_api`, bypassing the scoped sandbox. Required for writing to tables outside the app scope.

Send `{"op": "help"}` for the full annotated operation list. Send `{"op": "engine.status"}` for health, inventory, and update set state.

### Operation Summary (117 operations)

| Group | Operations |
|---|---|
| DIAGNOSTICS | `ping` · `now` · `scope.info` · `engine.status` · `selftest` · `help` · `sys.version` |
| DISCOVERY | `meta.tables` · `meta.script_includes` · `meta.business_rules` · `meta.notifications` · `meta.widgets` · `meta.jobs` · `meta.acls` · `meta.all` · `meta.ui_pages` · `meta.portal_pages` · `meta.catalog_items` · `meta.app_menus` · `meta.app_modules` · `meta.events` · `meta.roles` · `meta.portals` · `table.exists` · `schema.fields` · `table.schema` |
| DDL | `schema.table.create` · `schema.table.delete` · `schema.table.extend` · `schema.add_field` · `schema.field.update` · `schema.field.delete` · `schema.add_choice` · `schema.choice.update` · `schema.choice.delete` · `schema.set_autonumber` · `schema.index.create` |
| PROPERTIES | `property.set` · `property.get` · `property.list` · `property.delete` |
| RECORDS | `record.insert` · `record.insert_many` · `record.update` · `record.patch` · `record.upsert` · `record.delete` · `record.bulk_delete` · `record.get` · `record.find` · `record.query` · `record.clone` · `record.count` · `record.aggregate` · `record.history` · `record.exists` · `record.read_many` · `table.truncate` |
| ACL | `acl.create` · `acl.delete` · `acl.list` |
| ACCESS | `role.grant` · `role.revoke` · `user.roles` |
| USERS | `user.create` · `user.get` · `user.update` · `user.search` |
| GROUPS | `group.create` · `group.add_member` · `group.remove_member` · `group.members` · `group.search` |
| UPDATE SETS | `update_set.create` · `update_set.activate` · `update_set.list` |
| ARTIFACTS | `artifact.script_include` · `artifact.business_rule` · `artifact.notification` · `artifact.scheduled_job` · `artifact.client_script` · `artifact.ui_action` · `artifact.widget` · `artifact.ui_page` · `artifact.sp_page` · `artifact.sp_container` · `artifact.sp_row` · `artifact.sp_column` · `artifact.sp_instance` · `artifact.sp_theme` · `artifact.app_menu` · `artifact.app_module` · `artifact.catalog_item` · `artifact.catalog_variable` · `artifact.ui_policy` · `artifact.ui_policy_action` · `artifact.event_registry` · `artifact.report` · `artifact.role` · `artifact.sp_portal` |
| FILES | `attachment.write` · `attachment.read` · `attachment.list` · `attachment.delete` |
| POWER | `script.run` · `rest.call` · `event.fire` · `sys.log` · `cache.flush` · `sys.id` · `note.add` |
| WORKFLOW | `workflow.start` · `workflow.cancel` |
| EMAIL | `email.send` |
| ENGINE | `engine.source` · `engine.selfupdate` |
| BATCH | `batch` |
