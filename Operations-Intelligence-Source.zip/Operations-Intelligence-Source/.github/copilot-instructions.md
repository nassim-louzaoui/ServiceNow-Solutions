# Operations Intelligence — Instructions for AI Working in This Repository

You are working inside the **single source of truth** for the Operations
Intelligence platform. This file is loaded automatically every session. Read it
fully before acting.

---

## 1. What the Platform Is

Operations Intelligence is a ServiceNow scoped application (`x_infte_ops_int`) that
lets Infosys operations teams create, govern, and execute process automations and
persistent ServiceNow deliverables entirely through natural language, via a dedicated
Virtual Agent called the **Operations Assistant**. When a user cannot supply a
technical detail, GitHub Copilot generates the specification and the user confirms
it. Role-appropriate approval workflows govern impactful changes. Everything lives
at one portal: `/operations_intelligence`.

For the *why* in depth, read [`../context/`](../context/). For credentials and
system context, read [`../context/00-credentials-and-context.md`](../context/00-credentials-and-context.md).
For the *what* in full, read [`../architecture/solution-architecture.md`](../architecture/solution-architecture.md).

---

## 2. The Authority Order (resolve every conflict with this)

1. [`../architecture/solution-architecture.md`](../architecture/solution-architecture.md)
   — authoritative for all **technical** facts.
2. [`../context/`](../context/) — authoritative for all **business** facts and
   live system context (credentials, instance, identifiers).
3. [`../implementation/`](../implementation/) — verbatim artifact source; must match
   the architecture and the live instance.
4. Everything else is **derived** and must yield to the above.

---

## 3. How to Read This Repository

- `ai-guide/operating-guide.md` — start here for any task.
- `context/00-credentials-and-context.md` — live credentials, instance URL, engine endpoint.
- `context/` — business narrative: problem, value, future state, solution.
- `architecture/solution-architecture.md` — the complete technical specification.
- `implementation/coding-patterns.md` — the canonical patterns every artifact follows.
- `implementation/rest-api-guide.md` — building over HTTP; see also the engine API in context/00.
- `implementation/recipes/` — step-by-step "add one artifact" procedures.
- `implementation/scripts/` — exact, deployable source for background scripts, Script Includes, and widgets.
- `implementation/build-order.md` — the deploy sequence and background scripts.
- `reference/glossary.md` — the exact spelling of every term and identifier.
- `maintenance/self-maintenance-protocol.md` — how to keep this repository true.

---

## 4. Non-Negotiable Technical Facts

- Application scope prefix: `x_infte_ops_int`. Custom tables: `x_infte_ops_int_<name>`.
- Service account: `svc_operations_intelligence_api`. Sys ID: `94a5973dfb6dcb5052eef5c9beefdc77`.
- Engine endpoint: `POST /api/x_infte_ops_int/ops_int_engine/v1`. Auth: `X-Engine-Key` header.
- `system_role` is **never** stored on `person`. Read roles via `gs.hasRole()`.
- `creator_credential.github_pat` has **Read ACL = NOBODY**, including admin.
- `managed_artifact.artifact_sys_ids` is readable by admin and System only.
- `sysauto_script` is used **only** by `ScheduleManager` for automation scheduling.
- Approval escalation **updates** the existing `pending_action` record — never creates a second.
- CopilotBridge makes one bounded call; on any failure it falls back silently.
- **Update set:** the engine maintains exactly one update set named "Operations Intelligence" (never duplicated).
- **ES5 only** in engine script: no backticks, no `let`/`const`, no arrow functions, no destructuring, no `eval()`.
- **No inline comments** in the engine script body. Formal header only (scope, endpoint, auth, request format, operation catalog).
- **No AI identity** in any artifact, property, Script Include, or configuration name.
- **Naming:** title case, full words, no abbreviations in all display names and descriptions.

---

## 5. When You Build or Implement

Confirm where the artifact fits in [`../implementation/build-order.md`](../implementation/build-order.md);
choose the mechanism (engine operation, in-instance background script, or REST);
follow [`../implementation/coding-patterns.md`](../implementation/coding-patterns.md);
use the matching recipe in [`../implementation/recipes/`](../implementation/recipes/);
build from the **verbatim** source in [`../implementation/scripts/`](../implementation/scripts/).

## 6. When You Generate a Deliverable

Go to [`../ai-delivery/`](../ai-delivery/README.md). Apply
[`../ai-delivery/generation-logic.md`](../ai-delivery/generation-logic.md).

## 7. When the Platform Changes, Change This Repository

Follow [`../maintenance/self-maintenance-protocol.md`](../maintenance/self-maintenance-protocol.md)
exactly. Never add a changelog, a "v2" note, or dated history to file content. Edit
the file so it states the new current truth. Git history is the only history.
