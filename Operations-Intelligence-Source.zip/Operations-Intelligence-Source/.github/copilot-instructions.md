# Operations Intelligence — Instructions for AI Working in This System

You are working inside the **single source of truth** for the Operations Intelligence
platform. This file is loaded automatically every session. Read it fully before
acting. For detailed operating procedures, read `../AI-GUIDE.md`.

---

## 1. What the Platform Is

Operations Intelligence is a ServiceNow scoped application (`x_infte_ops_int`) that
lets Infosys operations teams create, govern, and execute process automations and
persistent ServiceNow deliverables entirely through natural language, via a dedicated
Virtual Agent called the **Operations Assistant**. Role-appropriate approval workflows
govern impactful changes. Everything lives at one portal: `/operations_intelligence`.

---

## 2. The Authority Order

1. `../architecture/solution-architecture.md` — all technical facts
2. `../context/` — all business facts; live credentials and identifiers
3. `../implementation/` — verbatim artifact source; must match architecture and instance
4. Everything else — derived; yields to the above

If two files disagree, the higher authority is correct. The lower file is wrong.

---

## 3. Structure Index

| Path | Role |
|---|---|
| `AI-GUIDE.md` | Comprehensive AI operating instructions — read first |
| `context/05-system-context.md` | Live credentials, instance URL, engine endpoint |
| `architecture/solution-architecture.md` | Complete technical specification |
| `implementation/documentation/` | Build order, coding patterns, engine API, REST guide, recipes |
| `implementation/source/` | Verbatim deployed code: engine, Script Includes, widgets |
| `reference/glossary.md` | Canonical spelling of every term and identifier |
| `maintenance/self-maintenance-protocol.md` | How to keep this source current |
| `ai-guide/operating-guide.md` | Step-by-step procedures for each request type |
| `ai-delivery/` | Logic and worked deliverables for presentations, overviews, briefings |

---

## 4. Non-Negotiable Technical Facts

- Scope prefix: `x_infte_ops_int`. Tables: `x_infte_ops_int_<name>`.
- Service account: `svc_operations_intelligence_api`.
- Engine: `POST /api/x_infte_ops_int/ops_int_engine/v1`. Auth: `X-Engine-Key` header.
- Update set: exactly one, named "Operations Intelligence". Never duplicated.
- ES5 only in Rhino-executed scripts. No backticks, `let`/`const`, arrow functions,
  destructuring, or `eval()`.
- No inline comments in the engine script body.
- `creator_credential.github_pat` — Read ACL = NOBODY including admin.
- `managed_artifact.artifact_sys_ids` — admin and System only.
- Approval escalation updates the existing `pending_action` — never creates a second.
- No AI identity in any artifact name, property, Script Include, or configuration.
- Naming: title case, full words, no abbreviations in display names.

---

## 5. When the Platform Changes, Change This Source

Follow `../maintenance/self-maintenance-protocol.md` exactly. Update the technical
canon, verbatim source, business canon if needed, and affected deliverables — in the
same change. Never add a changelog or dated note. Edit files so they state the new
current truth. Git history is the only history.
