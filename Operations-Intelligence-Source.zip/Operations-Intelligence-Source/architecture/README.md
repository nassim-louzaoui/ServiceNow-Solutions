# Architecture — The Technical Canon

This folder holds the authoritative technical specification of Operations
Intelligence in a single file:
[`solution-architecture.md`](solution-architecture.md).

It is the highest authority for every technical fact in this repository. When any
other file disagrees with it, this file is correct and the other file must be fixed
(see [`../maintenance/self-maintenance-protocol.md`](../maintenance/self-maintenance-protocol.md)).

## What the specification covers

The document is self-contained and ordered for building. Its major sections:

| Area | What it defines |
|---|---|
| Platform overview, naming, roles, hierarchy | Scope prefix convention, the four roles, the organisational and delegation model |
| Group model | Leadership vs custom groups, group roles, hierarchy |
| Data model | All 19 custom tables with every field, plus table-level notes |
| Deliverable types & governance | The governance matrix, builder dispatch, creation flows |
| Group Workspace interface | The three-panel workspace and cross-group surfacing |
| Lifecycles | Managed-artifact and automation lifecycles, deactivation, onboarding |
| Copilot role | Automatic gap-fill for deliverables and phrase generation for automations |
| Script Includes | All 21 includes in dependency (build) order |
| Business Rules | All 5 rules with full scripts |
| Security & access control | Complete table, row, and field ACLs; auditing |
| Virtual Agent architecture | Channel, NLU model, the 23 system topics, per-automation topic structure |
| CopilotBridge API | The request contracts, PAT access pattern, timeout and fallback |
| Notifications | All 22 templates with triggers and recipients |
| Portal interface | Portal, pages, navigation, sections, and all custom widgets |
| Maintenance mode | Property model, overlay and control-panel widgets, export gate, audit events |
| Action types & schemas | The 8 automation step action types with configuration JSON |
| Scheduled jobs & properties | All 5 jobs and all key configuration properties |
| Setup, migration, build order | Studio setup, update-set strategy, the 15-step build sequence, the 30-item end-to-end test checklist |

## Relationship to the rest of the repository

- The verbatim, deployable source for the artifacts described here lives in
  [`../implementation/`](../implementation/README.md). The implementation source and
  this specification must always agree.
- Business framing for these capabilities lives in [`../context/`](../context/).
- Audience-specific renderings (briefings, overviews, presentations) are generated
  from this file via [`../ai-delivery/`](../ai-delivery/README.md).
