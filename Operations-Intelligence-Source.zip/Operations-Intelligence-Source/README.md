# Operations Intelligence Source

The single source of truth for the Operations Intelligence platform — a ServiceNow
scoped application (`x_infte_ops_int`) that lets Infosys operations teams create,
govern, and run automations and persistent ServiceNow deliverables entirely through
natural language.

This is not a document archive. It is a living, structured knowledge system with
a defined role for every folder, files that reference one another rather than
repeating content, and explicit rules that keep it current as the platform evolves.

---

## Structure

| Folder | Role |
|---|---|
| [`context/`](context/) | **Why** — business narrative, problem, value, desired state, solution, and live system context |
| [`architecture/`](architecture/) | **What** — the complete technical specification: all tables, Script Includes, ACLs, roles, VA topics, widgets, and build sequence |
| [`implementation/`](implementation/) | **How** — implementation documentation (patterns, guides, recipes) and verbatim deployable source (engine, Script Includes, widgets) |
| [`reference/`](reference/) | **Look up** — canonical glossary of every term, role, and identifier |
| [`ai-delivery/`](ai-delivery/) | **Produce** — logic and worked examples for generating presentations, overviews, and briefings |
| [`ai-guide/`](ai-guide/) | **Operate** — step-by-step AI operating procedures for every request type |
| [`maintenance/`](maintenance/) | **Sustain** — the protocol that keeps this source true |
| [`.github/`](.github/copilot-instructions.md) | **Load** — auto-loaded by Claude Code and GitHub Copilot every session |

**Two loose files at root only:**
- This `README.md` — system entry point
- [`AI-GUIDE.md`](AI-GUIDE.md) — comprehensive instructions for any AI working in this system

---

## Two Canons

All derived material defers to two authoritative sources. When any other file
disagrees with either, the canon is correct and the other file is wrong.

1. **Business canon** — [`context/`](context/). The problem, value, future state,
   and solution, written once. Also contains live system context and credentials.
2. **Technical canon** — [`architecture/solution-architecture.md`](architecture/solution-architecture.md).
   The complete technical specification of the platform.

---

## Navigation

- **AI starting work here?** Read [`AI-GUIDE.md`](AI-GUIDE.md) first, then
  [`ai-guide/operating-guide.md`](ai-guide/operating-guide.md) for procedures.
- **Need credentials or instance details?** [`context/05-system-context.md`](context/05-system-context.md).
- **Building or extending the platform?** Start at
  [`implementation/documentation/build-order.md`](implementation/documentation/build-order.md).
- **Need the exact name of something?** [`reference/glossary.md`](reference/glossary.md).
- **Platform changed?** Follow [`maintenance/self-maintenance-protocol.md`](maintenance/self-maintenance-protocol.md).

---

## Principles

- **No version history in content.** Every file states the platform as it is now.
  Git history is the change record. The maintenance protocol ensures this source
  always equals the live ServiceNow application.
- **No duplication of fact.** Each fact has one home. Other files link to it.
- **No placeholder content.** Every claim traces to the canon or is the canon.
