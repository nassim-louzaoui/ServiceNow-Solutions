# Operations Intelligence — Source of Truth

This repository is the **single source of truth** for the Operations Intelligence
platform: an enterprise intelligent-automation and deliverable system, built as a
ServiceNow scoped application (`x_infte_ops_int`), that lets Infosys operations
teams create, govern, and run automations and ServiceNow deliverables entirely
through natural language.

It is not a document dump. It is a structured, self-maintaining knowledge system
with live credentials, verbatim implementation source, and operating rules for every
AI or human working on this platform.

---

## The System at a Glance

| Folder | Role | Read this when you need… |
|---|---|---|
| [`context/`](context/) | **Why** the platform exists + credentials + system context | Business narrative, credentials, active instance details |
| [`architecture/`](architecture/) | **What** the platform is — the complete technical canon | Any technical detail: tables, Script Includes, ACLs, VA, build order |
| [`implementation/`](implementation/) | **How** it is built — verbatim source, coding patterns, REST mechanics, recipes | The exact code, the patterns, and how to add any artifact |
| [`ai-delivery/`](ai-delivery/) | **Produce** — logic and worked deliverables generated from the canon | To create a presentation, overview, or briefing |
| [`ai-guide/`](ai-guide/) | **Operate** — how an AI should reason and act in this repo | To know how to handle any request: explain, build, generate, change |
| [`reference/`](reference/) | **Look up** — glossary of exact terms and identifiers | The one correct spelling of a name or term |
| [`maintenance/`](maintenance/) | **Sustain** — the protocol that keeps this repo true | Whenever the platform changes |
| [`.github/`](.github/copilot-instructions.md) | **Onboard AI** — auto-loaded instructions | Automatically, every session |

---

## The Two Canons

Everything else is derived from two authoritative sources. When they disagree with
any other file, they win.

1. **Business canon** — [`context/`](context/). The problem, the value, the future
   state, the solution, and the live system context including credentials.
2. **Technical canon** — [`architecture/solution-architecture.md`](architecture/solution-architecture.md).
   The complete specification of the platform.

---

## How to Navigate

- **An AI starting work here?** Read [`ai-guide/operating-guide.md`](ai-guide/operating-guide.md).
- **Need credentials or instance details?** [`context/00-credentials-and-context.md`](context/00-credentials-and-context.md).
- **Building or extending the platform?** Start at [`implementation/build-order.md`](implementation/build-order.md).
- **Need the exact name of something?** [`reference/glossary.md`](reference/glossary.md).
- **You changed the platform?** Follow [`maintenance/self-maintenance-protocol.md`](maintenance/self-maintenance-protocol.md).

---

## No Version History in Content

Each file states the platform as it is *now*. Change tracking is the job of git
history, not of prose.
