# AI Operating Guide

You are an AI working on Operations Intelligence with this repository as your single
source of truth. This guide tells you how to think and what to do. Follow it for
every request. It assumes you have read
[`../.github/copilot-instructions.md`](../.github/copilot-instructions.md).

---

## The mental model

Operations Intelligence lets operations teams create two kinds of thing —
**automations** (that run) and **deliverables** (that exist) — in natural language,
with Copilot filling technical gaps and role-based approval governing impact, all
inside **one scoped ServiceNow app** (`x_infte_ops_int`) at **one portal**
(`/operations_intelligence`). The engine is the sole remote build interface: 117
operations over a single authenticated REST endpoint. Everything you build or explain
serves one outcome: the distance from "I know what I need" to "it exists" is a
conversation.

---

## Step 0 — Classify the request

| Kind | Looks like | Go to |
|---|---|---|
| **Explain / answer** | "How does X work?", "What is the rule for Y?" | §A |
| **Build / implement** | "Add a widget", "create the table", "build feature Z" | §B |
| **Generate a deliverable** | "Make a presentation / overview / briefing / doc" | §C |
| **Change the platform** | "Fix X", "change behaviour Y" | §D |

---

## §A — Explain or answer

1. Find the authoritative source. Technical → `architecture/solution-architecture.md`.
   Business → `context/`. Credentials / instance → `context/00-credentials-and-context.md`.
   A term → `reference/glossary.md`.
2. Answer from the canon, not from general ServiceNow knowledge.
3. Quote the exact identifiers.
4. If the canon genuinely does not cover it, say so — do not invent a rule.

## §B — Build or implement

1. Confirm **where it fits**: [`../implementation/build-order.md`](../implementation/build-order.md).
2. Confirm **the mechanism**: engine operation (preferred for remote builds), in-instance
   background script + GlideRecord, or REST via `svc_operations_intelligence_api`.
3. Follow **patterns**: [`../implementation/coding-patterns.md`](../implementation/coding-patterns.md).
4. Use the matching **recipe** in [`../implementation/recipes/`](../implementation/recipes/).
5. Use **verbatim source** from [`../implementation/scripts/`](../implementation/scripts/).
6. **Verify**: run `02_verify_implementation.js`.
7. **Record** per §D.

## §C — Generate a deliverable

1. Go to [`../ai-delivery/`](../ai-delivery/README.md).
2. Apply [`../ai-delivery/generation-logic.md`](../ai-delivery/generation-logic.md).
3. No placeholders. No invented metrics. Every claim traces to the canon.

## §D — Change the platform (and keep this repo true)

1. Make/design the platform change.
2. Follow [`../maintenance/self-maintenance-protocol.md`](../maintenance/self-maintenance-protocol.md)
   exactly: update the technical canon, the verbatim implementation source, the
   business canon if rationale moved, and any affected deliverable — in the same change.
3. Never add a changelog, dated note, or "v2" annotation. Edit files so they simply
   state the new current truth.
4. Self-check against the authority order: if two files now disagree, the lower-authority
   one is wrong — fix it before finishing.

---

## Rules that bind every kind of request

- **Accuracy of names is non-negotiable.** Roles, scope, portal, Script Include, widget,
  property, and update-set names must be exact — `reference/glossary.md` is the spelling authority.
- **Security facts are load-bearing.** `github_pat` is unreadable by everyone including
  admin; `artifact_sys_ids` is admin/System only; approval escalation updates the existing
  `pending_action`; Copilot failure falls back silently; scheduled data jobs use
  `sysauto_report`, not `sysauto_script`. Getting any of these wrong produces an insecure
  or incorrect result.
- **ES5 only in the engine script.** No template literals, `let`/`const`, arrow functions,
  destructuring, or `eval()`. Template literals cause a Rhino parse error at load time,
  which silently disables the entire engine.
- **No inline comments in the engine body.** The formal header at the top of the engine
  script covers scope, endpoint, auth, request format, and operation catalog only.
- **No AI identity.** No AI tool, model, or vendor name in any artifact name, property,
  Script Include, configuration, or description.
- **Naming.** Title case, full words, no abbreviations in all display names.
- **Say each thing once.** Do not duplicate canon content into other files; link to it.
- **Prefer the verbatim artifact** over your recollection of how the code looks.
- **When unsure, read, don't guess.**
