# AI Guide — Operational Procedures

This folder contains the step-by-step operating procedures for any AI working on
Operations Intelligence. Read `../AI-GUIDE.md` first for the mental model, authority
order, request classification, and rules. This folder is the procedural depth.

| File | Purpose |
|---|---|
| [`operating-guide.md`](operating-guide.md) | Detailed procedures for explain, build, generate, and change requests |
