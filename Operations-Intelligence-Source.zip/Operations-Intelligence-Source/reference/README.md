# Reference

Quick-lookup material that supports the canon without restating it. Use these when you
need a precise term or identifier fast.

| File | Contents |
|---|---|
| [`glossary.md`](glossary.md) | Canonical terms, roles, identifiers, and named artifacts — with the one exact spelling to use |

For anything beyond a definition, the reference points you to the authoritative
section in [`../architecture/solution-architecture.md`](../architecture/solution-architecture.md)
or [`../context/`](../context/). The reference never overrides the canon; if they ever
differ, the canon wins and the reference is corrected.
