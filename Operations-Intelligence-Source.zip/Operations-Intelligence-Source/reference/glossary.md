# Glossary

The one correct spelling and meaning for every term, role, and identifier in
Operations Intelligence. When you write code, documentation, or a deliverable, use
these exactly. Where a term has a fuller treatment, the authoritative section is named.

## Platform and Surfaces

| Term | Meaning |
|---|---|
| **Operations Intelligence** | The platform: a ServiceNow scoped application for operations teams. Never abbreviated in prose. |
| **Operations Assistant** | The platform's Virtual Agent. The natural-language interface to everything. |
| **Operations Intelligence NLU** | The dedicated NLU model. No shared intents with Now Support. |
| **Portal** | The single Service Portal at URL suffix `/operations_intelligence`, portal id `operations_intelligence`, default page `main`. |
| **Sections** | The role-filtered areas within `main`: Workspace, My Activity, Studio, Governance, Command. Switching is client-side with no page reload. |
| **`{scope}`** | Placeholder for the application scope prefix. Actual value: `x_infte_ops_int`. |
| **Engine** | The Scripted REST API at `POST /api/x_infte_ops_int/ops_int_engine/v1`. 117 operations. Authentication: `X-Engine-Key` header matching `x_infte_ops_int.engine_key`. The sole remote build and management interface. |

## Roles (System) and Group Roles

| Term | Meaning |
|---|---|
| **admin** | Platform/IT. Full access; onboards top-level leadership; sees the Command section. |
| **leadership** | Business leaders. Group governance, user onboarding, approvals; sees the Governance section. |
| **creator** | Appointed power users. Design automations and deliverables for their groups; see the Studio section. Auto-granted when leadership appoints a group creator. |
| **user** | All other staff. Trigger automations and request deliverables via the Operations Assistant. |
| **group role** | Per-group role on `group_member`: `creator` or `user`. Independent of system role. |
| **delegation_rights** | Boolean on the `person` record. A leader with it set may onboard sub-leaders, never exceeding their own level. |

Roles are always read from ServiceNow (`gs.hasRole()`), never from a field on a
custom table. Authoritative: architecture *Roles*.

## Core Concepts

| Term | Meaning |
|---|---|
| **Automation** | A multi-step process sequence (`automation` + `automation_step` + `automation_input`), executed by `ExecutionEngine` on demand or on schedule. |
| **Deliverable / Managed Artifact** | A persistent ServiceNow artifact registered in `managed_artifact` and managed for its full lifecycle through Operations Intelligence. |
| **Execution** | One run of an automation (`execution` + `execution_step_log`). `is_test = true` runs are dry-run and excluded from `usage_count`. |
| **Group** | An operations team. `leadership_group` (auto-created for a leader) or `custom_group`. |
| **Pending Action** | A queued decision (`pending_action`): approval, deactivation, expiry, escalation. Escalation **updates** the existing record — never creates a second. |
| **Use Case Request** | Captured requirements for an automation (`use_case_request`), produced by the NLU conversation, optionally Copilot-enhanced. |
| **Creator Credential** | A creator's encrypted GitHub PAT (`creator_credential.github_pat`, `password2`). Read-blocked for everyone including admin; read only by `CopilotBridge` via an elevated GlideRecord. |

## Key Script Includes

Full list and dependency order: architecture *Script Includes*.

| Name | One-Line Role |
|---|---|
| **PermissionResolver** | Reads ServiceNow roles + group_member; never `person.system_role`. |
| **VAHelper** | VA context: identity, role, groups, top-N catalog, section context. |
| **CatalogService** | Automation lifecycle: create, version, publish, deprecate, VA topic, NLU retrain. |
| **ExecutionEngine** | Runs automation steps; template-variable resolution; dry-run; step logging. |
| **ApprovalRouter** | Self-approval guard, null-leader fallback, escalation, target resolution. |
| **CopilotBridge** | One bounded Copilot call; write-only PAT access; silent fallback. |
| **ArtifactManager** | Deliverable registry: `managed_artifact` CRUD, lifecycle, builder dispatch. |
| **TableBuilder / ReportBuilder / NotificationBuilder / FlowBuilder / UIPageBuilder** | The five builders that create underlying ServiceNow records per deliverable type. |
| **MaintenanceManager** | Reads/writes maintenance state; generates Studio export URL; logs via AuditService. |
| **AuditService** | Field-level audit logging for privileged admin actions. |

## Identifiers — Spell These Exactly

| Thing | Exact Value |
|---|---|
| Scope prefix | `x_infte_ops_int` |
| Portal id / URL suffix | `operations_intelligence` |
| Default portal page | `main` |
| Maintenance widgets | `oi-maintenance-overlay`, `oi-maintenance-control-panel` |
| Maintenance properties | `x_infte_ops_int.maintenance_sections`, `…maintenance_message`, `…maintenance_return_at`, `…maintenance_initiated_by`, `…maintenance_initiated_at` |
| Notification prefix | `OI - ` |
| Active update set | `Operations Intelligence` |
| Service account | `svc_operations_intelligence_api` |
| Service account sys_id | `94a5973dfb6dcb5052eef5c9beefdc77` |
| Engine key property | `x_infte_ops_int.engine_key` |
| Engine endpoint | `POST /api/x_infte_ops_int/ops_int_engine/v1` |

## Easy-to-Confuse Distinctions

- **`sysauto_script` vs `sysauto_report`.** `sysauto_script` is used only by
  `ScheduleManager` for automation scheduling. Scheduled data jobs use `sysauto_report`
  — declarative, no script. Never build a scheduled data job as a `sysauto_script`.
- **Automation vs Deliverable.** Both are created in natural language and use Copilot,
  but an automation *runs* (produces executions) while a deliverable *exists* (a
  durable artifact). Different tables, different lifecycles.
- **System Topic vs Per-Automation Topic.** System topics are fixed platform capabilities;
  per-automation topics are generated by `CatalogService.onPublish()`.
- **Engine vs Background Script.** The engine (`engine-api.md`) is used for remote
  builds from outside ServiceNow. Background scripts run inside the instance with
  full GlideRecord access and are used for maintenance operations and verification.
