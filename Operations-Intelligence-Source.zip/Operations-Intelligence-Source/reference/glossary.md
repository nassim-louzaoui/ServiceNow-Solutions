# Glossary

The one correct spelling and meaning for every term, role, and identifier in
Operations Intelligence. When you write code, documentation, or a deliverable, use
these exactly.

## Platform and surfaces

| Term | Meaning |
|---|---|
| **Operations Intelligence** | The platform: a ServiceNow scoped application for operations teams. Never abbreviated in prose; "OI" is acceptable only as an artifact-name prefix. |
| **Operations Assistant** | The platform's Virtual Agent (channel). The natural-language interface to everything. |
| **Operations Intelligence NLU** | The dedicated NLU model. No shared intents or training data with Now Support. |
| **Portal** | The single Service Portal at URL suffix `/operations_intelligence`, portal id `operations_intelligence`, default page `main`. |
| **Sections** | The role-filtered areas within the `main` page: Workspace, My Activity, Studio, Governance, Command. Switching is client-side; no page reload. |
| **`{scope}`** | Placeholder for the application scope prefix. Actual value: `x_infte_ops_int`. |
| **Engine** | The Scripted REST API at `POST /api/x_infte_ops_int/ops_int_engine/v1`. 117 operations. Auth: `X-Engine-Key` header. The sole remote build and management interface. |

## Roles (system) and group roles

| Term | Meaning |
|---|---|
| **admin** | Platform/IT. Full access; onboards top-level leadership; sees the Command section. |
| **leadership** | Business leaders. Group governance, onboarding, approvals; sees the Governance section. |
| **creator** | Appointed power users. Design automations and deliverables for their groups; see the Studio section. A *system role*, auto-granted when leadership appoints a group creator. |
| **user** | All other staff. Trigger automations and request deliverables via the Operations Assistant. |
| **group role** | Per-group role on `group_member`: `creator` or `user`. Independent of system role. |
| **delegation_rights** | Boolean on the `person` record. A leader with it set may onboard sub-leaders. |

Roles are always read from ServiceNow (`gs.hasRole()`), never from a field on a custom table.

## Core concepts

| Term | Meaning |
|---|---|
| **Automation** | A multi-step process sequence (`automation` + `automation_step` + `automation_input`), executed by `ExecutionEngine` on demand or on schedule. |
| **Deliverable / managed artifact** | A persistent ServiceNow artifact registered in `managed_artifact` and managed for its whole lifecycle through OI. |
| **Execution** | One run of an automation (`execution` + `execution_step_log`). `is_test = true` runs are dry-run and excluded from `usage_count`. |
| **Group** | An operations team. `leadership_group` (auto-created for a leader) or `custom_group`. |
| **Pending action** | A queued decision (`pending_action`): approval, deactivation, expiry, escalation. Escalation **updates** the existing record; never creates a second. |
| **Use case request** | The captured requirements for an automation (`use_case_request`). |
| **Creator credential** | A creator's encrypted GitHub PAT (`creator_credential.github_pat`, `password2`). Read-blocked for everyone including admin. |

## Key Script Includes (full list: architecture *Script Includes*)

| Name | One-line role |
|---|---|
| **PermissionResolver** | Reads ServiceNow roles + group_member; never `person.system_role`. |
| **VAHelper** | VA context: identity, role, groups, top-N catalog, section context. |
| **CatalogService** | Automation lifecycle: create, version, publish, deprecate, VA topic, NLU retrain. |
| **ExecutionEngine** | Runs automation steps; template-variable resolution; dry-run; step logging. |
| **ApprovalRouter** | Self-approval guard, null-leader fallback, escalation, target resolution. |
| **CopilotBridge** | One bounded Copilot call; write-only PAT access; silent fallback; phrase merge / deliverable spec. |
| **ArtifactManager** | Deliverable registry: `managed_artifact` CRUD, lifecycle, builder dispatch. |
| **TableBuilder / ReportBuilder / NotificationBuilder / FlowBuilder / UIPageBuilder** | The five builders that create the underlying ServiceNow records per deliverable type. |
| **MaintenanceManager** | Reads/writes maintenance state; generates the Studio export URL; logs via AuditService. |
| **AuditService** | Field-level audit logging for privileged admin actions. |

## Identifiers you must spell exactly

| Thing | Exact value |
|---|---|
| Scope prefix | `x_infte_ops_int` |
| Portal id / URL suffix | `operations_intelligence` |
| Default portal page | `main` |
| Maintenance widgets | `oi-maintenance-overlay`, `oi-maintenance-control-panel` |
| Maintenance properties | `{scope}.maintenance_sections`, `.maintenance_message`, `.maintenance_return_at`, `.maintenance_initiated_by`, `.maintenance_initiated_at` |
| Notification prefix | `OI - ` |
| Active update set | `Operations Intelligence` |
| Service account | `svc_operations_intelligence_api` |
| Service account sys_id | `94a5973dfb6dcb5052eef5c9beefdc77` |
| Engine key property | `x_infte_ops_int.engine_key` |
| Engine endpoint | `POST /api/x_infte_ops_int/ops_int_engine/v1` |

## Easy-to-confuse distinctions

- **`sysauto_script` vs `sysauto_report`.** `sysauto_script` is used **only** by
  `ScheduleManager` for automation scheduling; its body is always
  `new ExecutionEngine().runScheduled(automation_sys_id)`. Scheduled **data jobs**
  use `sysauto_report` — declarative, no script.
- **Automation vs deliverable.** Both are created by natural language and use Copilot,
  but an automation *runs* (executions) while a deliverable *exists* (a durable artifact).
- **System topic vs per-automation topic.** System topics are fixed capabilities built
  once; per-automation topics are generated by `CatalogService.onPublish()`.
- **`engine.selfupdate` vs background script.** The engine can update its own operation
  script via `engine.selfupdate`. Background scripts run in-instance with full
  GlideRecord access. Both paths are idempotent and valid; prefer the engine for remote
  orchestration.
