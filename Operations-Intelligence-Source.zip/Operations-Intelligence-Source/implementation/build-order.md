# Build Order — Operational Run Sheet

This is the operational run sheet: the manual prerequisites and the exact order to
run the background scripts. The complete authoritative build sequence lives in
[`../architecture/solution-architecture.md`](../architecture/solution-architecture.md)
under **Build Order**. This file is the checklist you keep open while doing it.

## Pre-build (manual, in ServiceNow Studio)

1. Create the scoped application in Studio. Scope: `x_infte_ops_int`.
2. Create the four application roles: `admin`, `leadership`, `creator`, `user`.
3. Confirm the scope picker (top-right banner) shows **Operations Intelligence**,
   not **Global**.

## Background scripts, in order

Run from **System Definition → Scripts - Background**, with the OI scope active
unless noted.

| Order | Script | Scope | What it does |
|---|---|---|---|
| 1 | `01_global_cleanup.js` | **Global** | Remove any artifacts from a prior partial deploy |
| 2 | `02_engine_setup.js` | OI scope | Create the Scripted REST API (`ops_int_engine`), generate the engine key property |
| 3 | `02b_engine_operation_script.js` | OI scope | Load the full 117-operation engine script into the operation record (or use `update_engine.sh` via `engine.selfupdate`) |
| 4 | `02d_grant_svc_account_roles.js` | Global | Grant `admin` role to `svc_operations_intelligence_api` |
| 5 | `02c_set_svc_account_password.js` | Global | Set the service account password; capture output |
| 6 | `02e_show_credentials.js` | OI scope | Print all live credentials to output; capture screenshot |
| 7 | `03_setup_update_sets.js` | OI scope | Create and activate the "Operations Intelligence" update set |
| 8 | `03_create_tables.js` | OI scope | Create all 19 custom tables with fields |
| 9 | *(full build sequence)* | OI scope | Script Includes, business rules, notifications, VA topics, portal and widgets per architecture Build Order steps 1–15 |
| 10 | `04_build_maintenance.js` | OI scope | Create 5 maintenance properties, MaintenanceManager Script Include, both maintenance widgets |
| 11 | `02_verify_implementation.js` | OI scope | Verify every artifact group; run after each major step and as the final gate |

## Engine deployment (ongoing)

After any change to `02b_engine_operation_script.js`:

```bash
bash implementation/scripts/background/update_engine.sh
```

This posts the file via `engine.selfupdate`. Alternatively run
`02g_update_engine_directly.js` as a background script.

## Verification

Run `02_verify_implementation.js` after every build step. All checks must read
`[OK]` or `[SKIP]`. Run `test_engine.sh` after each engine update to confirm
all 117 operations behave correctly.

## Migration

Promotion from dev → test → prod: Studio application export (preferred) or update
set. Environment config sets are applied separately. The NLU model must be retrained
on each environment after import. Follow the architecture under **Update Set &
Migration Strategy**.
