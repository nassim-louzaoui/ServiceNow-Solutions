# Coding Patterns & Conventions

Every artifact in Operations Intelligence follows a small set of patterns. Use them
exactly when you build or extend the platform — they are what make the code
consistent, idempotent, and safe. The verbatim files in
[`scripts/`](scripts/) are the worked examples referenced throughout.

This file is about *how* to write artifacts. *What* to build and in what order is the
architecture canon and [`build-order.md`](build-order.md).

---

## 1. Scope prefix discipline

All custom tables are auto-prefixed with the application scope. The architecture
writes the unprefixed name (`automation`); real code uses the prefixed name
(`x_infte_ops_int_automation`).

- **Never hardcode the prefix as a literal.** Resolve it at runtime:
  `gs.getCurrentScopeName()` (server) returns `x_infte_ops_int`. Build table names as
  `gs.getCurrentScopeName() + '_automation'` only when you must; prefer referencing
  records you already hold.
- System property keys are prefixed too: `gs.getProperty(gs.getCurrentScopeName() + '.maintenance_message')`.
  `MaintenanceManager._scope()` / `_getProp()` are the canonical helpers — see
  [`scripts/script-includes/MaintenanceManager.js`](scripts/script-includes/MaintenanceManager.js).
- The authoritative `{scope}` value for a given instance is printed by
  [`scripts/background/01_bootstrap_api_access.js`](scripts/background/01_bootstrap_api_access.js).

## 2. Two ways to create artifacts — pick deliberately

| Mechanism | Use when | Pattern source |
|---|---|---|
| **Background script + GlideRecord** | Building inside the instance, idempotently, with no external tooling | [`scripts/background/04_build_maintenance.js`](scripts/background/04_build_maintenance.js) |
| **REST API via `svc_operations_intelligence_api`** | Building from external/automated tooling | [`rest-api-guide.md`](rest-api-guide.md) |

Both create the *same records*. The background-script path is the most robust for
in-instance work because it runs in the active scope and is trivially idempotent; the
REST path is for orchestration from outside ServiceNow.

## 3. Idempotency: the `createOrSkip` pattern

Build scripts must be safe to re-run. Never blind-insert. Query first; insert only if
absent. The canonical helper (from `04_build_maintenance.js`):

```javascript
function createOrSkip(table, queryFn, insertFn, label) {
    var gr = new GlideRecord(table);
    queryFn(gr);
    gr.setLimit(1);
    gr.query();
    if (gr.next()) { /* already exists — skip */ return gr.getUniqueValue(); }
    var newGr = new GlideRecord(table);
    newGr.initialize();
    insertFn(newGr);
    return newGr.insert();
}
```

Every build script reports `[OK] / [SKIP] / [FAIL]` per artifact and a summary count.
A re-run of a completed build must produce all `[SKIP]` and zero `[FAIL]`.

## 4. Scope guard at the top of every background script

A background script that builds scoped artifacts must refuse to run in global scope,
because artifacts created under the wrong scope cannot be easily moved:

```javascript
var scope = gs.getCurrentScopeName();
if (!scope || scope === 'global') {
    gs.print('ERROR: Switch to your Operations Intelligence scope first.');
    return;
}
```

All four background scripts in [`scripts/background/`](scripts/background/) open with
this guard.

## 5. Client-callable Script Includes: the `AbstractAjaxProcessor` pattern

Any Script Include called from a widget client controller via GlideAjax extends
`AbstractAjaxProcessor`. `MaintenanceManager` is the reference implementation. The
rules it follows:

- `Class.create()` + `Object.extendsObject(AbstractAjaxProcessor, { ... })`.
- Record settings: **Client callable = true**, **Access = public**, **Active = true**,
  `api_name = {scope}.Name`.
- **Two surfaces, one logic.** Public `ajaxXxx()` methods are the GlideAjax entry
  points; they read params with `this.getParameter('sysparm_x')`, enforce
  authorisation, then delegate to private `_xxx()` methods. The same `_xxx()` methods
  are also exposed through plain server-side methods so other Script Includes can call
  the logic directly without going through AJAX. This is why `MaintenanceManager` has
  both `ajaxSetMaintenance()` and `setMaintenance()`.
- **Authorise inside every mutating `ajax` method**, never assume the caller is
  trusted: `if (!gs.hasRole('admin')) { return JSON.stringify({ error: 'Unauthorized' }); }`.
- Return strings: booleans as `'' + value`, objects as `JSON.stringify(obj)`.
- End with `type: 'Name'`.

## 6. Embedding a Script Include inside a background script (Rhino)

When a background script *creates* a Script Include record, the `script` field is a
string. Build it as a line array joined with `\n` so it is readable and quote-safe in
the Rhino engine — see the `siCode = [ ... ].join('\n')` block in
`04_build_maintenance.js`. This is why `MaintenanceManager` exists in two forms (a
readable `.js` file and the embedded array); the
[`README`](README.md#two-representations-of-maintenancemanager--both-correct-on-purpose)
and the [maintenance protocol](../maintenance/self-maintenance-protocol.md) require
both to be updated together.

## 7. Service Portal widget structure

Every widget is four parts, kept as four files under
[`scripts/widgets/<id>/`](scripts/widgets/):

| File | Field on `sp_widget` | Pattern |
|---|---|---|
| `template.html` | `template` | AngularJS bindings `{{c.data.x}}`, `ng-if`, `ng-repeat`. SVG illustrations are inline — no external image URLs. |
| `server-script.js` | `script` | `(function(){ ... })()`; reads `options`, role-gates with `gs.hasRole()`, populates the `data` object, may call Script Includes directly. |
| `client-script.js` | `client_script` | `function($scope, ...) { var c = this; ... }`; `c` is the controller; talks to the server via GlideAjax. |
| `style.css` | `css` | Widget-scoped class names prefixed `oi-`. |

The two maintenance widgets are the reference. Match their conventions: controller
alias `c = this`, GlideAjax through a single `_ajax(method, params, cb)` helper,
`$scope.$apply()` (guarded by `if (!$scope.$$phase)`) after async updates, and
`$interval`/`$timeout` cleaned up on `$destroy`.

## 8. GlideAjax call convention (client → Script Include)

```javascript
var ga = new GlideAjax('MaintenanceManager');     // Script Include name
ga.addParam('sysparm_name', 'ajaxGetStatus');     // the ajax method
ga.addParam('sysparm_section', sectionId);        // extra params as sysparm_*
ga.getXMLAnswer(function(answer) {                 // answer is the returned string
    var res = JSON.parse(answer);                  // parse if the method returns JSON
    // ... update c.*, then $scope.$apply() if needed
});
```

## 9. Security conventions (always)

- **Never return or log a secret.** `creator_credential.github_pat` is read-blocked
  for everyone including admin; `CopilotBridge` reads it via an elevated GlideRecord
  and passes it straight to the outbound call. Do not add a code path that returns it.
- **Never hardcode credentials** in automation step `configuration` JSON — use
  execution context variables or a ServiceNow Connection & Credential alias.
- **Authorise server-side**, not just by hiding UI. Widget server scripts role-gate
  with `gs.hasRole()` and return early for unauthorised users; the matching `ajax`
  methods re-check the role.
- **Audit privileged actions.** Admin actions that bypass normal role checks are
  logged via `AuditService` (e.g. `MaintenanceManager` logs `maintenance_enabled`,
  `maintenance_disabled`, `app_export_triggered`).

## 10. Template variables in automation steps

`ExecutionEngine` resolves `{{input.X}}`, `{{context.X}}`, and `{{steps.N.output.X}}`
in step `configuration` JSON before each step runs. An unresolvable variable is a
**step error**, never a silent empty value. The full variable catalogue and the
per-action configuration schemas are in the architecture (*Execution Context
Variables*, *Automation Step Action Types*). When you author a step, reference those
schemas exactly.
