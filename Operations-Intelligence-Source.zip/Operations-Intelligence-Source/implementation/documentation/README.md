# Implementation Documentation

This folder documents how Operations Intelligence is implemented: what patterns
all artifacts follow, how to deploy and sequence the build, how to use the engine
API, and how to add each kind of artifact. It is the reference you read before
building or extending anything.

| File / folder | Read it to… |
|---|---|
| [`build-order.md`](build-order.md) | Know the deploy prerequisites and sequence |
| [`coding-patterns.md`](coding-patterns.md) | Follow the exact patterns every artifact uses |
| [`engine-api.md`](engine-api.md) | Use the engine to create and manage platform artifacts remotely |
| [`rest-api-guide.md`](rest-api-guide.md) | Make direct Table API calls to ServiceNow |
| [`recipes/`](recipes/) | Follow step-by-step procedures for adding one artifact of each kind |

The verbatim deployed source is in [`../source/`](../source/).
The authoritative specification of what each artifact does is in
[`../../architecture/solution-architecture.md`](../../architecture/solution-architecture.md).
