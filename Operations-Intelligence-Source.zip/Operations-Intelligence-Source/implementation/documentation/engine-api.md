# Engine API Reference

The engine is the primary remote interface for building and managing Operations
Intelligence. It is a Scripted REST API deployed in the `x_infte_ops_int` scope
providing 117 operations across every category of platform management.

Authentication, credentials, and the live instance URL are in
[`../../context/05-system-context.md`](../../context/05-system-context.md).
The verbatim engine source is in
[`../source/engine/operation-script.js`](../source/engine/operation-script.js).

---

## Request Format

```
POST https://everestdev.service-now.com/api/x_infte_ops_int/ops_int_engine/v1
Authorization: Basic <base64(svc_operations_intelligence_api:PASSWORD)>
X-Engine-Key: <engine_key>
Content-Type: application/json
```

**Single operation:**
```json
{"op": "<name>", "data": { ... }, "table": "<table>", "query": { ... }, "limit": 100}
```

**Batch:**
```json
{"op": "batch", "ops": [{"op": "ping"}, {"op": "now", "label": "ts"}], "stop_on_error": true}
```

**Platform writes** — bypass the scoped sandbox, write to any ServiceNow table:
```json
{"op": "record.insert", "table": "sys_script_include", "platform": true, "data": {...}}
```

All responses are wrapped by ServiceNow: `{"result": {...}}`. Unwrap `.result`.

---

## Update Set Management

All configuration-creating operations (`artifact.*`, `schema.*`, `acl.*`, `role.grant`,
`user.create`, `group.*`) automatically ensure the single "Operations Intelligence"
update set is active before writing. This is transparent — callers do not manage it.

Check active update set: `{"op": "engine.status"}` → returns `update_set: {name, sys_id, state}`.

---

## Operations (117)

### DIAGNOSTICS

| Operation | Returns |
|---|---|
| `ping` | `{ok, pong, scope, ts}` |
| `now` | `{ok, utc, display, numeric}` |
| `scope.info` | `{ok, scope, instance, user, roles, platform_capable}` |
| `engine.status` | `{ok, scope, instance, op_count, update_set, inventory}` |
| `selftest` | `{ok, read, write, platform_write}` |
| `help` | `{ok, count, ops[{op, description}]}` — full annotated operation list |
| `sys.version` | `{ok, build_name, build_date, build_tag, instance}` |

### DISCOVERY

| Operation | Required data | Notes |
|---|---|---|
| `meta.tables` | — | Tables in scope |
| `meta.script_includes` | — | |
| `meta.business_rules` | — | |
| `meta.notifications` | — | |
| `meta.widgets` | — | |
| `meta.jobs` | — | |
| `meta.acls` | — | |
| `meta.all` | — | All artifact groups in one response |
| `meta.ui_pages` | — | |
| `meta.portal_pages` | — | |
| `meta.catalog_items` | — | |
| `meta.app_menus` | — | |
| `meta.app_modules` | — | |
| `meta.events` | — | |
| `meta.roles` | — | |
| `meta.portals` | — | |
| `table.exists` | `table` (field) | Returns `{ok, exists}` |
| `schema.fields` | `table` (field) | Fields on a table |
| `table.schema` | `table` (field) | Full schema with field details |

### DDL

| Operation | Required data | Notes |
|---|---|---|
| `schema.table.create` | `name`, `label` | Creates table in `x_infte_ops_int` scope |
| `schema.table.delete` | `name` | |
| `schema.table.extend` | `name`, `super_class` | |
| `schema.add_field` | `table`, `name`, `type` | |
| `schema.field.update` | `table`, `name` | |
| `schema.field.delete` | `table`, `name` | |
| `schema.add_choice` | `table`, `field`, `value`, `label` | |
| `schema.choice.update` | `table`, `field`, `value` | |
| `schema.choice.delete` | `table`, `field`, `value` | |
| `schema.set_autonumber` | `table` | |
| `schema.index.create` | `table`, `fields` | |

### PROPERTIES

| Operation | Required data |
|---|---|
| `property.set` | `name`, `value` |
| `property.get` | `name` |
| `property.list` | — |
| `property.delete` | `name` |

### RECORDS

| Operation | Required data | Notes |
|---|---|---|
| `record.insert` | `table`, `data` | |
| `record.insert_many` | `table`, `records` (array) | |
| `record.update` | `table`, `sys_id`, `data` | |
| `record.patch` | `table`, `sys_id`, `data` | Partial update |
| `record.upsert` | `table`, `query`, `data` | Insert or update |
| `record.delete` | `table`, `sys_id` | |
| `record.bulk_delete` | `table`, `query` | |
| `record.get` | `table`, `sys_id` | |
| `record.find` | `table`, `query` | First matching record |
| `record.query` | `table` | Filter with `query` or `data`; `limit` defaults to 100 |
| `record.clone` | `table`, `sys_id` | |
| `record.count` | `table` | With optional `query` |
| `record.aggregate` | `table`, `aggregate` | |
| `record.history` | `table`, `sys_id` | |
| `record.exists` | `table`, `query` | |
| `record.read_many` | `table`, `sys_ids` | |
| `table.truncate` | `table` | Remove all rows |

### ACL

| Operation | Required data |
|---|---|
| `acl.create` | `type`, `name`, `operation` |
| `acl.delete` | `sys_id` |
| `acl.list` | — |

### ACCESS

| Operation | Required data |
|---|---|
| `role.grant` | `user`, `role` |
| `role.revoke` | `user`, `role` |
| `user.roles` | `user` |

### USERS

| Operation | Required data |
|---|---|
| `user.create` | `user_name`, `first_name`, `last_name`, `email` |
| `user.get` | `user` |
| `user.update` | `user`, `data` |
| `user.search` | `query` |

### GROUPS

| Operation | Required data |
|---|---|
| `group.create` | `name` |
| `group.add_member` | `group`, `user` |
| `group.remove_member` | `group`, `user` |
| `group.members` | `group` |
| `group.search` | `query` |

### UPDATE SETS

| Operation | Required data |
|---|---|
| `update_set.create` | `name` |
| `update_set.activate` | `sys_id` |
| `update_set.list` | — |

### ARTIFACTS

All artifact operations follow the find-then-upsert pattern: they check if a record
with the given `name` exists in the `x_infte_ops_int` scope, update it if found, and
insert it if not. `sys_scope` is set automatically.

| Operation | Primary artifact table | Required data |
|---|---|---|
| `artifact.script_include` | `sys_script_include` | `name`, `script` |
| `artifact.business_rule` | `sys_script` | `name`, `table`, `when`, `script` |
| `artifact.notification` | `sysevent_email_action` | `name`, `table` |
| `artifact.scheduled_job` | `sysauto_script` | `name`, `script`, `run_type` |
| `artifact.client_script` | `sys_script_client` | `name`, `table`, `type`, `script` |
| `artifact.ui_action` | `sys_ui_action` | `name`, `table` |
| `artifact.widget` | `sp_widget` | `id`, `name` |
| `artifact.ui_page` | `sys_ui_page` | `name` |
| `artifact.sp_page` | `sp_page` | `id` |
| `artifact.sp_container` | `sp_container` | — |
| `artifact.sp_row` | `sp_row` | — |
| `artifact.sp_column` | `sp_column` | — |
| `artifact.sp_instance` | `sp_instance` | — |
| `artifact.sp_theme` | `sp_theme` | `name` |
| `artifact.app_menu` | `sys_app_application` | `name` |
| `artifact.app_module` | `sys_app_module` | `name` |
| `artifact.catalog_item` | `sc_cat_item` | `name` |
| `artifact.catalog_variable` | `item_option_new` | `name`, `cat_item` |
| `artifact.ui_policy` | `sys_ui_policy` | `name`, `table` |
| `artifact.ui_policy_action` | `sys_ui_policy_action` | `field_name` |
| `artifact.event_registry` | `sysevent_register` | `name`, `table` |
| `artifact.report` | `sys_report` | `name`, `table` |
| `artifact.role` | `sys_user_role` | `name` |
| `artifact.sp_portal` | `sp_portal` | `url_suffix` |

### FILES

| Operation | Required data |
|---|---|
| `attachment.write` | `table`, `sys_id`, `file_name`, `content_type`, `content` |
| `attachment.read` | `sys_id` |
| `attachment.list` | `table`, `sys_id` |
| `attachment.delete` | `sys_id` |

### POWER

| Operation | Required data | Notes |
|---|---|---|
| `script.run` | `script` | Executes arbitrary server-side JavaScript via GlideScopedEvaluator. Set `result` variable to return a value. |
| `rest.call` | `url`, `method` | Outbound REST from the instance |
| `event.fire` | `name`, `table`, `sys_id` | |
| `sys.log` | `message` | |
| `cache.flush` | — | |
| `sys.id` | — | Returns a new sys_id |
| `note.add` | `table`, `sys_id`, `value` | |

### WORKFLOW

| Operation | Required data |
|---|---|
| `workflow.start` | `name`, `table`, `sys_id` |
| `workflow.cancel` | `context_id` |

### EMAIL

| Operation | Required data |
|---|---|
| `email.send` | `to`, `subject`, `body` |

### ENGINE

| Operation | Required data | Notes |
|---|---|---|
| `engine.source` | — | Returns the current operation script source |
| `engine.selfupdate` | `script` | Replaces the engine operation script. Validates presence of safety markers before replacing. |

### BATCH

| Operation | Required data |
|---|---|
| `batch` | `ops` (array of operations), optional `stop_on_error` (default true) |

---

## Practical Notes

- **Idempotency:** artifact operations are always find-then-upsert. Re-running is safe.
- **Scope:** all artifact and schema operations automatically target `x_infte_ops_int`.
- **Platform writes:** add `"platform": true` to bypass the scoped sandbox for
  operations that need to write outside the application scope.
- **Limit:** `record.query` and similar operations default to 100 results; set `limit`
  explicitly. Maximum 10,000.
- **Error responses:** `{"result": {"ok": false, "error": "<message>", "_status": <code>}}`.
