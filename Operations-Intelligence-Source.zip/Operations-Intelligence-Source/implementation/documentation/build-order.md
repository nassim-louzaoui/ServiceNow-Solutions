# Build Order

This is the operational deploy reference: prerequisites, script sequence, and
engine setup. The complete authoritative 15-step build sequence — with every table
name, Script Include dependency chain, and the 30-item verification checklist —
lives in [`../../architecture/solution-architecture.md`](../../architecture/solution-architecture.md)
under **Build Order**. This file is the checklist you keep open while working from
that specification.

---

## Pre-build (manual, in ServiceNow Studio)

1. Create the scoped application in Studio with scope `x_infte_ops_int`.
2. Create the four application roles: `admin`, `leadership`, `creator`, `user`.
   ServiceNow prefixes them with the scope automatically.
3. Confirm the scope picker (top-right banner) shows **Operations Intelligence**,
   not **Global**. Every artifact must be created while this scope is active.

---

## Engine Setup

The engine (`POST /api/x_infte_ops_int/ops_int_engine/v1`) is the primary remote
build interface. It must be deployed before any remote build steps can run.

1. In ServiceNow Studio (OI scope active), create a Scripted REST API named
   **Operations Intelligence Engine** with service ID `ops_int_engine`.
2. Add a resource named **Engine Router**, HTTP method POST, URI `/v1`,
   requires authentication.
3. Set the resource script to the content of
   [`../source/engine/operation-script.js`](../source/engine/operation-script.js).
4. Create a system property `x_infte_ops_int.engine_key` with a secure random value.
   This value becomes the `X-Engine-Key` header required on every engine request.
5. Verify with `{"op": "ping"}` — expect `{"ok": true, "pong": true}`.

Full credentials and the live engine key are in
[`../../context/05-system-context.md`](../../context/05-system-context.md).

---

## Service Account Setup

The service account `svc_operations_intelligence_api` holds the `admin` role and
is used for:
- Basic Auth on all engine requests
- Platform writes (engine operations with `"platform": true`)
- Direct Table API calls

Create the account in ServiceNow User Administration, grant the `admin` role, and
set the password to the value in `context/05-system-context.md`. Store the password
in system property `x_infte_ops_int.svc_password`.

---

## Build Sequence

Run in OI scope (scope picker shows **Operations Intelligence**).

| Step | Tool | What it does |
|---|---|---|
| 1 — Tables | Engine: `schema.table.create` per table | Create all 19 custom tables with fields |
| 2 — Roles and ACLs | Engine: `acl.create`, `role.grant` | Create table, row, and field ACLs |
| 3 — Script Includes | Engine: `artifact.script_include` | All 21 in dependency order (see architecture) |
| 4 — Business Rules | Engine: `artifact.business_rule` | All 5 rules |
| 5 — Notifications | Engine: `artifact.notification` | All 22 templates |
| 6 — VA and NLU | Engine: `artifact.scheduled_job`, VA topics | Channel, NLU model, 23 system topics |
| 7 — Portal | Engine: `artifact.sp_portal`, `artifact.sp_page` | Portal, pages, widgets |
| 8 — Maintenance | Background: `04_build_maintenance.js` | 5 properties, MaintenanceManager, 2 widgets |
| 9 — Verify | Background: `02_verify_implementation.js` | All artifact groups; must read all [OK]/[SKIP] |

After every step, run `02_verify_implementation.js`. Every check must pass before
the next step. Do not promote until the final run produces all [OK] or [SKIP] with
zero [FAIL].

---

## Migration

Promotion from dev → test → prod: Studio application export (preferred) or single
update set. Environment-specific config sets are applied separately after import.
The NLU model must be retrained on each environment after import. Follow the
architecture under **Update Set & Migration Strategy** — do not duplicate those
steps here.
