# Implementation Recipes

Step-by-step procedures for adding one artifact of a given kind, correctly and
idempotently, following the platform's patterns. Each recipe assumes you have read
[`../coding-patterns.md`](../coding-patterns.md) and know which mechanism you are
using (background script + GlideRecord, or REST — see
[`../rest-api-guide.md`](../rest-api-guide.md)).

A recipe is *how to add one thing*. The full build order and the complete list of
what exists is the architecture canon and [`../build-order.md`](../build-order.md).

| Recipe | Use when you need to… |
|---|---|
| [`add-a-script-include.md`](add-a-script-include.md) | Add server-side logic, optionally client-callable |
| [`add-a-custom-table.md`](add-a-custom-table.md) | Add a custom data table with fields |
| [`add-a-service-portal-widget.md`](add-a-service-portal-widget.md) | Add a portal widget (the four-file structure) |
| [`add-a-notification.md`](add-a-notification.md) | Add an email/in-app notification template |
| [`add-a-va-topic.md`](add-a-va-topic.md) | Add a Virtual Agent topic + NLU intent |

After any recipe: run
[`../scripts/background/02_verify_implementation.js`](../scripts/background/02_verify_implementation.js),
update the architecture canon and (if the artifact has standalone source) the
`scripts/` tree, and follow the
[maintenance protocol](../../maintenance/self-maintenance-protocol.md).
