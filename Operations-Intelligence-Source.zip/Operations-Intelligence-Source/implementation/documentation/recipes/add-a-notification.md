# Recipe — Add a Notification

Operations Intelligence has 22 notification templates, all dispatched through
`NotificationService` and all named with the `OI - ` prefix. This recipe adds one.
The full list with triggers and recipients is the architecture's *Notification
Templates* section — consult it so a new notification fits the existing scheme and
does not duplicate one.

## 1. Decide trigger style

OI notifications fire one of two ways:

- **Event-driven** — a Script Include (via `NotificationService`) raises an event and
  the notification is bound to that `event_name`. Preferred for OI, because dispatch
  and recipient resolution live in `NotificationService` (including escalation-target
  resolution via `ApprovalRouter.getEscalationTarget()`).
- **Condition-driven** — the notification has a `condition` on a table `When to send`.
  Used only where a simple record condition is sufficient.

## 2. Record fields (`sysevent_email_action`)

| Field | Value |
|---|---|
| `name` | `OI - <Descriptive Name>` |
| `collection` | the triggering table (e.g. `x_infte_ops_int_pending_action`) |
| `event_name` | the event it listens for (event-driven), or |
| `condition` | the record condition (condition-driven) |
| `subject` | the email subject (may use `${field}` substitutions) |
| `message_html` | the body (HTML; use mail-script `${...}` for dynamic content) |
| `recipients` / `recipient_fields` | who receives it — resolve via `NotificationService` where the recipient is computed (e.g. primary leader, escalation target) |
| `sys_scope` | OI app sys_id |
| `active` | `true` |

## 3. Wire the trigger

For event-driven notifications, the raising code lives in the Script Include that owns
the lifecycle step. Example shape:

```javascript
gs.eventQueue('x_infte_ops_int.automation.submitted', current, approverSysId, '');
```

`NotificationService` centralises this — add the event and recipient logic there
rather than scattering `gs.eventQueue` calls, so escalation and null-leader fallback
stay consistent with the architecture (*User Deactivation Flow*, *Automation
Lifecycle*, approval escalation rules).

## 4. Recipient correctness (important)

Recipient resolution must honour the platform's routing rules:

- Approvals go to the **primary leader**; on null/deactivated leader, walk up the
  hierarchy, then admin.
- **Escalation updates the existing `pending_action`** and notifies the resolved
  escalation target — it never creates a second action record.
- Cross-group approvals go to `group.owner` (or admin if null/deactivated).

Use `ApprovalRouter` / `NotificationService` to resolve these — do not hardcode a
recipient.

## 5. Finish

- Add the row to the architecture's *Notification Templates* table (name, trigger,
  recipients).
- Add the name to the `templates` array in
  [`../../source/background/02_verify_implementation.js`](../../source/background/02_verify_implementation.js).
- If a new VA topic should surface the same event to the user, see
  [`add-a-va-topic.md`](add-a-va-topic.md).
- Follow the [maintenance protocol](../../maintenance/self-maintenance-protocol.md).
