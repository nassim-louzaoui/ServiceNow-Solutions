# REST API Implementation Guide

This guide is for building Operations Intelligence from **outside** ServiceNow — an
orchestrator (AI tooling or a script) that creates artifacts over HTTP using the
`svc_operations_intelligence_api` service account. The in-instance alternative (background script +
GlideRecord) is in [[`coding-patterns.md`](coding-patterns.md)](coding-patterns.md) §2–3; both create the
same records.

What each artifact *is* and the order to build them is the architecture canon and
[`build-order.md`](build-order.md). This file is the HTTP mechanics.

---

## Authentication and base setup

1. Run `../../context/05-system-context.md` for all credentials, instance URL, scope, and scope sys_id.
2. Authenticate every call with HTTP Basic auth using those credentials.
3. The service account holds `admin`, so it can create any artifact. Records are
   placed in the OI application by setting the **`sys_scope`** field to the Scope
   Sys ID on insert (and by the account operating with cross-scope privileges granted
   to admin).

```
Authorization: Basic base64(svc_operations_intelligence_api:PASSWORD)
Content-Type:  application/json
Accept:        application/json
```

> **Idempotency over REST:** before POSTing, GET with a query to check existence, and
> skip if found — the HTTP equivalent of the `createOrSkip` pattern. Re-running a
> build must not create duplicates.

---

## The Table API (the workhorse)

Almost every artifact is a row in a ServiceNow table, created with the Table API:

```
POST  {InstanceURL}/api/now/table/{table}        → create a record
GET   {InstanceURL}/api/now/table/{table}?sysparm_query=...&sysparm_limit=1
PUT   {InstanceURL}/api/now/table/{table}/{sys_id}
DELETE{InstanceURL}/api/now/table/{table}/{sys_id}
```

The target `{table}` for each artifact type:

| Artifact | Table | Key fields to set |
|---|---|---|
| System property | `sys_properties` | `name`, `value`, `type`, `description`, `write_roles` |
| Script Include | `sys_script_include` | `name`, `script`, `api_name` (`{scope}.Name`), `client_callable`, `access`, `active`, `sys_scope` |
| Business Rule | `sys_script` | `name`, `collection` (table), `when`, `order`, `action_insert`/`action_update`, `condition`, `script`, `sys_scope` |
| Notification | `sysevent_email_action` | `name`, `collection`, `event_name` or `condition`, `subject`, `message_html`, recipient fields, `sys_scope` |
| Scheduled job | `sysauto_script` | `name`, `script`, `run_type`, schedule fields, `active`, `sys_scope` |
| Service Portal widget | `sp_widget` | `id`, `name`, `template`, `css`, `script`, `client_script`, `option_schema`, `public`, `servicenow` |
| Portal | `sp_portal` | `url_suffix`, `title`, `default_page`, `sys_scope` |
| Portal page | `sp_page` | `id`, `title`, `sys_scope` |
| NLU model | `sys_nlu_model` | `name` |
| VA channel | `sys_cs_channel` | `name` |
| VA topic / blocks | `sys_cs_topic` / `sys_cs_topic_block` | see [`recipes/add-a-va-topic.md`](recipes/add-a-va-topic.md) |

Reference values (e.g. `sys_scope`, a `collection`, a `category`) are set by sending
the **sys_id** of the target record as the field value.

### Example — create a system property

```
POST {InstanceURL}/api/now/table/sys_properties
{
  "name":        "x_infte_ops_int.maintenance_message",
  "value":       "",
  "type":        "string",
  "description": "Message displayed on the Maintenance Overlay. Empty = default text.",
  "write_roles": "admin"
}
```

### Example — create a Script Include

```
POST {InstanceURL}/api/now/table/sys_script_include
{
  "name":            "MaintenanceManager",
  "api_name":        "x_infte_ops_int.MaintenanceManager",
  "client_callable": "true",
  "access":          "public",
  "active":          "true",
  "sys_scope":       "{ScopeSysId}",
  "script":          "var MaintenanceManager = Class.create(); ... type: 'MaintenanceManager'\n});"
}
```

Send the full source as the `script` string (escape newlines/quotes per JSON). The
canonical body is [`../source/script-includes/MaintenanceManager.js`](../source/script-includes/MaintenanceManager.js).

---

## Custom tables (two-record approach)

A custom table is not a single POST. Create it in two steps, mirroring what
`TableBuilder` does in-platform. Full walkthrough:
[`recipes/add-a-custom-table.md`](recipes/add-a-custom-table.md).

1. **Create the table** — POST to `sys_db_object` with `name`
   (`x_infte_ops_int_<table>`), `label`, optional `super_class`, and `sys_scope`.
   ServiceNow provisions the physical table and its collection dictionary row.
2. **Add each field** — POST to `sys_dictionary` per column: `name` (the table),
   `element` (field name), `internal_type` (e.g. `string`, `integer`, `glide_date_time`,
   `reference`, `boolean`, `choice`), `column_label`, `mandatory`, and for references
   `reference` (target table).

---

## NLU model training

After creating or changing VA topics/intents, retrain (architecture: *NLU Model
Training*):

```
POST {InstanceURL}/api/sn_nlu/v1/model/{nlu_model_sys_id}/train
{ }

GET  {InstanceURL}/api/sn_nlu/v1/model/{nlu_model_sys_id}
→ { "status": "ready" | "training" | "failed" }
```

Poll the GET until `status = "ready"` (typically 2–5 minutes for small models) before
running verification or tests.

---

## Application export

The packaged application XML (for migration) is produced by a UI endpoint, gated
behind full-app maintenance and surfaced by `MaintenanceManager.getExportURL()`:

```
{InstanceURL}/sys_app_export.do?sysparm_record_id={app_sys_id}
```

This streams a file download in a browser session; it is not a JSON API. Prefer the
Studio export / update-set strategy in the architecture for promotion.

---

## Verification

After any REST-built step, run
[`../source/background/02_verify_implementation.js`](../source/background/02_verify_implementation.js)
in the instance (or replicate its checks over the Table API by GET-querying each
artifact group). The two security assertions are mandatory and easy to check over
REST:

```
# github_pat must never come back populated, even as admin:
GET {InstanceURL}/api/now/table/x_infte_ops_int_creator_credential/{sys_id}?sysparm_fields=github_pat
→ field is null/empty

# A field-level read ACL must exist on creator_credential:
GET {InstanceURL}/api/now/table/sys_security_acl?sysparm_query=nameLIKEcreator_credential^operation=read^type=field
→ at least one record
```

---

## Practical notes

- **Display values vs sys_ids:** add `sysparm_input_display_value=true` to accept
  display values on input, or send sys_ids directly (preferred for references).
- **Cross-scope:** creating scoped artifacts over REST requires the application's
  cross-scope privileges to permit it; the admin service account satisfies this for
  OI's own scope. If a create is rejected for scope reasons, fall back to the
  in-instance background-script path.
- **Choosing the mechanism:** for the maintenance feature, the project ships the
  in-instance build (`04_build_maintenance.js`) because it is idempotent and
  scope-safe out of the box. Use REST when an external orchestrator must drive the
  build; use the background script when you are working inside the instance.
