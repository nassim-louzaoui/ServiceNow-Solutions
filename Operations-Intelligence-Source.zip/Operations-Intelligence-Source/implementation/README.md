# Implementation — Verbatim, Deployable Artifact Source

This folder holds the **exact source** of the artifacts that make up Operations
Intelligence. Every file here is byte-for-byte what is deployed in ServiceNow. It is
not a description of the code — it *is* the code. The architecture document explains
what these artifacts do; this folder is the ground truth for their content.

> **Invariant:** the files in `scripts/` must always match both the live ServiceNow
> instance and the specification in
> [`../architecture/solution-architecture.md`](../architecture/solution-architecture.md).
> If one changes, the others change in the same commit.

## What is in this folder

| File / folder | Role |
|---|---|
| [`build-order.md`](build-order.md) | Operational run sheet: prerequisites and the background scripts, in order |
| [`coding-patterns.md`](coding-patterns.md) | The canonical patterns every artifact follows |
| [`rest-api-guide.md`](rest-api-guide.md) | Engine API and Table API mechanics |
| [`recipes/`](recipes/) | Step-by-step procedures for adding one artifact of each kind |
| [`scripts/`](scripts/) | Verbatim, deployable source |

## Layout

```
implementation/
  build-order.md
  coding-patterns.md
  rest-api-guide.md
  recipes/
    add-a-script-include.md    add-a-custom-table.md    add-a-service-portal-widget.md
    add-a-notification.md      add-a-va-topic.md
  scripts/
    background/
      01_global_cleanup.js              Clean up any prior partial deploy (global scope)
      02_engine_setup.js                Create the Scripted REST API + engine key property
      02a_generate_engine_key.js        Regenerate the engine key
      02b_engine_operation_script.js    The engine operation script (117 operations) — ground truth
      02c_set_svc_account_password.js   Set/reset service account password
      02d_grant_svc_account_roles.js    Grant admin role to service account
      02e_show_credentials.js           Print live credentials to background script output
      02f_setup_and_show_credentials.js Combined setup + show (idempotent)
      02g_update_engine_directly.js     Update engine script in-place via GlideRecord
      02_verify_implementation.js       Verify all artifacts after build
      03_create_tables.js               Create all 19 custom tables
      03_setup_update_sets.js           Create and activate the "Operations Intelligence" update set
      03a_cleanup_orphan_tables.js      Remove tables from prior partial deploys
      04_build_maintenance.js           Build MaintenanceManager + both maintenance widgets + 5 props
      test_engine.sh                    Full engine test harness (bash; 117 operations)
      update_engine.sh                  Deploy engine operation script via engine.selfupdate
    script-includes/
      MaintenanceManager.js             Readable canonical source of the maintenance Script Include
    widgets/
      oi-maintenance-overlay/           Shown in place of a section when it is in maintenance
        template.html  client-script.js  server-script.js  style.css
      oi-maintenance-control-panel/     Admin control surface in the Command section
        template.html  client-script.js  server-script.js  style.css
```

## Two representations of MaintenanceManager — both correct, on purpose

`MaintenanceManager.js` in `script-includes/` is the readable source.
The same code is also embedded as a line array inside `04_build_maintenance.js`
so the build script can create the Script Include record without depending on an
external file. The [maintenance protocol](../maintenance/self-maintenance-protocol.md)
requires both to be updated together whenever the logic changes.
