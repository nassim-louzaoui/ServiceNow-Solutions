# Implementation — Documentation and Verbatim Source

This folder is in two parts: **documentation** (how the platform is implemented,
what patterns to follow, and how to add or change artifacts) and **source** (the
exact, deployable code that is live in ServiceNow right now).

> **Invariant:** `source/` must always match both the live ServiceNow instance and
> `../architecture/solution-architecture.md`. If one changes, all three change in
> the same unit of work.

---

## Layout

```
implementation/
│
├── documentation/              How the implementation works — read before building
│   ├── README.md
│   ├── build-order.md          Prerequisites and deploy sequence
│   ├── coding-patterns.md      ES5 rules, scope discipline, idempotency, patterns
│   ├── engine-api.md           The engine REST API — all 117 operations
│   ├── rest-api-guide.md       Table API mechanics for direct ServiceNow REST calls
│   └── recipes/                Step-by-step guides for each artifact type
│       ├── README.md
│       ├── add-a-custom-table.md
│       ├── add-a-notification.md
│       ├── add-a-script-include.md
│       ├── add-a-service-portal-widget.md
│       └── add-a-va-topic.md
│
└── source/                     Verbatim deployed code — ground truth for the instance
    ├── README.md
    ├── engine/
    │   └── operation-script.js  The engine operation script (117 operations)
    ├── script-includes/
    │   └── MaintenanceManager.js
    ├── background/
    │   ├── 02_verify_implementation.js   Verifies all platform artifacts
    │   └── 04_build_maintenance.js       Builds maintenance properties + widgets
    └── widgets/
        ├── oi-maintenance-control-panel/
        │   ├── client-script.js
        │   ├── server-script.js
        │   ├── style.css
        │   └── template.html
        └── oi-maintenance-overlay/
            ├── client-script.js
            ├── server-script.js
            ├── style.css
            └── template.html
```

## Two Representations of MaintenanceManager

`source/script-includes/MaintenanceManager.js` is the readable canonical source.
The same code is embedded as a string array inside `source/background/04_build_maintenance.js`
so the build script can create the Script Include record without external dependencies.
The [maintenance protocol](../maintenance/self-maintenance-protocol.md) requires
both to be updated together whenever the logic changes.
