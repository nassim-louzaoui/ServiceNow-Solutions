# Source — Verbatim Deployed Artifacts

Every file in this folder is byte-for-byte what is deployed in the live ServiceNow
instance. This is the ground truth for artifact content. The architecture document
specifies what they do; this folder is what they are.

| Path | Artifact |
|---|---|
| `engine/operation-script.js` | Engine operation script — 117 operations |
| `script-includes/MaintenanceManager.js` | Maintenance Script Include (readable canonical source) |
| `background/02_verify_implementation.js` | Verifies all platform artifacts; run after every build step |
| `background/04_build_maintenance.js` | Creates maintenance properties, MaintenanceManager, both widgets |
| `widgets/oi-maintenance-overlay/` | Maintenance overlay widget (4 files) |
| `widgets/oi-maintenance-control-panel/` | Admin maintenance control widget (4 files) |

## Invariant

These files must always match: (1) this folder, (2) the live ServiceNow instance,
and (3) `../../architecture/solution-architecture.md`. If any one changes, all three
change in the same commit. See `../../maintenance/self-maintenance-protocol.md`.

## Two Representations of MaintenanceManager

`script-includes/MaintenanceManager.js` is the readable source. The same logic is
embedded as a string array inside `background/04_build_maintenance.js` so the build
script can create the Script Include record without external file dependencies. Both
must be updated together whenever the logic changes.
