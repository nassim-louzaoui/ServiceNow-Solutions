# REST API Implementation Guide

This guide covers two HTTP-based build paths: the **Engine API** (primary, preferred)
and the **Table API** (for direct artifact creation). Both use the
`svc_operations_intelligence_api` service account.

---

## The Engine (primary build interface)

The engine is a Scripted REST API in the `x_infte_ops_int` scope. It provides
117 operations covering diagnostics, discovery, DDL, records, ACLs, users, groups,
artifacts, files, scripts, workflows, and more.

**Endpoint:** `POST https://everestdev.service-now.com/api/x_infte_ops_int/ops_int_engine/v1`

**Authentication:**
```
Authorization: Basic <base64(svc_operations_intelligence_api:PASS)>
X-Engine-Key: <value of x_infte_ops_int.engine_key property>
Content-Type: application/json
```

Full credentials: [`../context/00-credentials-and-context.md`](../context/00-credentials-and-context.md).

**Single operation:**
```json
{"op": "record.insert", "table": "x_infte_ops_int_person", "data": {"first_name": "Alex"}}
```

**Batch:**
```json
{"op": "batch", "ops": [{"op": "ping"}, {"op": "now", "label": "ts"}], "stop_on_error": true}
```

**Platform writes** (bypass scoped sandbox, write to any table):
```json
{"op": "record.insert", "table": "sys_script_include", "platform": true, "data": {...}}
```

**Responses** are wrapped by ServiceNow: `{"result": {...}}`. Unwrap `.result`.

**Operation groups:** DIAGNOSTICS · DISCOVERY · DDL · PROPERTIES · RECORDS · ACL ·
ACCESS · USERS · GROUPS · UPDATE SETS · ARTIFACTS · FILES · POWER · WORKFLOW ·
EMAIL · ENGINE · BATCH

Send `{"op": "help"}` for the full annotated list. Send `{"op": "engine.status"}` for
health, inventory, and update set state. See `02b_engine_operation_script.js` for the
complete implementation.

---

## Update set management

All configuration-creating engine operations (`artifact.*`, `schema.*`, ACL, role,
user, group writes) automatically ensure the "Operations Intelligence" update set is
active before writing. This is done transparently — callers do not need to manage it.

Check the active update set:
```json
{"op": "engine.status"}
```
Returns `update_set: {name, sys_id, state}`.

---

## The Table API (direct artifact creation)

For building from outside the engine, use the Table API directly with the service
account. This is the fallback when the engine is not yet deployed or for operations
the engine does not expose.

**Base URL:** `https://everestdev.service-now.com`

```
POST  {base}/api/now/table/{table}
GET   {base}/api/now/table/{table}?sysparm_query=...&sysparm_limit=1
PUT   {base}/api/now/table/{table}/{sys_id}
DELETE{base}/api/now/table/{table}/{sys_id}
```

**Auth:** same Basic Auth as the engine.

**Idempotency over REST:** before POSTing, GET with a query to check existence, and
skip if found. Re-running a build must not create duplicates.

### Artifact tables

| Artifact | Table | Key fields |
|---|---|---|
| System property | `sys_properties` | `name`, `value`, `type`, `description`, `write_roles` |
| Script Include | `sys_script_include` | `name`, `script`, `api_name` (`{scope}.Name`), `client_callable`, `access`, `active`, `sys_scope` |
| Business Rule | `sys_script` | `name`, `collection`, `when`, `order`, `action_insert`/`action_update`, `condition`, `script`, `sys_scope` |
| Notification | `sysevent_email_action` | `name`, `collection`, `event_name`, `subject`, `message_html`, recipient fields, `sys_scope` |
| Scheduled job | `sysauto_script` | `name`, `script`, `run_type`, schedule fields, `active`, `sys_scope` |
| Service Portal widget | `sp_widget` | `id`, `name`, `template`, `css`, `script`, `client_script`, `option_schema` |
| Portal | `sp_portal` | `url_suffix`, `title`, `default_page`, `sys_scope` |
| Portal page | `sp_page` | `id`, `title`, `sys_scope` |
| VA topic / blocks | `sys_cs_topic` / `sys_cs_topic_block` | see [`recipes/add-a-va-topic.md`](recipes/add-a-va-topic.md) |

### Example — create a system property

```
POST {base}/api/now/table/sys_properties
{
  "name":        "x_infte_ops_int.maintenance_message",
  "value":       "",
  "type":        "string",
  "description": "Message displayed on the Maintenance Overlay.",
  "write_roles": "admin"
}
```

### Custom tables (two-record approach)

1. **Create the table** — POST to `sys_db_object` with `name`
   (`x_infte_ops_int_<table>`), `label`, optional `super_class`, and `sys_scope`.
2. **Add each field** — POST to `sys_dictionary` per column: `name`, `element`,
   `internal_type`, `column_label`, `mandatory`, and for references `reference`.

---

## NLU model training

After creating or changing VA topics:

```
POST {base}/api/sn_nlu/v1/model/{nlu_model_sys_id}/train
{}

GET  {base}/api/sn_nlu/v1/model/{nlu_model_sys_id}
→ { "status": "ready" | "training" | "failed" }
```

Poll until `status = "ready"` before running verification.

---

## Verification

After any build step, run `02_verify_implementation.js` in-instance, or replicate
its checks over the Table API by GET-querying each artifact group. The two mandatory
security assertions:

```
# github_pat must never come back populated:
GET {base}/api/now/table/x_infte_ops_int_creator_credential/{sys_id}?sysparm_fields=github_pat
→ field is null/empty

# Field-level read ACL must exist on creator_credential:
GET {base}/api/now/table/sys_security_acl?sysparm_query=nameLIKEcreator_credential^operation=read^type=field
→ at least one record
```
