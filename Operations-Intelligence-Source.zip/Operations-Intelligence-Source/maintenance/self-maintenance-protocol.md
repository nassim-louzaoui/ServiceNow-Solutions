# Self-Maintenance Protocol

This repository is a **living** source of truth: it must always state the platform as
it actually is right now. That property does not maintain itself — it is maintained
by everyone (human or AI) who changes the platform following this protocol. This file
is the protocol.

## The core rule

> **A change to the platform is not complete until this repository states the new
> truth.**

If you correct, extend, or remove anything in the live Operations Intelligence
application, the same unit of work updates the canon and the verbatim source here.
There is no "update the docs later." Later is how a source of truth becomes a source
of confusion.

## What must move together

These travel in the same commit. Changing one without the others is a defect.

| If you change… | You must also update… |
|---|---|
| Any technical behaviour, structure, or rule | [`../architecture/solution-architecture.md`](../architecture/solution-architecture.md) (the technical canon) |
| The body of a background script, Script Include, or widget | The matching verbatim file in [`../implementation/scripts/`](../implementation/scripts/) — **and**, for maintenance logic, both the readable `MaintenanceManager.js` and its line-array copy inside `04_build_maintenance.js` |
| A coding pattern, REST procedure, or how an artifact kind is built | [`../implementation/coding-patterns.md`](../implementation/coding-patterns.md), [`../implementation/rest-api-guide.md`](../implementation/rest-api-guide.md), or the affected [`../implementation/recipes/`](../implementation/recipes/) file |
| A term, role, or identifier name | [`../reference/glossary.md`](../reference/glossary.md) |
| The business rationale, value, scope, or solution shape | The relevant file in [`../context/`](../context/) |
| Anything that changes what a generated deliverable would say | The affected file(s) in [`../ai-delivery/deliverables/`](../ai-delivery/deliverables/), regenerated per [`../ai-delivery/generation-logic.md`](../ai-delivery/generation-logic.md) |
| How an AI should reason/act, or the repo's structure and rules | [`../ai-guide/operating-guide.md`](../ai-guide/operating-guide.md), the affected `README.md`, and [`../.github/copilot-instructions.md`](../.github/copilot-instructions.md) |

## The invariants this protocol protects

1. **Architecture ⟷ implementation agree.** The verbatim source in `implementation/`
   matches the specification in `architecture/` and matches the live instance. Three
   representations, one truth.
2. **Two representations of maintenance logic stay identical.** The readable
   `MaintenanceManager.js` and the string-array version embedded in
   `04_build_maintenance.js` are the same logic. If you touch one, touch both.
3. **Derived files trace to a canon.** Nothing in `ai-delivery/`, a folder `README`,
   or the Copilot instructions asserts a fact the canon does not support.
4. **No duplication of fact.** Each fact has one home. Other files link to it. If you
   are about to paste a paragraph from a canon into another file, link instead.

## No history inside content

This repository carries **no changelog, no "what changed in vX", no dated notes**
inside any file. Every file reads as the current, standalone truth. Change history is
git's job. When you update a file, edit it so it simply *is* correct now — do not
annotate what it used to say.

## The maintenance loop (follow in order)

1. **Make the platform change** in ServiceNow (or design it).
2. **Update the technical canon** so the specification matches reality.
3. **Update the verbatim source** in `implementation/` to match (both copies of any
   maintenance logic).
4. **Update the business canon** in `context/` if rationale, value, scope, or
   solution shape moved.
5. **Regenerate affected deliverables** in `ai-delivery/deliverables/` from the
   updated canon.
6. **Update structural files** (`README`s, Copilot instructions) only if the system's
   shape or rules changed.
7. **Self-check against the conflict order** in
   [`../.github/copilot-instructions.md`](../.github/copilot-instructions.md): if any
   two files now disagree, the lower-authority one is wrong — fix it before you
   finish.
8. **Commit as one unit** with a message describing the change to the platform, not to
   the docs. The docs are not a separate thing; they are part of the change.

## Definition of done

A change is done when: the live instance, the architecture canon, the implementation
source, the business canon, and the affected deliverables all tell the same story;
no file contradicts a higher-authority file; and no placeholder, stale value, or
change-log annotation was introduced.
