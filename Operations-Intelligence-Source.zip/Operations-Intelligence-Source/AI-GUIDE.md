# AI Guide — Operations Intelligence Source

You are an AI working on the Operations Intelligence platform. This file is your
primary operating manual. Read it in full before acting on any request. It tells you
what this system is, how it is organised, what authority each part holds, and exactly
how to handle every kind of request. `.github/copilot-instructions.md` is loaded
automatically and covers the same facts in brief — this file is the depth behind it.

---

## 1. What Operations Intelligence Is

Operations Intelligence is a ServiceNow scoped application (`x_infte_ops_int`) that
lets Infosys operations teams create, govern, and execute process automations and
persistent ServiceNow deliverables entirely through natural language, via a dedicated
Virtual Agent called the **Operations Assistant**. When a user cannot supply a
technical detail, GitHub Copilot generates the specification and the user confirms
it. Role-appropriate approval workflows govern impactful changes. Everything lives
at one portal: `/operations_intelligence`.

The platform has two creative tracks: **automations** (multi-step sequences that
run on demand or on schedule) and **deliverables** (durable ServiceNow artifacts —
reports, dashboards, notification rules, scheduled data jobs, flows, custom tables,
UI pages). Both are created in natural language, Copilot-enhanced, and governed by
the same role and approval model.

---

## 2. The Authority Order — Resolve Every Conflict With This

When any two files disagree, the higher authority is correct. The lower file is
wrong and must be corrected before you finish.

| Authority | File | Governs |
|---|---|---|
| 1st | `architecture/solution-architecture.md` | All technical facts |
| 2nd | `context/` (all five files) | All business facts; live credentials and identifiers |
| 3rd | `implementation/` | Verbatim artifact source and implementation documentation |
| 4th | Everything else | Derived; must yield to the above |

---

## 3. How This Source Is Organised

### context/ — The Business Canon and System Identity
Five files. Read in order.

| File | Contents |
|---|---|
| `01-problem-statement.md` | The four structural problems operations teams face |
| `02-business-value.md` | The value each problem's removal produces |
| `03-desired-future-state.md` | What working life looks like once the platform is in place |
| `04-proposed-solution.md` | How Operations Intelligence delivers the future state |
| `05-system-context.md` | Live credentials, instance URL, engine endpoint, non-negotiable standards |

### architecture/ — The Technical Canon
One file: `solution-architecture.md`. The complete specification: 19 tables,
21 Script Includes, 5 business rules, 22 notifications, 23 VA topics, portal,
widgets, full ACL model, Copilot integration, maintenance mode, build sequence.
**When in doubt, open this file. Do not guess.**

### implementation/ — How It Is Built
Two subfolders:

**`implementation/documentation/`** — how the implementation works:
- `build-order.md` — prerequisites and deploy sequence
- `coding-patterns.md` — ES5 rules, scope discipline, idempotency, widget structure, security
- `engine-api.md` — the engine REST API: all 117 operations
- `rest-api-guide.md` — Table API mechanics for direct ServiceNow REST calls
- `recipes/` — step-by-step procedures for each artifact type

**`implementation/source/`** — verbatim deployed code:
- `engine/operation-script.js` — the engine operation script (ground truth)
- `script-includes/MaintenanceManager.js` — the maintenance Script Include
- `background/02_verify_implementation.js` — verifies all platform artifacts
- `background/04_build_maintenance.js` — builds maintenance properties + widgets
- `widgets/oi-maintenance-overlay/` and `oi-maintenance-control-panel/` — four files each

### reference/ — Quick Lookup
`glossary.md` — the one correct spelling for every term, role, and identifier.
When you write code or documentation, use these exactly.

### ai-delivery/ — Generating Deliverables
`generation-logic.md` — the procedure for producing audience-appropriate deliverables.
`deliverables/` — three complete reference deliverables (executive, user-facing, technical).

### ai-guide/ — Operational Procedures
`operating-guide.md` — step-by-step procedures for each request type (explain,
build, generate, change), plus the rules that bind all of them.

### maintenance/ — Keeping It True
`self-maintenance-protocol.md` — what must move together when the platform changes,
the invariants to protect, and the definition of done.

### .github/copilot-instructions.md
Auto-loaded by Claude Code and GitHub Copilot every session. Contains the authority
order, key technical facts, and structural index. Do not duplicate its content here.

---

## 4. Classify the Request — Go to the Right Section

| Kind | Looks like | Procedure |
|---|---|---|
| **Explain / answer** | "How does X work?", "What is Y?" | §A |
| **Build / implement** | "Add a widget", "create the table", "build Z" | §B |
| **Generate a deliverable** | "Make a presentation / overview / briefing" | §C |
| **Change the platform** | "Fix X", "change behaviour Y", "add operation Z to engine" | §D |

---

## §A — Explain or Answer

1. Find the authoritative source: technical → `architecture/solution-architecture.md`;
   business → `context/01-04`; credentials/identifiers → `context/05-system-context.md`;
   a term → `reference/glossary.md`.
2. Answer from the canon. If your memory and the canon disagree, the canon is right.
3. Quote exact identifiers — `reference/glossary.md` is the spelling authority.
4. Cite the source so the human can verify.
5. If the canon does not cover it, say so. Do not invent a rule.

## §B — Build or Implement

1. Confirm **where it fits**: `implementation/documentation/build-order.md` and the
   Script Include dependency order in the architecture.
2. Confirm **the mechanism**:
   - Engine operation (preferred for remote builds) — see `implementation/documentation/engine-api.md`
   - In-instance background script + GlideRecord — see `implementation/documentation/coding-patterns.md`
   - Table API directly — see `implementation/documentation/rest-api-guide.md`
3. Follow **coding patterns**: `implementation/documentation/coding-patterns.md`.
   ES5 only in any Rhino-executed code. No backticks, no `let`/`const`, no arrow
   functions, no destructuring, no `eval()`.
4. Use the matching **recipe**: `implementation/documentation/recipes/`.
5. Use **verbatim source** from `implementation/source/`. Never paraphrase code.
6. **Verify**: run `implementation/source/background/02_verify_implementation.js`
   including the two security assertions.
7. **Record the change** per §D.

## §C — Generate a Deliverable

1. Read `ai-delivery/generation-logic.md` in full.
2. Classify the audience and intent. Map to source sections (single-source rule).
3. If a reference deliverable in `ai-delivery/deliverables/` matches, adapt it.
4. No placeholders. No invented metrics. Every claim traces to the canon.
5. Verify against the generation-logic checklist before delivering.

## §D — Change the Platform (and Keep This Source True)

This is what makes this source a truth rather than a snapshot.

1. Make the platform change in ServiceNow.
2. Follow `maintenance/self-maintenance-protocol.md` exactly:
   - Update the technical canon (`architecture/solution-architecture.md`)
   - Update the verbatim source in `implementation/source/` — both copies of any
     maintenance logic (MaintenanceManager.js AND its embedded copy in 04_build_maintenance.js)
   - Update the business canon in `context/` if rationale or scope moved
   - Regenerate affected deliverables in `ai-delivery/deliverables/`
   - Update structural files (READMEs, AI-GUIDE.md, copilot-instructions.md) only
     if the system's shape or rules changed
3. Never add a changelog, dated note, or "v2" annotation to any file. Edit files so
   they simply state the new current truth.
4. Self-check against the authority order. If two files now disagree, fix the lower
   before finishing.
5. The change is done when: live instance, architecture, implementation source, and
   business canon all tell the same story — no file contradicts a higher-authority file.

---

## 5. Non-Negotiable Technical Facts

Getting these wrong produces an incorrect or insecure result.

- **Scope prefix:** `x_infte_ops_int`. Custom tables: `x_infte_ops_int_<name>`.
  Architecture writes the unprefixed name for readability; real code always uses
  the full prefix.
- **Service account:** `svc_operations_intelligence_api`. Sys ID:
  `94a5973dfb6dcb5052eef5c9beefdc77`. Never rename or abbreviate.
- **Engine:** `POST /api/x_infte_ops_int/ops_int_engine/v1`. Auth: `X-Engine-Key`
  header matching `x_infte_ops_int.engine_key` property. 117 operations. The sole
  remote build and management interface.
- **Update set:** the engine maintains exactly one update set named
  "Operations Intelligence". It is created on first configuration write and never
  duplicated. `engine.status` returns its sys_id and state.
- **ES5 only** in any Rhino-executed script (engine operation script, Script Includes,
  background scripts). No backticks, no `let`/`const`, no arrow functions, no
  destructuring, no `eval()`. Template literals cause a parse error that silently
  disables the engine.
- **No inline comments** in the engine script body. A formal header only.
- **`creator_credential.github_pat`** — Read ACL = NOBODY, including admin. Never
  add a code path that returns it.
- **`managed_artifact.artifact_sys_ids`** — readable by admin and System only.
- **`sysauto_script`** is used only by `ScheduleManager` for automation scheduling.
  Scheduled data jobs use `sysauto_report`, never `sysauto_script`.
- **Approval escalation** updates the existing `pending_action` record. It never
  creates a second one.
- **CopilotBridge** makes one bounded call. On any failure it falls back silently.
- **No AI identity** in any artifact name, property, Script Include, or configuration.
- **Naming** — title case, full words, no abbreviations in all display names,
  descriptions, and labels.

---

## 6. Rules That Bind Every Request

- **Accuracy of names is non-negotiable.** Use `reference/glossary.md` for every
  identifier, role name, table name, and widget id. One wrong character breaks things.
- **Say each thing once.** Each fact has one home. Other files link to it. Do not
  copy a paragraph from a canon into another file — link instead.
- **Prefer the verbatim artifact.** `implementation/source/` is ground truth.
  Your recollection of what the code looks like is not.
- **When unsure, read — do not guess.** The answer is almost always in
  `architecture/` or `context/`. Open the file.
- **No history inside content.** Edit files so they state the current truth. Git
  history is the record of what changed.
