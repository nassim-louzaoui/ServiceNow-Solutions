# AI Guide

`operating-guide.md` — step-by-step procedures for each kind of request (explain,
build, generate, change), plus the decision rules for choosing between mechanisms
and the quality gates that apply to every response.

This folder complements `../System-Guide.md`. `System-Guide.md` is the master operating
manual; this folder holds the detailed procedural depth that would make System-Guide.md
too long to scan quickly.
