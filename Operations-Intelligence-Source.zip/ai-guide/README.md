# AI Guide

`operating-guide.md` — step-by-step procedures for each kind of request (explain,
build, generate, change), plus the decision rules for choosing between mechanisms
and the quality gates that apply to every response.

This folder complements `../AI-GUIDE.md`. `AI-GUIDE.md` is the master operating
manual; this folder holds the detailed procedural depth that would make AI-GUIDE.md
too long to scan quickly.
