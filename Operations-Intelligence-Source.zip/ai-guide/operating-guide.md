# AI Operating Guide

You are an AI working on Operations Intelligence with this repository as your single
source of truth. This guide tells you how to think and what to do. Follow it for every
request. It assumes you have read
[`../.github/copilot-instructions.md`](../.github/copilot-instructions.md) (the
conflict/authority order and the non-negotiable technical facts).

---

## The mental model (hold this in your head)

Operations Intelligence lets operations teams create two kinds of thing —
**automations** (that run) and **deliverables** (that exist) — in natural language,
with **Copilot filling technical gaps** and **role-based approval** governing impact,
all inside **one scoped ServiceNow app** at **one portal**. Five sections, four roles,
one Virtual Agent. Everything you build or explain serves the single outcome in
[`../context/03-desired-future-state.md`](../context/03-desired-future-state.md): the
distance from "I know what I need" to "it exists" is a conversation.

If a request or a piece of content does not fit that model, you have misunderstood
something — re-read the relevant canon before acting.

---

## Step 0 — Classify the request

Every request is one of four kinds. Identify which, then jump to its section.

| Kind | Looks like | Go to |
|---|---|---|
| **Explain / answer** | "How does X work?", "What is the rule for Y?" | §A |
| **Build / implement** | "Add a widget", "create the table", "build feature Z" | §B |
| **Generate a deliverable** | "Make a presentation / overview / briefing / doc" | §C |
| **Change the platform** | "Fix X", "change behaviour Y" | §D |

---

## §A — Explain or answer

1. Find the authoritative source. Technical → `architecture/solution-architecture.md`.
   Business → `context/`. A term → `reference/glossary.md`.
2. Answer from the canon, not from general ServiceNow knowledge. If your memory and the
   canon differ, the canon is right.
3. Quote the exact identifiers (`reference/glossary.md` has the spellings).
4. Cite where it comes from so the human can verify.
5. If the canon genuinely does not cover it, say so — do not invent a rule.

## §B — Build or implement

1. Confirm **where it fits**: the build order
   ([`../implementation/build-order.md`](../implementation/build-order.md)) and the
   dependency order in the architecture's *Script Includes* section.
2. Confirm **the mechanism**: in-instance background script + GlideRecord, or REST via
   `svc_operations_intelligence_api`. See [`../implementation/coding-patterns.md`](../implementation/coding-patterns.md) §2.
3. Follow the **patterns** ([`../implementation/coding-patterns.md`](../implementation/coding-patterns.md)):
   scope discipline, `createOrSkip` idempotency, scope guard, the
   `AbstractAjaxProcessor` two-surface pattern, the four-file widget structure, secrets
   handling.
4. Use the matching **recipe** in
   [`../implementation/recipes/`](../implementation/recipes/) for the exact steps.
5. Use **verbatim source**, never paraphrased code: the files in
   [`../implementation/scripts/`](../implementation/scripts/) are ground truth.
6. **Verify**: run / replicate
   [`../implementation/scripts/background/02_verify_implementation.js`](../implementation/scripts/background/02_verify_implementation.js),
   including the two security assertions (`github_pat` unreadable; `artifact_sys_ids`
   restricted).
7. **Record it** per §D — building is also changing.

## §C — Generate a deliverable

1. Go to [`../ai-delivery/`](../ai-delivery/README.md).
2. Apply [`../ai-delivery/generation-logic.md`](../ai-delivery/generation-logic.md):
   classify audience and intent, map to source sections (single-source rule),
   transform (don't copy), verify against the checklist.
3. If a reference deliverable in `ai-delivery/deliverables/` already matches, adapt it
   — it is complete and current. Otherwise produce a new one to the same standard.
4. **No placeholders. No invented metrics.** State value by mechanism. Every claim
   traces to the canon.

## §D — Change the platform (and keep this repo true)

This is the rule that makes the repository a *source of truth* rather than a snapshot.

1. Make/design the platform change.
2. Follow
   [`../maintenance/self-maintenance-protocol.md`](../maintenance/self-maintenance-protocol.md)
   exactly: update the technical canon, the verbatim implementation source (both copies
   of any maintenance logic), the business canon if rationale moved, and any affected
   deliverable — **in the same change**.
3. Never add a changelog, dated note, or "v2" annotation to file content. Edit files so
   they simply state the new current truth. Git history is the only history.
4. Self-check against the authority order: if two files now disagree, the
   lower-authority one is wrong — fix it before finishing.

---

## Rules that bind every kind of request

- **Accuracy of names is non-negotiable.** Roles, scope, portal, Script Include,
  widget, property, and update-set names must be exact — `reference/glossary.md` is the
  spelling authority.
- **Security facts are load-bearing.** `github_pat` is unreadable by everyone including
  admin; `artifact_sys_ids` is admin/System only; approval escalation updates the
  existing `pending_action`; Copilot failure falls back silently; scheduled data jobs
  use `sysauto_report`, not `sysauto_script`. Getting any of these wrong produces an
  insecure or incorrect result.
- **Say each thing once.** Do not duplicate canon content into other files; link to it.
- **Prefer the verbatim artifact** over your recollection of how the code looks.
- **When unsure, read, don't guess.** The answer is almost always already in
  `architecture/` or `context/`. Open it.
