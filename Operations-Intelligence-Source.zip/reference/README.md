# Reference

One file: `glossary.md`. The canonical spelling and meaning for every term, role,
identifier, and table name in Operations Intelligence. When writing code,
documentation, or a deliverable, use these exactly. One wrong character in an
identifier breaks things.
