# Operations Intelligence Source

The single source of truth for the Operations Intelligence platform — a ServiceNow
scoped application (`x_infte_ops_int`) that lets Infosys operations teams create,
govern, and execute process automations and managed ServiceNow deliverables entirely
through natural language.

This is not a document collection. It is a structured system. Every folder has a
defined role. Files reference one another rather than repeating content. An AI
working here is instructed by `AI-GUIDE.md` (read it first) and `.github/copilot-instructions.md`
(auto-loaded each session).

---

## Folder Map

| Folder | Role |
|---|---|
| `context/` | Why the platform exists — problem, value, future state, solution, live credentials |
| `architecture/` | What the platform is — complete technical specification |
| `implementation/documentation/` | How the platform is built — patterns, engine API, REST mechanics, recipes |
| `implementation/source/` | Verbatim deployed code — engine, Script Includes, widgets, background scripts |
| `reference/` | Canonical spelling of every term, name, and identifier |
| `ai-delivery/` | Logic and worked examples for generating audience-appropriate deliverables |
| `ai-guide/` | Step-by-step operating procedures for each request type |
| `maintenance/` | Protocol for keeping this source current when the platform changes |
| `.github/` | Auto-loaded AI instructions (Copilot / Claude Code) |

---

## Two Canons

All other content derives from two authoritative sources. When they conflict with
any other file, the canon wins.

1. **Technical canon** — `architecture/solution-architecture.md`. Every table,
   Script Include, ACL, widget, VA topic, and build sequence.
2. **Business canon** — `context/01` through `context/05`. The problem, value,
   future state, solution, and live operational credentials.

---

## Loose Files

Only two files sit at the root: this README and `AI-GUIDE.md`. Everything else is
inside a folder. This is intentional — the folder structure is the logical map of
the system.
